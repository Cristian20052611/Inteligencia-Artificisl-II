import React, { useState } from 'react';
import { PEDAGOGICAL_STEPS } from '../utils/pedagogy';
import { PedagogicalStepId } from '../types';
import {
  ChevronLeft,
  ChevronRight,
  HelpCircle,
  Lightbulb,
  Sparkles,
  BookOpen,
  ArrowRight,
} from 'lucide-react';

interface PedagogicalGuideProps {
  currentStepIndex: number;
  onStepChange: (index: number) => void;
  onApplyStepPreset: (stepId: PedagogicalStepId) => void;
}

export const PedagogicalGuide: React.FC<PedagogicalGuideProps> = ({
  currentStepIndex,
  onStepChange,
  onApplyStepPreset,
}) => {
  const [showAnswer, setShowAnswer] = useState(false);
  const step = PEDAGOGICAL_STEPS[currentStepIndex];

  const handleNext = () => {
    if (currentStepIndex < PEDAGOGICAL_STEPS.length - 1) {
      const nextIdx = currentStepIndex + 1;
      onStepChange(nextIdx);
      setShowAnswer(false);
      onApplyStepPreset(PEDAGOGICAL_STEPS[nextIdx].id);
    }
  };

  const handlePrev = () => {
    if (currentStepIndex > 0) {
      const prevIdx = currentStepIndex - 1;
      onStepChange(prevIdx);
      setShowAnswer(false);
      onApplyStepPreset(PEDAGOGICAL_STEPS[prevIdx].id);
    }
  };

  const handleSelectStep = (idx: number) => {
    onStepChange(idx);
    setShowAnswer(false);
    onApplyStepPreset(PEDAGOGICAL_STEPS[idx].id);
  };

  return (
    <div
      id="pedagogical-guide-card"
      className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden flex flex-col"
    >
      {/* Step Navigator Header */}
      <div className="p-4 border-b border-slate-100 bg-gradient-to-r from-slate-50 via-sky-50/30 to-indigo-50/20 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-sky-600 text-white flex items-center justify-center font-bold text-xs shadow-xs">
            {step.number}
          </div>
          <div>
            <span className="text-[11px] font-semibold text-sky-700 uppercase tracking-wider block">
              Paso {step.number} de {PEDAGOGICAL_STEPS.length}
            </span>
            <h2 className="text-base font-bold text-slate-800 tracking-tight leading-snug">
              {step.title}
            </h2>
          </div>
        </div>

        {/* Step dots */}
        <div className="flex items-center gap-1.5">
          {PEDAGOGICAL_STEPS.map((s, idx) => (
            <button
              key={s.id}
              id={`step-indicator-${s.id}`}
              onClick={() => handleSelectStep(idx)}
              className={`transition-all rounded-full ${
                idx === currentStepIndex
                  ? 'w-6 h-2 bg-sky-600'
                  : 'w-2 h-2 bg-slate-200 hover:bg-slate-300'
              }`}
              title={`Ir al paso ${s.number}: ${s.title}`}
            />
          ))}
        </div>
      </div>

      {/* Step Body Content */}
      <div className="p-5 space-y-4 flex-1 overflow-y-auto max-h-[460px]">
        {/* Short Concept Intro */}
        <div className="p-3 bg-sky-50/50 rounded-xl border border-sky-100/80 text-sky-900 text-xs font-medium leading-relaxed">
          {step.shortDesc}
        </div>

        {/* Full Explanation */}
        <p className="text-slate-700 text-xs sm:text-sm leading-relaxed whitespace-pre-line">
          {step.fullExplanation}
        </p>

        {/* Formula Box if available */}
        {step.mathFormula && (
          <div className="p-3.5 bg-slate-900 text-slate-100 rounded-xl font-mono text-xs overflow-x-auto shadow-inner border border-slate-800 flex items-center justify-between gap-2">
            <span className="text-sky-300 select-all">{step.mathFormula}</span>
            <span className="text-[10px] text-slate-400 uppercase tracking-wider px-2 py-0.5 rounded bg-slate-800">
              Formulación
            </span>
          </div>
        )}

        {/* Didactic Reflective Question Box */}
        <div className="mt-4 p-4 rounded-xl bg-amber-50/70 border border-amber-200/80">
          <div className="flex items-start gap-2.5">
            <HelpCircle className="w-4 h-4 text-amber-600 mt-0.5 shrink-0" />
            <div className="space-y-2 flex-1">
              <span className="text-xs font-bold text-amber-950 block">
                Pregunta Didáctica: {step.didacticQuestion}
              </span>

              {showAnswer ? (
                <div className="pt-2 border-t border-amber-200/60 text-xs text-amber-900 leading-relaxed animate-in fade-in duration-200">
                  <div className="font-semibold flex items-center gap-1 text-emerald-800 mb-1">
                    <Lightbulb className="w-3.5 h-3.5 text-emerald-600" />
                    Respuesta Pedagógica:
                  </div>
                  {step.didacticAnswer}
                </div>
              ) : (
                <button
                  id="btn-reveal-answer"
                  onClick={() => setShowAnswer(true)}
                  className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-700 hover:text-amber-900 hover:underline pt-1"
                >
                  <Lightbulb className="w-3.5 h-3.5" />
                  Descubrir la respuesta intuitiva
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Footer Navigation Bar */}
      <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between gap-2">
        <button
          id="btn-prev-step"
          onClick={handlePrev}
          disabled={currentStepIndex === 0}
          className={`px-3 py-2 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-colors ${
            currentStepIndex === 0
              ? 'opacity-40 cursor-not-allowed text-slate-400'
              : 'text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 shadow-xs'
          }`}
        >
          <ChevronLeft className="w-4 h-4" />
          Paso Anterior
        </button>

        <span className="text-xs text-slate-500 font-medium hidden sm:inline">
          {currentStepIndex + 1} de {PEDAGOGICAL_STEPS.length}
        </span>

        {currentStepIndex < PEDAGOGICAL_STEPS.length - 1 ? (
          <button
            id="btn-next-step"
            onClick={handleNext}
            className="px-4 py-2 rounded-xl text-xs font-medium bg-sky-600 hover:bg-sky-700 text-white flex items-center gap-1.5 shadow-xs transition-colors"
          >
            Siguiente Paso
            <ChevronRight className="w-4 h-4" />
          </button>
        ) : (
          <button
            id="btn-restart-guide"
            onClick={() => handleSelectStep(0)}
            className="px-4 py-2 rounded-xl text-xs font-medium bg-emerald-600 hover:bg-emerald-700 text-white flex items-center gap-1.5 shadow-xs transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5" />
            Reiniciar Guía
          </button>
        )}
      </div>
    </div>
  );
};
