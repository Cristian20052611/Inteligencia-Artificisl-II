import React from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  RefreshCw,
  Sliders,
  Eye,
  SlidersHorizontal,
  Compass,
} from 'lucide-react';

interface ControlPanelProps {
  morphProgress: number;
  onMorphChange: (val: number) => void;
  isAnimating: boolean;
  onToggleAnimate: () => void;
  showAxes: boolean;
  onToggleAxes: () => void;
  showPlane: boolean;
  onTogglePlane: () => void;
  showResiduals: boolean;
  onToggleResiduals: () => void;
  showCentroid: boolean;
  onToggleCentroid: () => void;
  pointCount: number;
  onPointCountChange: (count: number) => void;
  noiseLevel: number;
  onNoiseChange: (noise: number) => void;
  turns: number;
  onTurnsChange: (turns: number) => void;
  onRegenerateData: () => void;
}

export const ControlPanel: React.FC<ControlPanelProps> = ({
  morphProgress,
  onMorphChange,
  isAnimating,
  onToggleAnimate,
  showAxes,
  onToggleAxes,
  showPlane,
  onTogglePlane,
  showResiduals,
  onToggleResiduals,
  showCentroid,
  onToggleCentroid,
  pointCount,
  onPointCountChange,
  noiseLevel,
  onNoiseChange,
  turns,
  onTurnsChange,
  onRegenerateData,
}) => {
  return (
    <div
      id="main-control-panel"
      className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-4 space-y-4"
    >
      {/* 1. Proyección & Morphing Section */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5 uppercase tracking-wide">
            <Compass className="w-3.5 h-3.5 text-sky-600" />
            Transición Dimensional: 3D → Proyección 2D
          </label>
          <span className="text-xs font-mono font-semibold text-sky-700 bg-sky-50 px-2 py-0.5 rounded-md border border-sky-100">
            {(morphProgress * 100).toFixed(0)}%
          </span>
        </div>

        {/* Morph Slider & Play Controls */}
        <div className="flex items-center gap-3">
          <button
            id="btn-play-projection"
            onClick={onToggleAnimate}
            className={`p-2 rounded-xl text-white transition-all shadow-xs flex items-center justify-center shrink-0 ${
              isAnimating
                ? 'bg-amber-600 hover:bg-amber-700'
                : 'bg-sky-600 hover:bg-sky-700'
            }`}
            title={isAnimating ? 'Pausar animación' : 'Reproducir animación de aplastamiento 3D a 2D'}
          >
            {isAnimating ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 translate-x-0.5" />}
          </button>

          <input
            id="slider-morph-progress"
            type="range"
            min={0}
            max={1}
            step={0.01}
            value={morphProgress}
            onChange={(e) => onMorphChange(parseFloat(e.target.value))}
            className="flex-1 accent-sky-600 h-2 bg-slate-100 rounded-lg cursor-pointer"
          />

          <div className="flex gap-1 shrink-0">
            <button
              id="btn-morph-0"
              onClick={() => onMorphChange(0)}
              className={`px-2 py-1 text-[11px] font-medium rounded-lg border transition-all ${
                morphProgress === 0
                  ? 'bg-slate-900 text-white border-slate-900'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border-slate-200'
              }`}
            >
              3D (0%)
            </button>
            <button
              id="btn-morph-1"
              onClick={() => onMorphChange(1)}
              className={`px-2 py-1 text-[11px] font-medium rounded-lg border transition-all ${
                morphProgress === 1
                  ? 'bg-sky-600 text-white border-sky-600'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border-slate-200'
              }`}
            >
              2D (100%)
            </button>
          </div>
        </div>
      </div>

      <hr className="border-slate-100" />

      {/* 2. Visual Elements Toggles */}
      <div>
        <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-2">
          Elementos Visuales en el Espacio 3D
        </span>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          <label className="flex items-center gap-2 p-2 rounded-xl bg-slate-50 hover:bg-slate-100/80 cursor-pointer border border-slate-200/60 transition-colors">
            <input
              id="toggle-axes"
              type="checkbox"
              checked={showAxes}
              onChange={onToggleAxes}
              className="accent-sky-600 rounded"
            />
            <span className="text-xs font-medium text-slate-700">Ejes PCA</span>
          </label>

          <label className="flex items-center gap-2 p-2 rounded-xl bg-slate-50 hover:bg-slate-100/80 cursor-pointer border border-slate-200/60 transition-colors">
            <input
              id="toggle-plane"
              type="checkbox"
              checked={showPlane}
              onChange={onTogglePlane}
              className="accent-sky-600 rounded"
            />
            <span className="text-xs font-medium text-slate-700">Plano 2D</span>
          </label>

          <label className="flex items-center gap-2 p-2 rounded-xl bg-slate-50 hover:bg-slate-100/80 cursor-pointer border border-slate-200/60 transition-colors">
            <input
              id="toggle-residuals"
              type="checkbox"
              checked={showResiduals}
              onChange={onToggleResiduals}
              className="accent-sky-600 rounded"
            />
            <span className="text-xs font-medium text-slate-700">Líneas de Error</span>
          </label>

          <label className="flex items-center gap-2 p-2 rounded-xl bg-slate-50 hover:bg-slate-100/80 cursor-pointer border border-slate-200/60 transition-colors">
            <input
              id="toggle-centroid"
              type="checkbox"
              checked={showCentroid}
              onChange={onToggleCentroid}
              className="accent-sky-600 rounded"
            />
            <span className="text-xs font-medium text-slate-700">Centroide μ</span>
          </label>
        </div>
      </div>

      <hr className="border-slate-100" />

      {/* 3. Dataset Parameters (Points, Noise, Turns) */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
            Parámetros del Swiss Roll
          </span>
          <button
            id="btn-regenerate-data"
            onClick={onRegenerateData}
            className="inline-flex items-center gap-1 text-xs text-sky-600 hover:text-sky-700 font-medium active:scale-95"
          >
            <RefreshCw className="w-3 h-3" />
            Regenerar Puntos
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          {/* Points */}
          <div className="space-y-1">
            <div className="flex justify-between text-slate-600 font-medium">
              <span>Muestras (N):</span>
              <span className="font-mono">{pointCount}</span>
            </div>
            <input
              id="slider-point-count"
              type="range"
              min={250}
              max={1200}
              step={50}
              value={pointCount}
              onChange={(e) => onPointCountChange(parseInt(e.target.value))}
              className="w-full accent-slate-800 h-1.5 bg-slate-100 rounded-lg cursor-pointer"
            />
          </div>

          {/* Noise */}
          <div className="space-y-1">
            <div className="flex justify-between text-slate-600 font-medium">
              <span>Ruido (σ):</span>
              <span className="font-mono">{noiseLevel.toFixed(2)}</span>
            </div>
            <input
              id="slider-noise-level"
              type="range"
              min={0}
              max={0.35}
              step={0.02}
              value={noiseLevel}
              onChange={(e) => onNoiseChange(parseFloat(e.target.value))}
              className="w-full accent-slate-800 h-1.5 bg-slate-100 rounded-lg cursor-pointer"
            />
          </div>

          {/* Turns */}
          <div className="space-y-1">
            <div className="flex justify-between text-slate-600 font-medium">
              <span>Vueltas espiral:</span>
              <span className="font-mono">{turns.toFixed(1)}</span>
            </div>
            <input
              id="slider-turns"
              type="range"
              min={1.2}
              max={3.0}
              step={0.1}
              value={turns}
              onChange={(e) => onTurnsChange(parseFloat(e.target.value))}
              className="w-full accent-slate-800 h-1.5 bg-slate-100 rounded-lg cursor-pointer"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
