import React, { useMemo, useState } from 'react';
import { PCAResult } from '../types';
import { getSwissRollColor } from '../utils/math';
import { ArrowUpDown, HelpCircle, Sparkles, CheckCircle2 } from 'lucide-react';

interface Scatter2DProps {
  pcaData: PCAResult;
  selectedPointId: number | null;
  onSelectPoint: (id: number | null) => void;
  viewMode: 'pca' | 'unrolled';
  onToggleViewMode: (mode: 'pca' | 'unrolled') => void;
}

export const Scatter2D: React.FC<Scatter2DProps> = ({
  pcaData,
  selectedPointId,
  onSelectPoint,
  viewMode,
  onToggleViewMode,
}) => {
  const [hoveredPointId, setHoveredPointId] = useState<number | null>(null);

  // Compute ranges for SVG coordinates
  const bounds = useMemo(() => {
    let minX = Infinity,
      maxX = -Infinity,
      minY = Infinity,
      maxY = -Infinity;

    pcaData.points.forEach((pt) => {
      const xVal = viewMode === 'pca' ? pt.pc1 : pt.t;
      const yVal = viewMode === 'pca' ? pt.pc2 : pt.y;
      if (xVal < minX) minX = xVal;
      if (xVal > maxX) maxX = xVal;
      if (yVal < minY) minY = yVal;
      if (yVal > maxY) maxY = yVal;
    });

    const padX = (maxX - minX) * 0.08 || 1;
    const padY = (maxY - minY) * 0.08 || 1;

    return {
      minX: minX - padX,
      maxX: maxX + padX,
      minY: minY - padY,
      maxY: maxY + padY,
    };
  }, [pcaData, viewMode]);

  // SVG dimensions
  const svgWidth = 520;
  const svgHeight = 440;
  const padding = 54;

  const scaleX = (val: number) => {
    return padding + ((val - bounds.minX) / (bounds.maxX - bounds.minX)) * (svgWidth - 2 * padding);
  };

  const scaleY = (val: number) => {
    // Invert for SVG
    return (
      svgHeight -
      padding -
      ((val - bounds.minY) / (bounds.maxY - bounds.minY)) * (svgHeight - 2 * padding)
    );
  };

  const zeroX = scaleX(0);
  const zeroY = scaleY(0);

  const activeId = hoveredPointId !== null ? hoveredPointId : selectedPointId;
  const activePt = pcaData.points.find((p) => p.id === activeId);

  return (
    <div id="scatter-2d-container" className="flex flex-col h-full bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
      {/* Header with Mode Switcher */}
      <div className="p-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-slate-50/50">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-bold text-slate-800 tracking-tight">
              {viewMode === 'pca' ? 'Espacio Proyectado 2D de PCA' : 'Desenrollado Manifold Ideal (No Lineal)'}
            </h3>
            {viewMode === 'pca' ? (
              <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-amber-50 text-amber-700 border border-amber-200/70">
                Proyección Lineal
              </span>
            ) : (
              <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200/70 flex items-center gap-1">
                <Sparkles className="w-3 h-3" /> Geodésico
              </span>
            )}
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            {viewMode === 'pca'
              ? 'PC1 vs PC2: Observa la superposición de capas y pérdida de la estructura espiral.'
              : 'Coordenadas intrínsecas (Arco t vs Ancho): La variedad desenrollada como una hoja plana sin solapamientos.'}
          </p>
        </div>

        {/* Toggle Switch */}
        <div id="projection-mode-toggle" className="inline-flex rounded-xl bg-slate-100 p-1 border border-slate-200/80 text-xs">
          <button
            id="btn-toggle-pca"
            onClick={() => onToggleViewMode('pca')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              viewMode === 'pca'
                ? 'bg-white text-slate-800 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            PCA (PC1 vs PC2)
          </button>
          <button
            id="btn-toggle-unrolled"
            onClick={() => onToggleViewMode('unrolled')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              viewMode === 'unrolled'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Desenrollado Ideal
          </button>
        </div>
      </div>

      {/* SVG Scatter Plot */}
      <div className="relative flex-1 flex items-center justify-center p-2 bg-slate-50/30">
        <svg
          viewBox={`0 0 ${svgWidth} ${svgHeight}`}
          className="w-full h-full max-h-[460px] select-none"
        >
          {/* Subtle Grid Lines */}
          <g stroke="#f1f5f9" strokeWidth="1">
            {[0.2, 0.4, 0.6, 0.8].map((ratio) => {
              const xPos = padding + ratio * (svgWidth - 2 * padding);
              const yPos = padding + ratio * (svgHeight - 2 * padding);
              return (
                <React.Fragment key={ratio}>
                  <line x1={xPos} y1={padding} x2={xPos} y2={svgHeight - padding} />
                  <line x1={padding} y1={yPos} x2={svgWidth - padding} y2={yPos} />
                </React.Fragment>
              );
            })}
          </g>

          {/* Zero axes if within bounds (useful in PCA space) */}
          {viewMode === 'pca' && zeroX >= padding && zeroX <= svgWidth - padding && (
            <line
              x1={zeroX}
              y1={padding}
              x2={zeroX}
              y2={svgHeight - padding}
              stroke="#cbd5e1"
              strokeDasharray="4 4"
              strokeWidth="1.2"
            />
          )}
          {viewMode === 'pca' && zeroY >= padding && zeroY <= svgHeight - padding && (
            <line
              x1={padding}
              y1={zeroY}
              x2={svgWidth - padding}
              y2={zeroY}
              stroke="#cbd5e1"
              strokeDasharray="4 4"
              strokeWidth="1.2"
            />
          )}

          {/* Axes Base Frame */}
          <line
            x1={padding}
            y1={svgHeight - padding}
            x2={svgWidth - padding}
            y2={svgHeight - padding}
            stroke="#94a3b8"
            strokeWidth="1.5"
          />
          <line
            x1={padding}
            y1={padding}
            x2={padding}
            y2={svgHeight - padding}
            stroke="#94a3b8"
            strokeWidth="1.5"
          />

          {/* Scatter Points */}
          {pcaData.points.map((pt) => {
            const cx = scaleX(viewMode === 'pca' ? pt.pc1 : pt.t);
            const cy = scaleY(viewMode === 'pca' ? pt.pc2 : pt.y);
            const isSelected = activeId === pt.id;
            const color = getSwissRollColor(pt.colorValue);

            return (
              <circle
                key={pt.id}
                cx={cx}
                cy={cy}
                r={isSelected ? 6.5 : 3.8}
                fill={color}
                stroke={isSelected ? '#0f172a' : '#ffffff'}
                strokeWidth={isSelected ? 2 : 0.6}
                opacity={activeId !== null && !isSelected ? 0.35 : 0.9}
                className="cursor-pointer transition-all hover:scale-125"
                onMouseEnter={() => setHoveredPointId(pt.id)}
                onMouseLeave={() => setHoveredPointId(null)}
                onClick={() => onSelectPoint(pt.id)}
              />
            );
          })}

          {/* Axis Labels */}
          {/* X Axis */}
          <text
            x={svgWidth / 2}
            y={svgHeight - 16}
            textAnchor="middle"
            className="text-xs font-semibold fill-slate-700"
          >
            {viewMode === 'pca'
              ? `Componente Principal 1 (PC1) — ${(pcaData.explainedVarianceRatio[0] * 100).toFixed(1)}% Varianza`
              : 'Coordenada Geodésica t (Longitud de la Espiral) — Sin solapamiento'}
          </text>

          {/* Y Axis */}
          <text
            x={-(svgHeight / 2)}
            y={18}
            transform="rotate(-90)"
            textAnchor="middle"
            className="text-xs font-semibold fill-slate-700"
          >
            {viewMode === 'pca'
              ? `Componente Principal 2 (PC2) — ${(pcaData.explainedVarianceRatio[1] * 100).toFixed(1)}% Varianza`
              : 'Coordenada y (Ancho del Cilindro)'}
          </text>

          {/* Tick values */}
          <text x={padding} y={svgHeight - padding + 18} textAnchor="middle" className="text-[10px] fill-slate-400 font-mono">
            {bounds.minX.toFixed(1)}
          </text>
          <text x={svgWidth - padding} y={svgHeight - padding + 18} textAnchor="middle" className="text-[10px] fill-slate-400 font-mono">
            {bounds.maxX.toFixed(1)}
          </text>
          <text x={padding - 8} y={svgHeight - padding} textAnchor="end" dominantBaseline="middle" className="text-[10px] fill-slate-400 font-mono">
            {bounds.minY.toFixed(1)}
          </text>
          <text x={padding - 8} y={padding} textAnchor="end" dominantBaseline="middle" className="text-[10px] fill-slate-400 font-mono">
            {bounds.maxY.toFixed(1)}
          </text>
        </svg>

        {/* Didactic Notice Ribbon */}
        {viewMode === 'pca' ? (
          <div className="absolute bottom-14 right-4 max-w-[210px] bg-amber-50/90 backdrop-blur-xs border border-amber-200 p-2.5 rounded-xl text-[11px] text-amber-900 leading-snug shadow-xs pointer-events-none">
            <div className="font-semibold flex items-center gap-1 mb-0.5">
              <HelpCircle className="w-3.5 h-3.5 text-amber-600" />
              ¿Por qué se mezclan?
            </div>
            PCA proyecta en línea recta. Las capas exterior (roja) e interior (azul) caen en las mismas coordenadas 2D.
          </div>
        ) : (
          <div className="absolute bottom-14 right-4 max-w-[210px] bg-emerald-50/90 backdrop-blur-xs border border-emerald-200 p-2.5 rounded-xl text-[11px] text-emerald-900 leading-snug shadow-xs pointer-events-none">
            <div className="font-semibold flex items-center gap-1 mb-0.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              Estructura Preservada
            </div>
            Al desenrollar a lo largo del arco intrínseco, los puntos vecinos en la superficie siguen siendo vecinos en 2D.
          </div>
        )}
      </div>

      {/* Footer Info on active point */}
      <div className="px-4 py-2.5 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
        <div>
          {activePt ? (
            <span className="font-medium text-slate-800">
              Punto #{activePt.id}: {viewMode === 'pca' ? `PC1=${activePt.pc1.toFixed(2)}, PC2=${activePt.pc2.toFixed(2)}` : `Arco t=${activePt.t.toFixed(2)}, y=${activePt.y.toFixed(2)}`}
            </span>
          ) : (
            <span className="text-slate-400">Pasa el cursor o haz clic en cualquier punto para sincronizar con 3D</span>
          )}
        </div>
        <div className="text-[11px] text-slate-500 font-mono">
          Total Varianza Retenida: {((pcaData.explainedVarianceRatio[0] + pcaData.explainedVarianceRatio[1]) * 100).toFixed(1)}%
        </div>
      </div>
    </div>
  );
};
