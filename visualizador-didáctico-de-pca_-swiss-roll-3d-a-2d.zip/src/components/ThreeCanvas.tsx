import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { PCAResult } from '../types';
import { getSwissRollColor } from '../utils/math';
import { Eye, RotateCcw, Maximize2, Layers } from 'lucide-react';

interface ThreeCanvasProps {
  pcaData: PCAResult;
  morphProgress: number; // 0 (original 3D) to 1 (projected on 2D plane)
  showAxes: boolean;
  showPlane: boolean;
  showResiduals: boolean;
  showCentroid: boolean;
  selectedPointId: number | null;
  onSelectPoint: (id: number | null) => void;
}

export const ThreeCanvas: React.FC<ThreeCanvasProps> = ({
  pcaData,
  morphProgress,
  showAxes,
  showPlane,
  showResiduals,
  showCentroid,
  selectedPointId,
  onSelectPoint,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);

  // Object group references for dynamic updates
  const pointsMeshRef = useRef<THREE.InstancedMesh | null>(null);
  const highlightMeshRef = useRef<THREE.Mesh | null>(null);
  const axesGroupRef = useRef<THREE.Group | null>(null);
  const planeMeshRef = useRef<THREE.Mesh | null>(null);
  const linesSegmentsRef = useRef<THREE.LineSegments | null>(null);
  const centroidMeshRef = useRef<THREE.Mesh | null>(null);

  const [hoveredPointId, setHoveredPointId] = useState<number | null>(null);
  const raycasterRef = useRef<THREE.Raycaster>(new THREE.Raycaster());
  const mouseRef = useRef<THREE.Vector2>(new THREE.Vector2(-1000, -1000));
  const dummyMatrixRef = useRef<THREE.Matrix4>(new THREE.Matrix4());
  const dummyPosRef = useRef<THREE.Vector3>(new THREE.Vector3());

  // Setup Three.js scene once
  useEffect(() => {
    if (!mountRef.current) return;
    const container = mountRef.current;
    const width = container.clientWidth;
    const height = container.clientHeight;

    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(0xf8fafc); // Clean neutral slate-50 background

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(28, 22, 34);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.maxDistance = 150;
    controls.minDistance = 5;
    controlsRef.current = controls;

    // Ambient and directional lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.9);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0xffffff, 0.7);
    dirLight1.position.set(30, 40, 30);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0xffffff, 0.4);
    dirLight2.position.set(-30, -20, -30);
    scene.add(dirLight2);

    // Subtle soft grid floor for 3D depth perception
    const grid = new THREE.GridHelper(50, 25, 0xcfd8dc, 0xe2e8f0);
    grid.position.y = -15;
    scene.add(grid);

    // Create highlight ring mesh for hovered/selected point
    const ringGeo = new THREE.SphereGeometry(0.55, 16, 16);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0x0f172a,
      wireframe: true,
      transparent: true,
      opacity: 0.85,
    });
    const highlightMesh = new THREE.Mesh(ringGeo, ringMat);
    highlightMesh.visible = false;
    scene.add(highlightMesh);
    highlightMeshRef.current = highlightMesh;

    // Animation Loop
    let animationFrameId: number;
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    // Resize observer
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width: newW, height: newH } = entry.contentRect;
        if (newW > 0 && newH > 0) {
          camera.aspect = newW / newH;
          camera.updateProjectionMatrix();
          renderer.setSize(newW, newH);
        }
      }
    });
    resizeObserver.observe(container);

    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
      renderer.dispose();
      container.innerHTML = '';
    };
  }, []);

  // Update Points Geometry & Colors when data changes
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    // Remove old mesh if exists
    if (pointsMeshRef.current) {
      scene.remove(pointsMeshRef.current);
      pointsMeshRef.current.geometry.dispose();
      (pointsMeshRef.current.material as THREE.Material).dispose();
      pointsMeshRef.current = null;
    }

    const count = pcaData.points.length;
    const pointGeo = new THREE.SphereGeometry(0.32, 16, 16);
    const pointMat = new THREE.MeshStandardMaterial({
      roughness: 0.35,
      metalness: 0.1,
    });

    const instancedMesh = new THREE.InstancedMesh(pointGeo, pointMat, count);
    instancedMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);

    const dummy = dummyMatrixRef.current;
    const pos = dummyPosRef.current;

    pcaData.points.forEach((pt, i) => {
      // Interpolate between original and projected based on morphProgress
      pos.x = pt.x + (pt.projX - pt.x) * morphProgress;
      pos.y = pt.y + (pt.projY - pt.y) * morphProgress;
      pos.z = pt.z + (pt.projZ - pt.z) * morphProgress;

      dummy.identity();
      dummy.setPosition(pos);
      instancedMesh.setMatrixAt(i, dummy);

      const colStr = getSwissRollColor(pt.colorValue);
      const color = new THREE.Color(colStr);
      instancedMesh.setColorAt(i, color);
    });

    if (instancedMesh.instanceColor) {
      instancedMesh.instanceColor.needsUpdate = true;
    }
    instancedMesh.instanceMatrix.needsUpdate = true;

    scene.add(instancedMesh);
    pointsMeshRef.current = instancedMesh;
  }, [pcaData]);

  // Update positions when morphProgress changes
  useEffect(() => {
    if (!pointsMeshRef.current) return;
    const mesh = pointsMeshRef.current;
    const dummy = dummyMatrixRef.current;
    const pos = dummyPosRef.current;

    pcaData.points.forEach((pt, i) => {
      pos.x = pt.x + (pt.projX - pt.x) * morphProgress;
      pos.y = pt.y + (pt.projY - pt.y) * morphProgress;
      pos.z = pt.z + (pt.projZ - pt.z) * morphProgress;

      dummy.identity();
      dummy.setPosition(pos);
      mesh.setMatrixAt(i, dummy);
    });

    mesh.instanceMatrix.needsUpdate = true;
  }, [morphProgress, pcaData]);

  // Update Centroid Marker
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    if (centroidMeshRef.current) {
      scene.remove(centroidMeshRef.current);
      centroidMeshRef.current.geometry.dispose();
      (centroidMeshRef.current.material as THREE.Material).dispose();
      centroidMeshRef.current = null;
    }

    if (showCentroid) {
      const geo = new THREE.SphereGeometry(0.7, 16, 16);
      const mat = new THREE.MeshBasicMaterial({
        color: 0x0f172a, // dark slate
      });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(pcaData.mean[0], pcaData.mean[1], pcaData.mean[2]);
      scene.add(mesh);
      centroidMeshRef.current = mesh;
    }
  }, [pcaData.mean, showCentroid]);

  // Update PCA Axes (PC1, PC2, PC3 arrows)
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    if (axesGroupRef.current) {
      scene.remove(axesGroupRef.current);
      axesGroupRef.current.clear();
      axesGroupRef.current = null;
    }

    if (!showAxes) return;

    const group = new THREE.Group();
    const origin = new THREE.Vector3(pcaData.mean[0], pcaData.mean[1], pcaData.mean[2]);

    // Scale arrow lengths by square root of eigenvalue (standard deviation)
    const totalStd = Math.sqrt(pcaData.totalVariance);
    const scaleFactor = 16 / Math.max(1, totalStd);

    // PC1: Emerald / Coral
    const dir1 = new THREE.Vector3(...pcaData.eigenvectors[0]).normalize();
    const len1 = Math.max(6, Math.sqrt(pcaData.eigenvalues[0]) * scaleFactor);
    const arrow1 = new THREE.ArrowHelper(dir1, origin, len1, 0xef4444, 1.2, 0.6);
    group.add(arrow1);

    // Negative direction for bidirectional axis
    const negArrow1 = new THREE.ArrowHelper(dir1.clone().negate(), origin, len1, 0xfca5a5, 0.8, 0.4);
    group.add(negArrow1);

    // PC2: Cyan / Blue
    const dir2 = new THREE.Vector3(...pcaData.eigenvectors[1]).normalize();
    const len2 = Math.max(5, Math.sqrt(pcaData.eigenvalues[1]) * scaleFactor);
    const arrow2 = new THREE.ArrowHelper(dir2, origin, len2, 0x0284c7, 1.2, 0.6);
    group.add(arrow2);

    const negArrow2 = new THREE.ArrowHelper(dir2.clone().negate(), origin, len2, 0x7dd3fc, 0.8, 0.4);
    group.add(negArrow2);

    // PC3: Violet (The discarded axis)
    const dir3 = new THREE.Vector3(...pcaData.eigenvectors[2]).normalize();
    const len3 = Math.max(4, Math.sqrt(pcaData.eigenvalues[2]) * scaleFactor);
    const arrow3 = new THREE.ArrowHelper(dir3, origin, len3, 0x8b5cf6, 1.2, 0.6);
    group.add(arrow3);

    const negArrow3 = new THREE.ArrowHelper(dir3.clone().negate(), origin, len3, 0xc4b5fd, 0.8, 0.4);
    group.add(negArrow3);

    scene.add(group);
    axesGroupRef.current = group;
  }, [pcaData, showAxes]);

  // Update 2D Projection Hyperplane
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    if (planeMeshRef.current) {
      scene.remove(planeMeshRef.current);
      planeMeshRef.current.geometry.dispose();
      (planeMeshRef.current.material as THREE.Material).dispose();
      planeMeshRef.current = null;
    }

    if (!showPlane) return;

    // Plane defined by PC1 and PC2 span
    const width = 42;
    const height = 42;
    const planeGeo = new THREE.PlaneGeometry(width, height, 14, 14);

    const planeMat = new THREE.MeshStandardMaterial({
      color: 0x3b82f6,
      transparent: true,
      opacity: 0.15,
      side: THREE.DoubleSide,
      wireframe: false,
      roughness: 0.8,
    });

    const planeMesh = new THREE.Mesh(planeGeo, planeMat);
    planeMesh.position.set(pcaData.mean[0], pcaData.mean[1], pcaData.mean[2]);

    // Align plane normal with PC3 (normal vector of the plane spanned by PC1 and PC2)
    const normal = new THREE.Vector3(...pcaData.eigenvectors[2]).normalize();
    planeMesh.lookAt(
      pcaData.mean[0] + normal.x,
      pcaData.mean[1] + normal.y,
      pcaData.mean[2] + normal.z
    );

    // Add wireframe outline to plane for clear borders
    const edges = new THREE.EdgesGeometry(planeGeo);
    const lineMat = new THREE.LineBasicMaterial({
      color: 0x2563eb,
      transparent: true,
      opacity: 0.45,
    });
    const wireframe = new THREE.LineSegments(edges, lineMat);
    planeMesh.add(wireframe);

    scene.add(planeMesh);
    planeMeshRef.current = planeMesh;
  }, [pcaData, showPlane]);

  // Update Residual / Projection Lines
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    if (linesSegmentsRef.current) {
      scene.remove(linesSegmentsRef.current);
      linesSegmentsRef.current.geometry.dispose();
      (linesSegmentsRef.current.material as THREE.Material).dispose();
      linesSegmentsRef.current = null;
    }

    if (!showResiduals) return;

    // Show projection lines between original 3D point and projected plane
    // We sample a subset (or all if < 600) to keep render super sharp
    const subset = pcaData.points.filter((_, idx) => idx % 2 === 0);
    const linePositions = new Float32Array(subset.length * 6);

    subset.forEach((pt, i) => {
      const idx = i * 6;
      // Start at 3D point
      linePositions[idx] = pt.x;
      linePositions[idx + 1] = pt.y;
      linePositions[idx + 2] = pt.z;
      // End at projected plane point
      linePositions[idx + 3] = pt.projX;
      linePositions[idx + 4] = pt.projY;
      linePositions[idx + 5] = pt.projZ;
    });

    const lineGeo = new THREE.BufferGeometry();
    lineGeo.setAttribute('position', new THREE.BufferAttribute(linePositions, 3));

    const lineMat = new THREE.LineBasicMaterial({
      color: 0x94a3b8, // slate-400
      transparent: true,
      opacity: 0.4,
    });

    const lineSegments = new THREE.LineSegments(lineGeo, lineMat);
    scene.add(lineSegments);
    linesSegmentsRef.current = lineSegments;
  }, [pcaData, showResiduals]);

  // Update Highlight of Selected/Hovered Point
  useEffect(() => {
    if (!highlightMeshRef.current) return;
    const mesh = highlightMeshRef.current;
    const activeId = hoveredPointId !== null ? hoveredPointId : selectedPointId;

    if (activeId === null) {
      mesh.visible = false;
      return;
    }

    const pt = pcaData.points.find((p) => p.id === activeId);
    if (!pt) {
      mesh.visible = false;
      return;
    }

    // Position at current morphed location
    const curX = pt.x + (pt.projX - pt.x) * morphProgress;
    const curY = pt.y + (pt.projY - pt.y) * morphProgress;
    const curZ = pt.z + (pt.projZ - pt.z) * morphProgress;

    mesh.position.set(curX, curY, curZ);
    mesh.visible = true;
  }, [hoveredPointId, selectedPointId, morphProgress, pcaData]);

  // Mouse interaction: Raycasting for hovering/clicking points
  const handlePointerMove = useCallback(
    (e: React.PointerEvent<HTMLDivElement>) => {
      if (!mountRef.current || !cameraRef.current || !pointsMeshRef.current) return;
      const rect = mountRef.current.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      mouseRef.current.set(x, y);

      raycasterRef.current.setFromCamera(mouseRef.current, cameraRef.current);
      const intersects = raycasterRef.current.intersectObject(pointsMeshRef.current);

      if (intersects.length > 0 && intersects[0].instanceId !== undefined) {
        const id = intersects[0].instanceId;
        setHoveredPointId(id);
      } else {
        setHoveredPointId(null);
      }
    },
    []
  );

  const handleClick = useCallback(() => {
    if (hoveredPointId !== null) {
      onSelectPoint(hoveredPointId);
    }
  }, [hoveredPointId, onSelectPoint]);

  // Camera presets
  const setCameraView = (view: 'iso' | 'perpendicular' | 'profile' | 'top') => {
    if (!cameraRef.current || !controlsRef.current) return;
    const cam = cameraRef.current;
    const ctr = controlsRef.current;
    const mx = pcaData.mean[0];
    const my = pcaData.mean[1];
    const mz = pcaData.mean[2];

    ctr.target.set(mx, my, mz);

    if (view === 'iso') {
      cam.position.set(mx + 26, my + 20, mz + 30);
    } else if (view === 'perpendicular') {
      // Look directly down PC3 (normal to the PC1-PC2 projection plane)
      const n = new THREE.Vector3(...pcaData.eigenvectors[2]).normalize();
      cam.position.set(mx + n.x * 45, my + n.y * 45, mz + n.z * 45);
    } else if (view === 'profile') {
      // Look parallel to the projection plane (along PC1 or PC2)
      const v1 = new THREE.Vector3(...pcaData.eigenvectors[0]).normalize();
      cam.position.set(mx + v1.x * 45, my + v1.y * 45, mz + v1.z * 45);
    } else if (view === 'top') {
      cam.position.set(mx, my + 50, mz);
    }
    ctr.update();
  };

  const activePoint = pcaData.points.find(
    (p) => p.id === (hoveredPointId !== null ? hoveredPointId : selectedPointId)
  );

  return (
    <div
      id="three-3d-viewport-container"
      className="relative w-full h-full min-h-[460px] bg-slate-50 overflow-hidden select-none border-b lg:border-b-0 lg:border-r border-slate-200"
      onPointerMove={handlePointerMove}
      onClick={handleClick}
    >
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Floating 3D Legend & Camera Toolbars */}
      <div
        id="camera-presets-bar"
        className="absolute top-3 left-3 flex flex-wrap items-center gap-1.5 bg-white/90 backdrop-blur-md px-2.5 py-1.5 rounded-xl shadow-xs border border-slate-200/80 text-xs font-medium text-slate-700"
      >
        <span className="text-slate-400 font-normal mr-1">Vistas:</span>
        <button
          id="btn-view-iso"
          onClick={() => setCameraView('iso')}
          className="px-2 py-1 rounded-md hover:bg-slate-100 transition-colors text-slate-700 active:scale-95"
          title="Vista 3D Libre Isométrica"
        >
          3D Libre
        </button>
        <button
          id="btn-view-perpendicular"
          onClick={() => setCameraView('perpendicular')}
          className="px-2 py-1 rounded-md bg-sky-50 text-sky-700 hover:bg-sky-100 transition-colors active:scale-95 flex items-center gap-1"
          title="Ver directamente de frente al plano de proyección (PC1 × PC2)"
        >
          <Eye className="w-3.5 h-3.5" />
          Frente al Plano (2D)
        </button>
        <button
          id="btn-view-profile"
          onClick={() => setCameraView('profile')}
          className="px-2 py-1 rounded-md hover:bg-slate-100 transition-colors text-slate-700 active:scale-95"
          title="Ver perfil del plano para notar el grosor descartado (PC3)"
        >
          Perfil (Grosor PC3)
        </button>
        <button
          id="btn-view-reset"
          onClick={() => setCameraView('iso')}
          className="p-1 rounded-md hover:bg-slate-100 text-slate-500"
          title="Resetear ángulo"
        >
          <RotateCcw className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* 3D Component Badges */}
      <div
        id="axes-3d-legend"
        className="absolute bottom-3 left-3 bg-white/90 backdrop-blur-md px-3 py-2 rounded-xl shadow-xs border border-slate-200/80 text-xs space-y-1"
      >
        <div className="font-semibold text-slate-800 text-[11px] uppercase tracking-wider mb-1 flex items-center gap-1.5">
          <Layers className="w-3 h-3 text-slate-500" /> Componentes Principales 3D
        </div>
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-red-500 inline-block shadow-xs"></span>
          <span className="font-medium text-slate-700">PC1:</span>
          <span className="text-slate-500">
            {(pcaData.explainedVarianceRatio[0] * 100).toFixed(1)}% Varianza (Eje Máximo)
          </span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-sky-600 inline-block shadow-xs"></span>
          <span className="font-medium text-slate-700">PC2:</span>
          <span className="text-slate-500">
            {(pcaData.explainedVarianceRatio[1] * 100).toFixed(1)}% Varianza (Eje Secundario)
          </span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-purple-500 inline-block shadow-xs"></span>
          <span className="font-medium text-slate-700">PC3:</span>
          <span className="text-slate-500">
            {(pcaData.explainedVarianceRatio[2] * 100).toFixed(1)}% Varianza (Eje Descartado)
          </span>
        </div>
      </div>

      {/* Point Hover / Inspection Card */}
      {activePoint && (
        <div
          id="point-tooltip-card"
          className="absolute top-3 right-3 bg-white/95 backdrop-blur-md p-3 rounded-xl shadow-md border border-slate-200 text-xs max-w-xs transition-all pointer-events-none"
        >
          <div className="flex items-center justify-between pb-1 border-b border-slate-100 mb-2">
            <span className="font-semibold text-slate-800 flex items-center gap-1.5">
              <span
                className="w-2.5 h-2.5 rounded-full"
                style={{ backgroundColor: getSwissRollColor(activePoint.colorValue) }}
              />
              Muestra #{activePoint.id}
            </span>
            <span className="text-[11px] text-slate-500">Arco t: {activePoint.t.toFixed(2)} rad</span>
          </div>
          <div className="space-y-1 text-slate-600 font-mono text-[11px]">
            <div>3D Original: ({activePoint.x.toFixed(1)}, {activePoint.y.toFixed(1)}, {activePoint.z.toFixed(1)})</div>
            <div className="text-sky-700 font-semibold">
              Proyección 2D: (PC1: {activePoint.pc1.toFixed(1)}, PC2: {activePoint.pc2.toFixed(1)})
            </div>
            <div className="text-slate-500">
              Residuo (Error dist): {activePoint.residualDist.toFixed(2)}
            </div>
          </div>
        </div>
      )}

      {/* Hint badge */}
      <div className="absolute bottom-3 right-3 hidden sm:block text-[11px] text-slate-600 bg-white/80 px-2 py-1 rounded-md border border-slate-200/60 pointer-events-none">
        Arrastra para rotar • Rueda para zoom • Clic derecho para desplazar
      </div>
    </div>
  );
};
