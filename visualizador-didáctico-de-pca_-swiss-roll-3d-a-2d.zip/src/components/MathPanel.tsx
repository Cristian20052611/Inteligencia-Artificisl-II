import React, { useState } from 'react';
import { PCAResult } from '../types';
import { Sigma, BarChart3, Binary, Table, Info } from 'lucide-react';

interface MathPanelProps {
  pcaData: PCAResult;
}

export const MathPanel: React.FC<MathPanelProps> = ({ pcaData }) => {
  const [activeTab, setActiveTab] = useState<'variance' | 'matrix' | 'vectors'>('variance');

  const {
    mean,
    covarianceMatrix,
    eigenvalues,
    eigenvectors,
    explainedVarianceRatio,
    totalVariance,
  } = pcaData;

  const cumVariance2D = (explainedVarianceRatio[0] + explainedVarianceRatio[1]) * 100;

  return (
    <div
      id="math-panel-container"
      className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden flex flex-col"
    >
      {/* Header Tabs */}
      <div className="p-3 border-b border-slate-100 bg-slate-50 flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800">
          <Sigma className="w-4 h-4 text-sky-600" />
          <span>Matemáticas y Métricas en Tiempo Real</span>
        </div>

        <div className="flex rounded-lg bg-slate-200/80 p-0.5 text-xs font-medium">
          <button
            id="tab-btn-variance"
            onClick={() => setActiveTab('variance')}
            className={`px-2.5 py-1 rounded-md transition-all ${
              activeTab === 'variance'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Varianza Explicada
          </button>
          <button
            id="tab-btn-matrix"
            onClick={() => setActiveTab('matrix')}
            className={`px-2.5 py-1 rounded-md transition-all ${
              activeTab === 'matrix'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Matriz de Covarianza
          </button>
          <button
            id="tab-btn-vectors"
            onClick={() => setActiveTab('vectors')}
            className={`px-2.5 py-1 rounded-md transition-all ${
              activeTab === 'vectors'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Autovectores (Ejes)
          </button>
        </div>
      </div>

      {/* Tab Content */}
      <div className="p-4 flex-1 overflow-y-auto">
        {/* TAB 1: EXPLAINED VARIANCE / SCREE PLOT */}
        {activeTab === 'variance' && (
          <div className="space-y-4 text-xs">
            {/* Cumulative Banner */}
            <div className="p-3 bg-sky-50 rounded-xl border border-sky-100 flex items-center justify-between">
              <div>
                <span className="font-semibold text-sky-950 block">
                  Información Retenida al Reducir a 2D (PC1 + PC2):
                </span>
                <span className="text-sky-700 text-[11px]">
                  Varianza Total Σλ = {totalVariance.toFixed(2)}
                </span>
              </div>
              <div className="text-right">
                <span className="text-xl font-extrabold text-sky-600 font-mono">
                  {cumVariance2D.toFixed(1)}%
                </span>
                <span className="text-[10px] text-slate-500 block">del total 3D</span>
              </div>
            </div>

            {/* Variance breakdown bars */}
            <div className="space-y-3">
              {/* PC1 */}
              <div>
                <div className="flex justify-between items-center mb-1 font-medium">
                  <span className="flex items-center gap-1.5 text-slate-800">
                    <span className="w-2.5 h-2.5 rounded-full bg-red-500"></span>
                    PC1 (Primer Componente):
                  </span>
                  <span className="font-mono text-slate-700">
                    {(explainedVarianceRatio[0] * 100).toFixed(1)}% (λ₁ = {eigenvalues[0].toFixed(2)})
                  </span>
                </div>
                <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-red-500 transition-all duration-500 rounded-full"
                    style={{ width: `${explainedVarianceRatio[0] * 100}%` }}
                  />
                </div>
              </div>

              {/* PC2 */}
              <div>
                <div className="flex justify-between items-center mb-1 font-medium">
                  <span className="flex items-center gap-1.5 text-slate-800">
                    <span className="w-2.5 h-2.5 rounded-full bg-sky-600"></span>
                    PC2 (Segundo Componente):
                  </span>
                  <span className="font-mono text-slate-700">
                    {(explainedVarianceRatio[1] * 100).toFixed(1)}% (λ₂ = {eigenvalues[1].toFixed(2)})
                  </span>
                </div>
                <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-sky-600 transition-all duration-500 rounded-full"
                    style={{ width: `${explainedVarianceRatio[1] * 100}%` }}
                  />
                </div>
              </div>

              {/* PC3 */}
              <div>
                <div className="flex justify-between items-center mb-1 font-medium text-slate-500">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-purple-500"></span>
                    PC3 (Descartado al pasar a 2D):
                  </span>
                  <span className="font-mono">
                    {(explainedVarianceRatio[2] * 100).toFixed(1)}% (λ₃ = {eigenvalues[2].toFixed(2)})
                  </span>
                </div>
                <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-purple-500 transition-all duration-500 rounded-full"
                    style={{ width: `${explainedVarianceRatio[2] * 100}%` }}
                  />
                </div>
              </div>
            </div>

            <p className="text-[11px] text-slate-500 leading-normal pt-1">
              <strong>Nota Pedagógica:</strong> Al descartar PC3, solo perdemos el{' '}
              {(explainedVarianceRatio[2] * 100).toFixed(1)}% de la varianza euclidiana. Sin embargo,
              esa pequeña varianza es crucial porque contenía la separación entre los rollos en el
              espacio tridimensional.
            </p>
          </div>
        )}

        {/* TAB 2: COVARIANCE MATRIX & CENTROID */}
        {activeTab === 'matrix' && (
          <div className="space-y-3 text-xs">
            <div>
              <span className="font-semibold text-slate-700 block mb-1">
                Vector Media (Centroide μ):
              </span>
              <div className="p-2 bg-slate-50 rounded-lg font-mono text-[11px] text-slate-800 border border-slate-200/80">
                μ = [ x̄: {mean[0].toFixed(2)}, ȳ: {mean[1].toFixed(2)}, z̄: {mean[2].toFixed(2)} ]
              </div>
            </div>

            <div>
              <span className="font-semibold text-slate-700 block mb-1">
                Matriz de Covarianza Muestral Σ (3 × 3):
              </span>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse font-mono text-[11px] text-center border border-slate-200">
                  <thead>
                    <tr className="bg-slate-100 text-slate-600">
                      <th className="p-1.5 border border-slate-200"></th>
                      <th className="p-1.5 border border-slate-200 font-semibold">X</th>
                      <th className="p-1.5 border border-slate-200 font-semibold">Y</th>
                      <th className="p-1.5 border border-slate-200 font-semibold">Z</th>
                    </tr>
                  </thead>
                  <tbody>
                    {['X', 'Y', 'Z'].map((rowLabel, r) => (
                      <tr key={rowLabel} className="hover:bg-slate-50">
                        <td className="p-1.5 bg-slate-100 font-semibold text-slate-600 border border-slate-200">
                          {rowLabel}
                        </td>
                        {covarianceMatrix[r].map((val, c) => (
                          <td
                            key={c}
                            className={`p-1.5 border border-slate-200 ${
                              r === c
                                ? 'bg-sky-50/80 font-bold text-sky-800'
                                : 'text-slate-700'
                            }`}
                            title={
                              r === c
                                ? `Varianza Var(${rowLabel})`
                                : `Covarianza Cov(${rowLabel}, ${['X', 'Y', 'Z'][c]})`
                            }
                          >
                            {val.toFixed(2)}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <span className="text-[10px] text-slate-400 mt-1 block">
                * Las celdas resaltadas en la diagonal representan las varianzas individuales Var(X), Var(Y), Var(Z).
              </span>
            </div>
          </div>
        )}

        {/* TAB 3: EIGENVECTORS (PROJECTION MATRIX W) */}
        {activeTab === 'vectors' && (
          <div className="space-y-3 text-xs">
            <p className="text-slate-600 text-[11px]">
              Los autovectores unitarios forman la base de proyección ortogonal. Los dos primeros (PC1
              y PC2) constituyen la matriz de proyección W = [v₁, v₂]:
            </p>

            <div className="space-y-2">
              <div className="p-2.5 bg-red-50/70 border border-red-200/80 rounded-xl">
                <div className="font-semibold text-red-950 flex items-center justify-between">
                  <span>v₁ (PC1 - Mayor dispersión):</span>
                  <span className="font-mono text-[11px] text-red-700">λ₁ = {eigenvalues[0].toFixed(2)}</span>
                </div>
                <div className="font-mono text-[11px] text-slate-700 mt-1">
                  [{eigenvectors[0][0].toFixed(3)}, {eigenvectors[0][1].toFixed(3)}, {eigenvectors[0][2].toFixed(3)}]
                </div>
              </div>

              <div className="p-2.5 bg-sky-50/70 border border-sky-200/80 rounded-xl">
                <div className="font-semibold text-sky-950 flex items-center justify-between">
                  <span>v₂ (PC2 - Segunda dispersión):</span>
                  <span className="font-mono text-[11px] text-sky-700">λ₂ = {eigenvalues[1].toFixed(2)}</span>
                </div>
                <div className="font-mono text-[11px] text-slate-700 mt-1">
                  [{eigenvectors[1][0].toFixed(3)}, {eigenvectors[1][1].toFixed(3)}, {eigenvectors[1][2].toFixed(3)}]
                </div>
              </div>

              <div className="p-2.5 bg-purple-50/70 border border-purple-200/80 rounded-xl">
                <div className="font-semibold text-purple-950 flex items-center justify-between">
                  <span>v₃ (PC3 - Eje Descartado):</span>
                  <span className="font-mono text-[11px] text-purple-700">λ₃ = {eigenvalues[2].toFixed(2)}</span>
                </div>
                <div className="font-mono text-[11px] text-slate-700 mt-1">
                  [{eigenvectors[2][0].toFixed(3)}, {eigenvectors[2][1].toFixed(3)}, {eigenvectors[2][2].toFixed(3)}]
                </div>
              </div>
            </div>

            <div className="p-2 bg-slate-50 rounded-lg border border-slate-200 text-[11px] text-slate-600 font-mono">
              Proyección 2D: z = [v₁·(x-μ), v₂·(x-μ)]ᵀ
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
