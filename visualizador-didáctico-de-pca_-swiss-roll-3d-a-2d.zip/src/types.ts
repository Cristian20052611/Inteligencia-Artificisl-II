export interface SwissRollPoint {
  id: number;
  // Original 3D coordinates
  x: number;
  y: number;
  z: number;
  // Intrinsic manifold coordinates:
  // t: position along the spiral arc
  // h: height along cylinder axis (y)
  t: number;
  h: number;
  // Normalized position [0, 1] for color palette
  colorValue: number;
  // Projected 2D coordinates in PCA space (PC1, PC2)
  pc1: number;
  pc2: number;
  // Reconstructed 3D coordinates on projection plane (PC1 + PC2 + mean)
  projX: number;
  projY: number;
  projZ: number;
  // Error / residual distance from original 3D to 2D plane
  residualDist: number;
}

export interface PCAResult {
  mean: [number, number, number];
  // 3x3 covariance matrix
  covarianceMatrix: number[][];
  // Eigenvalues sorted descending [lambda1, lambda2, lambda3]
  eigenvalues: [number, number, number];
  // Eigenvectors corresponding to eigenvalues [v1, v2, v3] each of length 3
  eigenvectors: [
    [number, number, number],
    [number, number, number],
    [number, number, number]
  ];
  // Explained variance ratio [ratio1, ratio2, ratio3] summing to 1
  explainedVarianceRatio: [number, number, number];
  // Total variance (sum of eigenvalues)
  totalVariance: number;
  // Points enriched with projections
  points: SwissRollPoint[];
}

export type PedagogicalStepId = 'intro' | 'centering' | 'eigen' | 'projection' | 'lesson';

export interface PedagogicalStep {
  id: PedagogicalStepId;
  number: number;
  title: string;
  shortDesc: string;
  fullExplanation: string;
  mathFormula?: string;
  didacticQuestion: string;
  didacticAnswer: string;
  suggestedProjectionMorph: number; // 0 to 1
  suggestedView: '3d' | 'projection' | '2d' | 'comparison';
}
