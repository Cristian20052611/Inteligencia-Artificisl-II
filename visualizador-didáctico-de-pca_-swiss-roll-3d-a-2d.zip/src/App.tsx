import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { generateSwissRoll } from './utils/math';
import { PCAResult, PedagogicalStepId } from './types';
import { PEDAGOGICAL_STEPS } from './utils/pedagogy';
import { ThreeCanvas } from './components/ThreeCanvas';
import { Scatter2D } from './components/Scatter2D';
import { PedagogicalGuide } from './components/PedagogicalGuide';
import { MathPanel } from './components/MathPanel';
import { ControlPanel } from './components/ControlPanel';
import {
  Brain,
  GraduationCap,
  Layers,
  Sparkles,
  Sliders,
  Sigma,
  GitCompare,
  ExternalLink,
  ChevronRight,
  Info,
} from 'lucide-react';

export default function App() {
  // Dataset parameter states
  const [pointCount, setPointCount] = useState<number>(550);
  const [noiseLevel, setNoiseLevel] = useState<number>(0.04);
  const [turns, setTurns] = useState<number>(2.0);
  const [seed, setSeed] = useState<number>(1);

  // Compute PCA and Swiss Roll points
  const pcaData: PCAResult = useMemo(() => {
    // seed can trigger regeneration
    return generateSwissRoll(pointCount, noiseLevel, turns);
  }, [pointCount, noiseLevel, turns, seed]);

  // Morph slider (0 = 3D original, 1 = projected on 2D plane)
  const [morphProgress, setMorphProgress] = useState<number>(0.0);
  const [isAnimating, setIsAnimating] = useState<boolean>(false);

  // 3D visual toggles
  const [showAxes, setShowAxes] = useState<boolean>(true);
  const [showPlane, setShowPlane] = useState<boolean>(true);
  const [showResiduals, setShowResiduals] = useState<boolean>(false);
  const [showCentroid, setShowCentroid] = useState<boolean>(true);

  // Point selection for synchronized inspection
  const [selectedPointId, setSelectedPointId] = useState<number | null>(null);

  // 2D View mode: 'pca' (PC1 vs PC2) or 'unrolled' (intrinsic manifold t vs y)
  const [viewMode2D, setViewMode2D] = useState<'pca' | 'unrolled'>('pca');

  // App navigation tabs / mode
  const [activeTab, setActiveTab] = useState<'guide' | 'math' | 'comparison'>('guide');
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);

  // Animate morphing if playing
  useEffect(() => {
    if (!isAnimating) return;
    let direction = 1;
    let frameId: number;
    let lastTime = performance.now();

    const loop = (time: number) => {
      const dt = (time - lastTime) / 1000;
      lastTime = time;
      setMorphProgress((prev) => {
        let next = prev + direction * dt * 0.4;
        if (next >= 1) {
          next = 1;
          direction = -1;
        } else if (next <= 0) {
          next = 0;
          direction = 1;
        }
        return next;
      });
      frameId = requestAnimationFrame(loop);
    };

    frameId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(frameId);
  }, [isAnimating]);

  // Handle applying presets when navigating pedagogical steps
  const handleApplyStepPreset = useCallback((stepId: PedagogicalStepId) => {
    setIsAnimating(false);
    if (stepId === 'intro') {
      setMorphProgress(0.0);
      setShowAxes(false);
      setShowPlane(false);
      setShowResiduals(false);
      setShowCentroid(false);
      setViewMode2D('pca');
    } else if (stepId === 'centering') {
      setMorphProgress(0.0);
      setShowCentroid(true);
      setShowAxes(false);
      setShowPlane(false);
      setShowResiduals(false);
    } else if (stepId === 'eigen') {
      setMorphProgress(0.0);
      setShowAxes(true);
      setShowCentroid(true);
      setShowPlane(true);
      setShowResiduals(false);
    } else if (stepId === 'projection') {
      setMorphProgress(1.0);
      setShowAxes(true);
      setShowPlane(true);
      setShowResiduals(true);
      setViewMode2D('pca');
    } else if (stepId === 'lesson') {
      setMorphProgress(1.0);
      setShowAxes(true);
      setShowPlane(true);
      setShowResiduals(false);
      setViewMode2D('pca');
    }
  }, []);

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 flex flex-col antialiased">
      {/* Top Application Bar */}
      <header
        id="app-header"
        className="bg-white border-b border-slate-200 sticky top-0 z-30 px-4 py-3 shadow-xs"
      >
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-sky-600 to-indigo-700 text-white flex items-center justify-center shadow-xs">
              <Brain className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-bold text-slate-900 tracking-tight">
                  PCA & Swiss Roll: Reducción Dimensional Didáctica
                </h1>
                <span className="hidden sm:inline-block px-2 py-0.5 rounded-full text-[11px] font-semibold bg-sky-50 text-sky-700 border border-sky-200">
                  3D → 2D
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Aprende de forma intuitiva cómo PCA descompone la varianza y por qué la no-linealidad desafía a los métodos lineales.
              </p>
            </div>
          </div>

          {/* Tab navigation */}
          <div id="top-nav-tabs" className="flex items-center gap-1.5 self-start md:self-auto bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs font-medium">
            <button
              id="tab-guide-btn"
              onClick={() => setActiveTab('guide')}
              className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all ${
                activeTab === 'guide'
                  ? 'bg-white text-sky-700 font-semibold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <GraduationCap className="w-3.5 h-3.5" />
              Guía Paso a Paso
            </button>
            <button
              id="tab-math-btn"
              onClick={() => setActiveTab('math')}
              className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all ${
                activeTab === 'math'
                  ? 'bg-white text-sky-700 font-semibold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Sigma className="w-3.5 h-3.5" />
              Cálculos Matemáticos
            </button>
            <button
              id="tab-comparison-btn"
              onClick={() => setActiveTab('comparison')}
              className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all ${
                activeTab === 'comparison'
                  ? 'bg-white text-sky-700 font-semibold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <GitCompare className="w-3.5 h-3.5" />
              PCA vs Manifold Learning
            </button>
          </div>
        </div>
      </header>

      {/* Main Workspace */}
      <main className="max-w-7xl mx-auto w-full p-4 lg:p-6 flex-1 flex flex-col gap-6">
        {/* Upper Visualizer Split View (3D Space on Left + 2D Projection on Right) */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 min-h-[480px]">
          {/* Left: 3D Interactive WebGL View */}
          <div className="flex flex-col bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
            <div className="px-4 py-2.5 border-b border-slate-100 bg-slate-50/70 flex items-center justify-between text-xs">
              <span className="font-bold text-slate-800 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-sky-600" />
                Espacio Tridimensional Original ℝ³ & Proyección al Hiperplano
              </span>
              <span className="text-slate-500 font-mono text-[11px]">
                N = {pcaData.points.length} puntos
              </span>
            </div>
            <div className="flex-1 min-h-[420px] relative">
              <ThreeCanvas
                pcaData={pcaData}
                morphProgress={morphProgress}
                showAxes={showAxes}
                showPlane={showPlane}
                showResiduals={showResiduals}
                showCentroid={showCentroid}
                selectedPointId={selectedPointId}
                onSelectPoint={setSelectedPointId}
              />
            </div>
          </div>

          {/* Right: 2D Projected Space */}
          <div className="flex flex-col">
            <Scatter2D
              pcaData={pcaData}
              selectedPointId={selectedPointId}
              onSelectPoint={setSelectedPointId}
              viewMode={viewMode2D}
              onToggleViewMode={setViewMode2D}
            />
          </div>
        </div>

        {/* Morph & Dataset Controls Panel */}
        <ControlPanel
          morphProgress={morphProgress}
          onMorphChange={(val) => {
            setIsAnimating(false);
            setMorphProgress(val);
          }}
          isAnimating={isAnimating}
          onToggleAnimate={() => setIsAnimating(!isAnimating)}
          showAxes={showAxes}
          onToggleAxes={() => setShowAxes(!showAxes)}
          showPlane={showPlane}
          onTogglePlane={() => setShowPlane(!showPlane)}
          showResiduals={showResiduals}
          onToggleResiduals={() => setShowResiduals(!showResiduals)}
          showCentroid={showCentroid}
          onToggleCentroid={() => setShowCentroid(!showCentroid)}
          pointCount={pointCount}
          onPointCountChange={setPointCount}
          noiseLevel={noiseLevel}
          onNoiseChange={setNoiseLevel}
          turns={turns}
          onTurnsChange={setTurns}
          onRegenerateData={() => setSeed((prev) => prev + 1)}
        />

        {/* Lower Educational / Theoretical Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {/* Main Selected Tab Content */}
          <div className="lg:col-span-2">
            {activeTab === 'guide' && (
              <PedagogicalGuide
                currentStepIndex={currentStepIndex}
                onStepChange={setCurrentStepIndex}
                onApplyStepPreset={handleApplyStepPreset}
              />
            )}

            {activeTab === 'math' && <MathPanel pcaData={pcaData} />}

            {activeTab === 'comparison' && (
              <div
                id="comparison-card"
                className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5 space-y-4"
              >
                <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
                  <GitCompare className="w-5 h-5 text-sky-600" />
                  <h2 className="text-base font-bold text-slate-800 tracking-tight">
                    Comparativa Didáctica: PCA (Lineal) vs Manifold Learning (No Lineal)
                  </h2>
                </div>

                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  El dataset de Swiss Roll fue popularizado en el año 2000 por los científicos de Stanford
                  (Tenenbaum et al., Science) para demostrar por qué los métodos lineales clásicos como PCA
                  no son suficientes para variedades curvadas.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  {/* PCA Column */}
                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2.5">
                    <span className="font-bold text-slate-900 block text-sm flex items-center justify-between">
                      <span>PCA (Lineal)</span>
                      <span className="text-[10px] bg-slate-200 text-slate-700 px-2 py-0.5 rounded">
                        Global
                      </span>
                    </span>
                    <ul className="space-y-1.5 text-slate-600 list-disc list-inside">
                      <li>
                        <strong>Principio:</strong> Proyecta los datos sobre un hiperplano ortogonal plano.
                      </li>
                      <li>
                        <strong>Distancia:</strong> Mide distancias euclidianas en línea recta a través del aire.
                      </li>
                      <li>
                        <strong>Resultado en Swiss Roll:</strong> Las capas del rollo se aplastan unas sobre otras.
                      </li>
                      <li>
                        <strong>Ventajas:</strong> Ultrarrápido, determinista, exacto matemáticamente, interpretable.
                      </li>
                      <li>
                        <strong>Cuándo usar:</strong> Cuando las relaciones entre variables sean aproximadamente lineales o para comprimir ruido.
                      </li>
                    </ul>
                  </div>

                  {/* Manifold Learning Column */}
                  <div className="p-4 rounded-xl bg-emerald-50/60 border border-emerald-200/80 space-y-2.5">
                    <span className="font-bold text-emerald-950 block text-sm flex items-center justify-between">
                      <span>Manifold Learning (Isomap, t-SNE)</span>
                      <span className="text-[10px] bg-emerald-200 text-emerald-800 px-2 py-0.5 rounded">
                        No Lineal
                      </span>
                    </span>
                    <ul className="space-y-1.5 text-emerald-900 list-disc list-inside">
                      <li>
                        <strong>Principio:</strong> Aprende la geometría intrínseca de la variedad curvada.
                      </li>
                      <li>
                        <strong>Distancia:</strong> Mide distancias geodésicas (caminando a través de la superficie de los vecinos).
                      </li>
                      <li>
                        <strong>Resultado en Swiss Roll:</strong> Desenrolla la espiral completamente plana como un mantel.
                      </li>
                      <li>
                        <strong>Ventajas:</strong> Preserva la topología y relaciones locales de vecindad.
                      </li>
                      <li>
                        <strong>Cuándo usar:</strong> Visualización de clústeres complejos, datos biológicos (single-cell), imágenes de alta dimensionalidad.
                      </li>
                    </ul>
                  </div>
                </div>

                <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 leading-relaxed flex items-start gap-2">
                  <Info className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <strong>Conclusión Pedagógica Clave:</strong> PCA no comete un error de cálculo; calcula
                    impecablemente el mejor plano lineal de máxima varianza. El fenómeno de aplastamiento nos
                    enseña que <em>la dimensionalidad intrínseca de un problema puede ser baja (2D), pero su forma en el espacio puede ser no lineal</em>.
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Quick Summary Reference Card on Right */}
          <div className="space-y-4">
            <div
              id="pca-cheat-sheet"
              className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-4 space-y-3 text-xs"
            >
              <div className="font-bold text-slate-800 flex items-center gap-1.5 pb-2 border-b border-slate-100">
                <Sparkles className="w-4 h-4 text-sky-600" />
                Resumen Rápido: Pasos de PCA
              </div>

              <ol className="space-y-2.5 text-slate-600">
                <li className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-slate-100 text-slate-800 font-bold flex items-center justify-center shrink-0 text-[10px]">
                    1
                  </span>
                  <div>
                    <strong className="text-slate-800 block">Centrar los datos:</strong>
                    Restar el vector de medias: x′ = x - μ.
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-slate-100 text-slate-800 font-bold flex items-center justify-center shrink-0 text-[10px]">
                    2
                  </span>
                  <div>
                    <strong className="text-slate-800 block">Matriz de Covarianza:</strong>
                    Calcular Σ = (1/(N-1)) X′ᵀX′.
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-slate-100 text-slate-800 font-bold flex items-center justify-center shrink-0 text-[10px]">
                    3
                  </span>
                  <div>
                    <strong className="text-slate-800 block">Descomposición espectral:</strong>
                    Hallar autovalores λ y autovectores v de Σ.
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-slate-100 text-slate-800 font-bold flex items-center justify-center shrink-0 text-[10px]">
                    4
                  </span>
                  <div>
                    <strong className="text-slate-800 block">Seleccionar k componentes:</strong>
                    Tomar los 2 autovectores con mayor λ (PC1 y PC2).
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-slate-100 text-slate-800 font-bold flex items-center justify-center shrink-0 text-[10px]">
                    5
                  </span>
                  <div>
                    <strong className="text-slate-800 block">Proyectar a 2D:</strong>
                    Multiplicar Z = X′ · W, descartando PC3.
                  </div>
                </li>
              </ol>

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                <span>Varianza explicada 2D:</span>
                <span className="font-bold text-sky-700 font-mono">
                  {(
                    (pcaData.explainedVarianceRatio[0] + pcaData.explainedVarianceRatio[1]) *
                    100
                  ).toFixed(1)}
                  %
                </span>
              </div>
            </div>

            {/* Interactive experiment tip */}
            <div className="bg-gradient-to-br from-sky-50 to-indigo-50/50 rounded-2xl border border-sky-100 p-4 text-xs space-y-2 text-sky-950">
              <span className="font-bold flex items-center gap-1.5 text-sky-900">
                <Brain className="w-4 h-4 text-sky-700" />
                Experimento Interactivo Recomendado
              </span>
              <p className="text-slate-600 leading-relaxed text-[11px]">
                Prueba pulsar el botón <strong>&quot;Frente al Plano (2D)&quot;</strong> arriba a la izquierda del visor 3D,
                y luego arrastra el deslizador de <strong>Transición Dimensional</strong> al 100%. Verás que la vista 3D
                alineada coincide exactamente con el gráfico 2D de la derecha.
              </p>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-3 px-4 text-center text-xs text-slate-500 mt-8">
        Visualizador Didáctico de Análisis de Componentes Principales (PCA) • Dataset Clásico Swiss Roll (Reducción Dimensional 3D a 2D)
      </footer>
    </div>
  );
}
