import { PedagogicalStep } from '../types';

export const PEDAGOGICAL_STEPS: PedagogicalStep[] = [
  {
    id: 'intro',
    number: 1,
    title: 'El Dataset del Swiss Roll (3D)',
    shortDesc: 'Una variedad bidimensional curvada y enrollada dentro de un espacio 3D.',
    fullExplanation:
      'El Swiss Roll (rollo suizo) es el ejemplo clásico por excelencia en Ciencia de Datos y Machine Learning. Imagina una hoja plana de papel rectangular (2D) que ha sido enrollada como un brazo de gitano en el espacio tridimensional. Aunque cada punto tiene tres coordenadas (x, y, z), los datos solo tienen dos grados de libertad intrínsecos: la posición a lo largo de la espiral (el color) y el ancho a lo largo del cilindro.',
    mathFormula: 'x = t \\cdot \\cos(t), \\quad y = h, \\quad z = t \\cdot \\sin(t)',
    didacticQuestion: '¿Por qué los puntos tienen colores graduados del violeta al rojo?',
    didacticAnswer:
      'El color codifica la distancia intrínseca a lo largo de la espiral. Si desenrolláramos la hoja en una mesa plana, los colores formarían una franja continua perfecta sin mezclarse.',
    suggestedProjectionMorph: 0.0,
    suggestedView: '3d',
  },
  {
    id: 'centering',
    number: 2,
    title: 'Centrado de Datos (μ) y Matriz de Covarianza (Σ)',
    shortDesc: 'Trasladar el centroide al origen (0,0,0) y medir cómo covarían las dimensiones.',
    fullExplanation:
      'El primer paso innegociable de PCA es restar el vector media μ a cada muestra. Esto traslada el centro de gravedad de la nube de puntos al origen de coordenadas (0, 0, 0), garantizando que las direcciones que busquemos midan dispersión real y no desplazamientos respecto al origen. Luego, calculamos la matriz de covarianza Σ (3x3), donde los elementos diagonales son las varianzas de cada eje y los cruzados son las covarianzas entre pares.',
    mathFormula: '\\mathbf{x}\'_i = \\mathbf{x}_i - \\boldsymbol{\\mu}, \\quad \\Sigma = \\frac{1}{N-1} \\sum_{i=1}^N \\mathbf{x}\'_i (\\mathbf{x}\'_i)^T',
    didacticQuestion: '¿Qué pasaría si no restáramos la media antes de calcular PCA?',
    didacticAnswer:
      'Si los datos estuvieran lejos del origen, el primer componente principal apuntaría hacia el cúmulo de datos en vez de seguir la dirección de mayor dispersión interna.',
    suggestedProjectionMorph: 0.0,
    suggestedView: '3d',
  },
  {
    id: 'eigen',
    number: 3,
    title: 'Autovectores y Autovalores (PC1, PC2, PC3)',
    shortDesc: 'Hallar los ejes ortogonales de máxima varianza mediante descomposición espectral.',
    fullExplanation:
      'Mediante la ecuación característica Σ·v = λ·v, encontramos tres direcciones ortogonales perpendiculares a 90° entre sí:\n• PC1 (v₁): La dirección a lo largo de la cual los datos se dispersan con mayor fuerza.\n• PC2 (v₂): La segunda dirección de mayor variabilidad, perpendicular a PC1.\n• PC3 (v₃): El eje con menor variabilidad (el "grosor" o ruido perpendicular al plano).\nLos autovalores λ₁, λ₂, λ₃ indican cuantitativamente la cantidad de varianza explicada por cada vector.',
    mathFormula: '\\Sigma \\mathbf{v}_k = \\lambda_k \\mathbf{v}_k, \\quad \\text{Varianza Retenida} = \\frac{\\lambda_1 + \\lambda_2}{\\sum \\lambda_k}',
    didacticQuestion: '¿Por qué los ejes principales siempre forman ángulos rectos de 90° exactos?',
    didacticAnswer:
      'Porque la matriz de covarianza Σ es simétrica real. Por el Teorema Espectral del Álgebra Lineal, sus autovectores siempre forman una base ortonormal perfecta.',
    suggestedProjectionMorph: 0.0,
    suggestedView: '3d',
  },
  {
    id: 'projection',
    number: 4,
    title: 'Proyección Ortogonal 3D → 2D',
    shortDesc: 'Aplastamos la nube de puntos sobre el hiperplano óptimo definido por PC1 y PC2.',
    fullExplanation:
      'Para reducir de 3D a 2D, descartamos el eje de menor varianza (PC3) y construimos un plano con PC1 y PC2. Cada punto tridimensional cae en línea recta perpendicular sobre este plano. La distancia entre el punto 3D original y su sombra en el plano es el "error de reconstrucción" o residuo. ¡Usa el deslizador de morphing para ver a los puntos viajar físicamente hacia el plano!',
    mathFormula: 'z_{i,1} = \\mathbf{v}_1^T (\\mathbf{x}_i - \\boldsymbol{\\mu}), \\quad z_{i,2} = \\mathbf{v}_2^T (\\mathbf{x}_i - \\boldsymbol{\\mu})',
    didacticQuestion: '¿Por qué este plano es matemáticamente el mejor posible?',
    didacticAnswer:
      'Porque minimiza la suma de las distancias perpendiculares al cuadrado (error de reconstrucción) y al mismo tiempo maximiza la varianza de los puntos proyectados.',
    suggestedProjectionMorph: 1.0,
    suggestedView: 'projection',
  },
  {
    id: 'lesson',
    number: 5,
    title: 'La Gran Lección: ¿Por qué PCA "aplasta" el rollo?',
    shortDesc: 'La diferencia fundamental entre reducción lineal (PCA) y no lineal (Manifold Learning).',
    fullExplanation:
      '¡Observa con atención el gráfico 2D! En la proyección de PCA, las diferentes espirales del rollo se superponen unas sobre otras: puntos violetas (centro) y puntos rojos (exterior) se mezclan en la misma región. ¿Por qué ocurre esto?\n\nPCA es estrictamente LINEAL. Solo sabe proyectar sobre planos planos. No "entiende" que la hoja está curvada. Para desenrollar el Swiss Roll sin mezclar capas, la ciencia de datos inventó algoritmos no lineales como Isomap, LLE o t-SNE, que miden distancias geodésicas (caminando sobre la superficie) en lugar de distancias euclidianas en línea recta.',
    mathFormula: '\\text{Distancia Euclidiana 3D} \\neq \\text{Distancia Geodésica en la Variedad}',
    didacticQuestion: '¿Significa esto que PCA falló o es un mal algoritmo?',
    didacticAnswer:
      '¡No! PCA hizo exactamente lo que promete: encontrar el mejor plano lineal global con máxima varianza. El Swiss Roll nos enseña que para estructuras no lineales enrolladas, necesitamos métodos de Manifold Learning.',
    suggestedProjectionMorph: 1.0,
    suggestedView: 'comparison',
  },
];
