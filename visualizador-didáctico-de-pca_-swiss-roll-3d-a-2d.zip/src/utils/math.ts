import { PCAResult, SwissRollPoint } from '../types';

/**
 * Generates points for the 3D Swiss Roll dataset.
 *
 * @param count Number of sample points
 * @param noise Gaussian noise standard deviation
 * @param turns Number of spiral revolutions (default ~2 turns, t in [1.5*PI, 4.5*PI])
 */
export function generateSwissRoll(
  count: number = 600,
  noise: number = 0.05,
  turns: number = 2.0
): PCAResult {
  const minT = 1.5 * Math.PI;
  const maxT = (1.5 + turns * 1.5) * Math.PI;
  const heightRange = 22; // width along cylinder axis (y)

  // Box-Muller transform for gaussian noise
  function randomGaussian(stdDev: number): number {
    if (stdDev <= 0) return 0;
    let u = 0, v = 0;
    while (u === 0) u = Math.random();
    while (v === 0) v = Math.random();
    return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v) * stdDev;
  }

  // Pre-generate raw points
  const rawPoints: { x: number; y: number; z: number; t: number; h: number; colorValue: number }[] = [];
  let sumX = 0;
  let sumY = 0;
  let sumZ = 0;

  for (let i = 0; i < count; i++) {
    // Generate t using square root or uniform distribution
    // Square root distribution spreads points more evenly along surface area
    const tFrac = Math.sqrt(Math.random());
    const t = minT + tFrac * (maxT - minT);
    const h = (Math.random() - 0.5) * heightRange;

    // Swiss roll parametric formulation:
    // x = t * cos(t) + noise
    // y = h + noise
    // z = t * sin(t) + noise
    const nx = randomGaussian(noise * 4);
    const ny = randomGaussian(noise * 4);
    const nz = randomGaussian(noise * 4);

    const x = t * Math.cos(t) + nx;
    const y = h + ny;
    const z = t * Math.sin(t) + nz;

    const colorValue = (t - minT) / (maxT - minT);

    rawPoints.push({ x, y, z, t, h, colorValue });
    sumX += x;
    sumY += y;
    sumZ += z;
  }

  // Step 1: Calculate Mean Vector
  const mean: [number, number, number] = [sumX / count, sumY / count, sumZ / count];

  // Step 2: Calculate 3x3 Covariance Matrix
  // Cov(a, b) = sum( (a_i - mean_a) * (b_i - mean_b) ) / (count - 1)
  const cov: number[][] = [
    [0, 0, 0],
    [0, 0, 0],
    [0, 0, 0],
  ];

  for (let i = 0; i < count; i++) {
    const dx = rawPoints[i].x - mean[0];
    const dy = rawPoints[i].y - mean[1];
    const dz = rawPoints[i].z - mean[2];

    cov[0][0] += dx * dx;
    cov[0][1] += dx * dy;
    cov[0][2] += dx * dz;

    cov[1][0] += dy * dx;
    cov[1][1] += dy * dy;
    cov[1][2] += dy * dz;

    cov[2][0] += dz * dx;
    cov[2][1] += dz * dy;
    cov[2][2] += dz * dz;
  }

  const factor = count > 1 ? count - 1 : 1;
  for (let r = 0; r < 3; r++) {
    for (let c = 0; c < 3; c++) {
      cov[r][c] /= factor;
    }
  }

  // Step 3: Compute Eigenvalues & Eigenvectors of the symmetric 3x3 covariance matrix
  const { eigenvalues: rawEigenvalues, eigenvectors: rawEigenvectors } = jacobiEigenDecomposition(cov);

  // Sort eigenvalues descending
  const indices = [0, 1, 2];
  indices.sort((a, b) => rawEigenvalues[b] - rawEigenvalues[a]);

  const eigenvalues: [number, number, number] = [
    rawEigenvalues[indices[0]],
    rawEigenvalues[indices[1]],
    rawEigenvalues[indices[2]],
  ];

  // Make sure eigenvectors have consistent orientation for clean visualization
  const eigenvectors: [
    [number, number, number],
    [number, number, number],
    [number, number, number]
  ] = [
    orientVector(rawEigenvectors[indices[0]]),
    orientVector(rawEigenvectors[indices[1]]),
    orientVector(rawEigenvectors[indices[2]]),
  ];

  const totalVariance = Math.max(0.0001, eigenvalues[0] + eigenvalues[1] + eigenvalues[2]);
  const explainedVarianceRatio: [number, number, number] = [
    eigenvalues[0] / totalVariance,
    eigenvalues[1] / totalVariance,
    eigenvalues[2] / totalVariance,
  ];

  // Step 4: Project points onto the subspace spanned by PC1 and PC2
  const v1 = eigenvectors[0];
  const v2 = eigenvectors[1];

  const points: SwissRollPoint[] = rawPoints.map((pt, idx) => {
    const dx = pt.x - mean[0];
    const dy = pt.y - mean[1];
    const dz = pt.z - mean[2];

    // Dot products with eigenvectors
    const pc1 = dx * v1[0] + dy * v1[1] + dz * v1[2];
    const pc2 = dx * v2[0] + dy * v2[1] + dz * v2[2];

    // Reconstructed 3D position on the projection plane: mean + pc1*v1 + pc2*v2
    const projX = mean[0] + pc1 * v1[0] + pc2 * v2[0];
    const projY = mean[1] + pc1 * v1[1] + pc2 * v2[1];
    const projZ = mean[2] + pc1 * v1[2] + pc2 * v2[2];

    const rx = pt.x - projX;
    const ry = pt.y - projY;
    const rz = pt.z - projZ;
    const residualDist = Math.sqrt(rx * rx + ry * ry + rz * rz);

    return {
      id: idx,
      x: pt.x,
      y: pt.y,
      z: pt.z,
      t: pt.t,
      h: pt.h,
      colorValue: pt.colorValue,
      pc1,
      pc2,
      projX,
      projY,
      projZ,
      residualDist,
    };
  });

  return {
    mean,
    covarianceMatrix: cov,
    eigenvalues,
    eigenvectors,
    explainedVarianceRatio,
    totalVariance,
    points,
  };
}

/**
 * Normalizes vector direction to avoid flipping between data regenerations.
 */
function orientVector(v: [number, number, number]): [number, number, number] {
  // Find component with largest absolute value and ensure it's positive
  let maxAbs = Math.abs(v[0]);
  let maxIdx = 0;
  if (Math.abs(v[1]) > maxAbs) {
    maxAbs = Math.abs(v[1]);
    maxIdx = 1;
  }
  if (Math.abs(v[2]) > maxAbs) {
    maxAbs = Math.abs(v[2]);
    maxIdx = 2;
  }

  if (v[maxIdx] < 0) {
    return [-v[0], -v[1], -v[2]];
  }
  return [v[0], v[1], v[2]];
}

/**
 * Classic Jacobi Eigenvalue Algorithm for 3x3 Real Symmetric Matrices.
 * Fast, highly accurate, and guaranteed convergence.
 */
function jacobiEigenDecomposition(A_in: number[][]): {
  eigenvalues: [number, number, number];
  eigenvectors: [[number, number, number], [number, number, number], [number, number, number]];
} {
  const n = 3;
  // Clone A
  const A = [
    [A_in[0][0], A_in[0][1], A_in[0][2]],
    [A_in[1][0], A_in[1][1], A_in[1][2]],
    [A_in[2][0], A_in[2][1], A_in[2][2]],
  ];

  // Initialize V as identity matrix (eigenvectors)
  const V = [
    [1, 0, 0],
    [0, 1, 0],
    [0, 0, 1],
  ];

  const maxIterations = 50;
  const eps = 1e-10;

  for (let iter = 0; iter < maxIterations; iter++) {
    // Find largest off-diagonal element
    let maxVal = 0;
    let p = 0;
    let q = 1;

    for (let i = 0; i < n; i++) {
      for (let j = i + 1; j < n; j++) {
        const absVal = Math.abs(A[i][j]);
        if (absVal > maxVal) {
          maxVal = absVal;
          p = i;
          q = j;
        }
      }
    }

    if (maxVal < eps) {
      break;
    }

    // Compute rotation angle theta
    const app = A[p][p];
    const aqq = A[q][q];
    const apq = A[p][q];

    const theta = 0.5 * Math.atan2(2 * apq, aqq - app);
    const c = Math.cos(theta);
    const s = Math.sin(theta);

    // Apply Jacobi rotation to matrix A
    for (let k = 0; k < n; k++) {
      if (k !== p && k !== q) {
        const akp = A[k][p];
        const akq = A[k][q];
        A[k][p] = c * akp - s * akq;
        A[p][k] = A[k][p];
        A[k][q] = s * akp + c * akq;
        A[q][k] = A[k][q];
      }
    }

    A[p][p] = c * c * app - 2 * s * c * apq + s * s * aqq;
    A[q][q] = s * s * app + 2 * s * c * apq + c * c * aqq;
    A[p][q] = 0;
    A[q][p] = 0;

    // Accumulate transformation in eigenvector matrix V
    for (let k = 0; k < n; k++) {
      const vkp = V[k][p];
      const vkq = V[k][q];
      V[k][p] = c * vkp - s * vkq;
      V[k][q] = s * vkp + c * vkq;
    }
  }

  // Eigenvalues are the diagonal entries of A
  const eigenvalues: [number, number, number] = [
    Math.max(0, A[0][0]),
    Math.max(0, A[1][1]),
    Math.max(0, A[2][2]),
  ];

  // Column vectors of V are the eigenvectors
  const eigenvectors: [
    [number, number, number],
    [number, number, number],
    [number, number, number]
  ] = [
    [V[0][0], V[1][0], V[2][0]],
    [V[0][1], V[1][1], V[2][1]],
    [V[0][2], V[1][2], V[2][2]],
  ];

  return { eigenvalues, eigenvectors };
}

/**
 * Returns a hex/rgba color for a point given its normalized t position [0, 1].
 * Uses a smooth scientific sequential colormap (indigo -> blue -> cyan -> emerald -> amber -> coral).
 */
export function getSwissRollColor(normalizedVal: number): string {
  // Clamped [0, 1]
  const val = Math.max(0, Math.min(1, normalizedVal));
  
  // High contrast vibrant palette that is beautiful on both dark and light backgrounds:
  // 0.0 -> #6366f1 (Indigo)
  // 0.25 -> #06b6d4 (Cyan)
  // 0.50 -> #10b981 (Emerald)
  // 0.75 -> #f59e0b (Amber)
  // 1.0 -> #ef4444 (Crimson)
  const stops = [
    { pos: 0.0, r: 99, g: 102, b: 241 },   // Indigo
    { pos: 0.25, r: 6, g: 182, b: 212 },   // Cyan
    { pos: 0.50, r: 16, g: 185, b: 129 },  // Emerald
    { pos: 0.75, r: 245, g: 158, b: 11 },  // Amber
    { pos: 1.0, r: 239, g: 68, b: 68 },    // Crimson
  ];

  for (let i = 0; i < stops.length - 1; i++) {
    const s1 = stops[i];
    const s2 = stops[i + 1];
    if (val >= s1.pos && val <= s2.pos) {
      const t = (val - s1.pos) / (s2.pos - s1.pos);
      const r = Math.round(s1.r + t * (s2.r - s1.r));
      const g = Math.round(s1.g + t * (s2.g - s1.g));
      const b = Math.round(s1.b + t * (s2.b - s1.b));
      return `rgb(${r}, ${g}, ${b})`;
    }
  }
  return `rgb(239, 68, 68)`;
}
