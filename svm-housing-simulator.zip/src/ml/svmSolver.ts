/**
 * MOTOR MATEMÁTICO DE MÁQUINAS DE SOPORTE VECTORIAL (SVM)
 * Este archivo implementa el algoritmo SMO (Sequential Minimal Optimization) completo,
 * las funciones Kernel (Lineal, RBF Gaussiano, Polinómico), normalización de datos,
 * extracción de vectores de soporte, cálculo del hiperplano w·x + b = 0, márgenes y métricas.
 */

import { HousingRecord, FeatureKey, SVMHyperparameters, SVMModelResult, SupportVectorInfo } from '../types/housing';

/**
 * Estructura para almacenar los datos después de normalizarlos al rango [-1, 1]
 */
export interface NormalizedDataset {
  // Arreglo con los registros inmobiliarios originales completos
  raw: HousingRecord[];
  // Matriz de características normalizadas: cada fila es una casa, cada columna una variable escalada a [-1, 1]
  features: number[][];
  // Etiquetas binarias de clasificación: +1 para Alta Gama / Lujo, -1 para Accesible / Estándar
  targets: number[];
  // Valores mínimos originales por variable (necesarios para des-normalizar y proyectar)
  mins: number[];
  // Valores máximos originales por variable
  maxs: number[];
}

/**
 * Función que toma las viviendas en bruto y las normaliza matemáticamente.
 * La normalización es fundamental en SVM porque variables en escalas enormes (ej. Ingreso: $80,000)
 * aplastarían a variables en escalas pequeñas (ej. Habitaciones: 7), distorsionando las distancias euclidianas.
 */
export function prepareDataset(
  records: HousingRecord[],       // Lista de casas a procesar
  features: FeatureKey[],         // Variables elegidas para los ejes (ej. ['avgAreaIncome', 'squareFeet'])
  threshold: number               // Umbral de precio ($) para dividir entre clase +1 y clase -1
): NormalizedDataset {
  // Cantidad de casas en la muestra (n)
  const n = records.length;
  // Cantidad de dimensiones espaciales seleccionadas (d: 2 para 2D, 3 para 3D)
  const d = features.length;
  // Inicializamos los valores mínimos con infinito para encontrarlos mediante comparación
  const mins = new Array(d).fill(Infinity);
  // Inicializamos los valores máximos con menos infinito
  const maxs = new Array(d).fill(-Infinity);

  // Recorremos cada vivienda para registrar los mínimos y máximos de cada característica elegida
  records.forEach((r) => {
    features.forEach((f, fi) => {
      const val = r[f];
      // Si el valor actual es menor que el mínimo conocido, actualizamos el mínimo
      if (val < mins[fi]) mins[fi] = val;
      // Si el valor actual es mayor que el máximo conocido, actualizamos el máximo
      if (val > maxs[fi]) maxs[fi] = val;
    });
  });

  // Protección matemática contra división por cero (si todos los valores de una columna fuesen idénticos)
  for (let fi = 0; fi < d; fi++) {
    if (maxs[fi] === mins[fi]) {
      maxs[fi] = mins[fi] + 1;
    }
  }

  // Mapeamos cada vivienda a su coordenada matemática normalizada en el intervalo simétrico [-1, 1]
  // Fórmula: ((valor - min) / (max - min)) * 2 - 1
  const normalizedFeatures: number[][] = records.map((r) => {
    return features.map((f, fi) => {
      const v = r[f];
      // Escalado Min-Max centrado en el origen (0, 0)
      return ((v - mins[fi]) / (maxs[fi] - mins[fi])) * 2 - 1;
    });
  });

  // Asignamos la etiqueta objetivo:
  // Si el precio real es mayor o igual al umbral -> Clase +1 (Vivienda de Lujo)
  // Si el precio real es inferior al umbral -> Clase -1 (Vivienda Estándar)
  const targets = records.map((r) => (r.price >= threshold ? 1 : -1));

  // Retornamos el conjunto de datos estructurado y normalizado
  return {
    raw: records,
    features: normalizedFeatures,
    targets,
    mins,
    maxs,
  };
}

/**
 * FUNCIÓN KERNEL: K(x1, x2)
 * Calcula el producto escalar (similitud) entre dos vectores en un espacio de características transformado.
 * Permite a SVM resolver problemas no lineales sin calcular explícitamente las coordenadas de alta dimensión.
 */
export function computeKernel(
  x1: number[],                   // Vector de características de la casa 1
  x2: number[],                   // Vector de características de la casa 2
  params: { kernel: string; gamma: number; polyDegree: number } // Hiperparámetros del kernel
): number {
  // 1. KERNEL LINEAL: K(x1, x2) = x1 · x2
  // Es el producto punto euclidiano estándar; busca una separación con hiperplano plano
  if (params.kernel === 'linear') {
    let sum = 0;
    // Sumatoria de x1[i] * x2[i] para cada dimensión i
    for (let i = 0; i < x1.length; i++) sum += x1[i] * x2[i];
    return sum;
  }

  // 2. KERNEL RBF (Función de Base Radial / Gaussiano): K(x1, x2) = exp(-γ ||x1 - x2||²)
  // Mide la cercanía radial infinita entre viviendas; crea fronteras suaves y curvas
  if (params.kernel === 'rbf') {
    let distSq = 0;
    // Calculamos la distancia euclidiana al cuadrado ||x1 - x2||²
    for (let i = 0; i < x1.length; i++) {
      const diff = x1[i] - x2[i];
      distSq += diff * diff;
    }
    // Aplicamos la campana de Gauss ponderada por el parámetro gamma (γ)
    return Math.exp(-params.gamma * distSq);
  }

  // 3. KERNEL POLINÓMICO: K(x1, x2) = (x1 · x2 + 1)^d
  // Modela interacciones polinómicas cruzadas de grado d entre variables
  if (params.kernel === 'poly') {
    let dot = 0;
    // Calculamos el producto punto base
    for (let i = 0; i < x1.length; i++) dot += x1[i] * x2[i];
    // Elevamos al grado polinómico configurado
    return Math.pow(dot + 1, params.polyDegree);
  }

  // Valor por defecto en caso de parámetro desconocido
  return 0;
}

/**
 * OPTIMIZADOR PRINCIPAL: ALGORITMO SMO (Sequential Minimal Optimization)
 * Resuelve el problema dual de programación cuadrática de SVM:
 * Maximizar ∑ αᵢ - (1/2) ∑ ∑ αᵢ αⱼ yᵢ yⱼ K(xᵢ, xⱼ)
 * Sujeto a: 0 ≤ αᵢ ≤ C  y  ∑ αᵢ yᵢ = 0
 */
export function solveSVM(
  dataset: NormalizedDataset,     // Dataset normalizado
  params: SVMHyperparameters,     // Parámetros de regularización C, tipo de kernel, etc.
  features: FeatureKey[]          // Lista de características en estudio
): SVMModelResult {
  // Desestructuramos las variables de entrada del dataset
  const { features: X, targets: y, raw } = dataset;
  // n = número total de viviendas en el dataset
  const n = X.length;
  // d = número de dimensiones/variables (2 para 2D, 3 para 3D)
  const d = X[0].length;
  // Extraemos los hiperparámetros elegidos por el usuario
  const { C, kernel, gamma, polyDegree } = params;

  // Precomputamos la Matriz de Gram / Kernel (K[i][j] = K(x_i, x_j))
  // Esto evita recalcular el kernel millones de veces dentro del bucle SMO
  const K: number[][] = Array.from({ length: n }, () => new Array(n).fill(0));
  for (let i = 0; i < n; i++) {
    for (let j = i; j < n; j++) {
      // Calculamos la similitud kernel entre la casa i y la casa j
      const kVal = computeKernel(X[i], X[j], { kernel, gamma, polyDegree });
      // La matriz de kernel es simétrica: K[i][j] == K[j][i]
      K[i][j] = kVal;
      K[j][i] = kVal;
    }
  }

  // Vector de multiplicadores de Lagrange (alphas), uno para cada vivienda. Inicialmente todos en 0.
  const alphas = new Array(n).fill(0);
  // Término de sesgo independiente (bias b) del hiperplano. Inicialmente en 0.
  let b = 0;
  // Tolerancia de error numérico para las condiciones KKT (Karush-Kuhn-Tucker)
  const tol = 1e-3;
  // Cantidad máxima de pasadas consecutivas sin cambios antes de declarar convergencia
  const maxPasses = 30;
  // Contador de pasadas sin cambios
  let passes = 0;

  /**
   * Función auxiliar para evaluar la predicción actual f(x_i):
   * f(x_i) = ∑ (α_j * y_j * K(x_j, x_i)) + b
   */
  const computeF = (i: number) => {
    let val = b;
    for (let j = 0; j < n; j++) {
      // Solo las casas con alpha > 0 influyen en la predicción (Vectores de Soporte)
      if (alphas[j] > 0) {
        val += alphas[j] * y[j] * K[j][i];
      }
    }
    return val;
  };

  // Bucle iterativo de optimización SMO
  while (passes < maxPasses) {
    // Contador de alphas actualizados en la pasada actual
    let numChangedAlphas = 0;

    // Iteramos por cada punto de entrenamiento i
    for (let i = 0; i < n; i++) {
      // Error de predicción del punto i: Ei = f(x_i) - y_i
      const Ei = computeF(i) - y[i];

      // Verificamos si el punto i viola las condiciones de holgura KKT
      if ((y[i] * Ei < -tol && alphas[i] < C) || (y[i] * Ei > tol && alphas[i] > 0)) {
        // Seleccionamos un segundo multiplicador j (heurística simplificada: j != i al azar)
        let j = Math.floor(Math.random() * (n - 1));
        if (j >= i) j++;

        // Error de predicción del segundo punto j: Ej = f(x_j) - y_j
        const Ej = computeF(j) - y[j];
        // Guardamos los valores antiguos de alpha_i y alpha_j para los cálculos
        const alphaIold = alphas[i];
        const alphaJold = alphas[j];

        // Calculamos los límites inferior (L) y superior (H) de la caja [0, C]
        let L = 0;
        let H = C;

        // Caso 1: Los dos puntos tienen etiquetas opuestas (y_i != y_j)
        if (y[i] !== y[j]) {
          L = Math.max(0, alphas[j] - alphas[i]);
          H = Math.min(C, C + alphas[j] - alphas[i]);
        } else {
          // Caso 2: Los dos puntos tienen la misma etiqueta (y_i == y_j)
          L = Math.max(0, alphas[i] + alphas[j] - C);
          H = Math.min(C, alphas[i] + alphas[j]);
        }

        // Si los límites coinciden, no hay margen de optimización en esta pareja; pasamos al siguiente
        if (L >= H) continue;

        // Calculamos la segunda derivada de la función objetivo (eta)
        // eta = 2 * K(x_i, x_j) - K(x_i, x_i) - K(x_j, x_j)
        const eta = 2 * K[i][j] - K[i][i] - K[j][j];

        // Si eta >= 0, la matriz no es definida negativa en este par; continuamos
        if (eta >= 0) continue;

        // Calculamos el nuevo valor sin recortar para alpha_j
        let newAlphaJ = alphaJold - (y[j] * (Ei - Ej)) / eta;

        // Recortamos alpha_j dentro de la caja factible [L, H] impuesta por el parámetro C
        if (newAlphaJ > H) newAlphaJ = H;
        if (newAlphaJ < L) newAlphaJ = L;

        // Si el cambio en alpha_j es insignificante (menor a 1e-4), no hacemos nada
        if (Math.abs(newAlphaJ - alphaJold) < 1e-4) continue;

        // Actualizamos alpha_i en sentido opuesto para conservar la restricción de igualdad ∑ α_k y_k = 0
        const newAlphaI = alphaIold + y[i] * y[j] * (alphaJold - newAlphaJ);
        alphas[i] = newAlphaI;
        alphas[j] = newAlphaJ;

        // Actualizamos el término independiente (bias b)
        const b1 = b - Ei - y[i] * (newAlphaI - alphaIold) * K[i][i] - y[j] * (newAlphaJ - alphaJold) * K[i][j];
        const b2 = b - Ej - y[i] * (newAlphaI - alphaIold) * K[i][j] - y[j] * (newAlphaJ - alphaJold) * K[j][j];

        // Escogemos el b que cumpla las condiciones de holgura
        if (newAlphaI > 0 && newAlphaI < C) b = b1;
        else if (newAlphaJ > 0 && newAlphaJ < C) b = b2;
        else b = (b1 + b2) / 2;

        // Registramos que hubo un cambio efectivo en esta iteración
        numChangedAlphas++;
      }
    }

    // Si no hubo ningún cambio en toda la pasada por el dataset, incrementamos el contador de pasadas
    if (numChangedAlphas === 0) passes++;
    // Si hubo cambios, reiniciamos el contador a 0 para asegurar convergencia sólida
    else passes = 0;
  }

  // Si el Kernel es LINEAL, podemos reconstruir explícitamente el vector normal de pesos w:
  // w = ∑ (α_i * y_i * x_i)
  const weights = new Array(d).fill(0);
  for (let i = 0; i < n; i++) {
    if (alphas[i] > 1e-5) {
      for (let j = 0; j < d; j++) {
        // Acumulamos la ponderación de cada vector de soporte en la dirección w
        weights[j] += alphas[i] * y[i] * X[i][j];
      }
    }
  }

  // Calculamos la norma euclidiana del vector de pesos: ||w|| = √(w₁² + w₂² + ...)
  let wNormSq = 0;
  for (let j = 0; j < d; j++) wNormSq += weights[j] * weights[j];
  const wNorm = Math.sqrt(wNormSq);

  // ANCHO DEL MARGEN GEOMÉTRICO: Margen = 2 / ||w||
  // Esta es la fórmula célebre que demuestra por qué maximizar el margen equivale a minimizar ||w||
  const marginWidth = wNorm > 0.001 ? 2 / wNorm : 0;

  /**
   * FUNCIÓN DE PREDICCIÓN EN ESPACIO NORMALIZADO
   * Calcula f(x) = sign(w · x + b) o f(x) = sign(∑ α_i y_i K(x_i, x) + b)
   */
  const predictNorm = (x: number[]) => {
    let score = b;
    // Si es lineal, usamos el producto punto directo w · x + b (muy rápido)
    if (kernel === 'linear') {
      for (let j = 0; j < d; j++) score += weights[j] * x[j];
    } else {
      // Si es RBF o Polinómico, evaluamos el kernel contra cada Vector de Soporte (α_i > 0)
      for (let i = 0; i < n; i++) {
        if (alphas[i] > 1e-5) {
          const kVal = computeKernel(X[i], x, { kernel, gamma, polyDegree });
          score += alphas[i] * y[i] * kVal;
        }
      }
    }
    // La clase predicha es +1 si f(x) >= 0, o -1 si f(x) < 0
    const label = score >= 0 ? 1 : -1;
    // Distancia perpendicular de la casa al hiperplano: d = f(x) / ||w||
    const distanceToHyperplane = wNorm > 0.001 ? score / wNorm : score;
    return { score, label, distanceToHyperplane };
  };

  // IDENTIFICACIÓN DE VECTORES DE SOPORTE Y CÁLCULO DE VARIABLES DE HOLGURA (ξ_i)
  const supportVectors: SupportVectorInfo[] = [];
  let totalSlack = 0;

  for (let i = 0; i < n; i++) {
    const { score } = predictNorm(X[i]);
    // Margen funcional: y_i * (w · x_i + b)
    const functionalMargin = y[i] * score;
    // Variable de holgura: ξ_i = max(0, 1 - y_i * f(x_i))
    // Si el punto está perfectamente clasificado y fuera del margen, ξ_i = 0
    // Si invade el margen o está del lado equivocado, ξ_i > 0
    const slack = Math.max(0, 1 - functionalMargin);
    totalSlack += slack;

    // Un punto es Vector de Soporte si su alpha > 0 o si está sobre/dentro del margen (margen funcional <= 1.05)
    const isSV = alphas[i] > 1e-4 || functionalMargin <= 1.05;

    if (isSV) {
      supportVectors.push({
        index: i,
        house: raw[i],
        coords: X[i],
        rawCoords: features.map((f) => raw[i][f]),
        alpha: alphas[i],
        target: y[i],
        slack: Math.max(0, slack),
        isMarginViolator: slack > 0.01,
      });
    }
  }

  /**
   * FUNCIÓN DE PREDICCIÓN EN VALORES REALES (RAW FEATURE SPACE)
   * Recibe un objeto de casa con valores reales (ej. Ingreso: $85,000, 7 habitaciones)
   * lo normaliza y calcula su veredicto SVM junto con una probabilidad calibrada por sigmoide.
   */
  const predictRaw = (rawPoint: Record<FeatureKey, number>) => {
    // Normalizamos el punto entrante usando los mínimos y máximos del dataset
    const normX = features.map((f, fi) => {
      const v = rawPoint[f];
      return ((v - dataset.mins[fi]) / (dataset.maxs[fi] - dataset.mins[fi])) * 2 - 1;
    });
    // Evaluamos el modelo SVM
    const res = predictNorm(normX);
    // Calibración de probabilidad de Platt (Sigmoide): P(y = +1 | x) = 1 / (1 + exp(-A * f(x)))
    const probability = 1 / (1 + Math.exp(-res.score * 1.5));
    return { score: res.score, label: res.label, probability };
  };

  // CÁLCULO DE MÉTRICAS ESTADÍSTICAS Y MATRIZ DE CONFUSIÓN
  let tp = 0; // Verdaderos Positivos (Lujo clasificado como Lujo)
  let fp = 0; // Falsos Positivos (Accesible clasificado como Lujo)
  let tn = 0; // Verdaderos Negativos (Accesible clasificado como Accesible)
  let fn = 0; // Falsos Negativos (Lujo clasificado como Accesible)

  for (let i = 0; i < n; i++) {
    const { label } = predictNorm(X[i]);
    const actual = y[i];
    if (actual === 1 && label === 1) tp++;
    else if (actual === -1 && label === 1) fp++;
    else if (actual === -1 && label === -1) tn++;
    else if (actual === 1 && label === -1) fn++;
  }

  // Exactitud (Accuracy): proporción de todas las clasificaciones correctas
  const accuracy = (tp + tn) / n;
  // Precisión: de las casas que dijimos que eran de Lujo, ¿cuántas lo eran de verdad?
  const precision = tp + fp > 0 ? tp / (tp + fp) : 0;
  // Exhaustividad / Recall: de todas las casas de Lujo reales, ¿cuántas detectamos?
  const recall = tp + fn > 0 ? tp / (tp + fn) : 0;
  // Puntuación F1: media armónica entre precisión y recall
  const f1Score = precision + recall > 0 ? (2 * precision * recall) / (precision + recall) : 0;

  // Retornamos el objeto completo del modelo SVM entrenado con todos sus componentes matemáticos
  return {
    weights,
    bias: b,
    marginWidth,
    supportVectors,
    accuracy,
    precision,
    recall,
    f1Score,
    confusionMatrix: { tp, fp, tn, fn },
    totalSlack,
    predict: predictNorm,
    predictRaw,
  };
}
