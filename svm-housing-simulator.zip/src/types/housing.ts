/**
 * DEFINICIONES DE TIPOS Y ESTRUCTURAS DE DATOS (TYPESCRIPT)
 * Modela las viviendas del dataset de EE.UU. y todos los conceptos de SVM.
 */

/**
 * Representa una vivienda individual dentro del conjunto de datos de precios de vivienda en EE.UU.
 */
export interface HousingRecord {
  // Identificador único para referenciar la vivienda en el DOM o en la lista
  id: string;
  // Dirección física de la propiedad
  address: string;
  // Ciudad donde se ubica la vivienda (ej. Los Angeles, Austin, Miami)
  city: string;
  // Estado de EE.UU. (código postal de dos letras: CA, TX, FL, etc.)
  state: string;
  // Ingreso promedio anual de los hogares en el área censal (en USD)
  avgAreaIncome: number;
  // Antigüedad media de la construcción en años
  avgHouseAge: number;
  // Promedio de habitaciones totales en la propiedad (incluye salones y dormitorios)
  avgRooms: number;
  // Promedio de dormitorios específicos
  avgBedrooms: number;
  // Población y densidad demográfica del vecindario
  areaPopulation: number;
  // Superficie habitable construida en pies cuadrados (sq ft)
  squareFeet: number;
  // Precio de tasación/venta de la vivienda en USD (variable continua base)
  price: number;
  // Bandera que indica si fue creada interactivamente por el usuario haciendo clic en el plano
  isCustom?: boolean;
}

/**
 * Claves válidas de las variables numéricas que el usuario puede proyectar en los ejes (2D y 3D)
 */
export type FeatureKey = 
  | 'avgAreaIncome'   // Ingreso medio del área
  | 'avgHouseAge'     // Antigüedad de la casa
  | 'avgRooms'        // Habitaciones totales
  | 'avgBedrooms'     // Dormitorios
  | 'areaPopulation'  // Población
  | 'squareFeet';     // Pies cuadrados de superficie

/**
 * Metadatos descriptivos de cada variable (etiquetas, unidades y formateadores visuales)
 */
export interface FeatureMeta {
  // Identificador de la variable
  key: FeatureKey;
  // Nombre formal para títulos y explicaciones
  label: string;
  // Nombre corto para botones y ejes compactos
  shortLabel: string;
  // Unidad de medida (ej. USD/año, años, habs, sq ft)
  unit: string;
  // Función para convertir el número en texto con formato legible
  format: (val: number) => string;
  // Valor mínimo razonable para los sliders interactivos
  min: number;
  // Valor máximo razonable para los sliders interactivos
  max: number;
  // Explicación pedagógica de lo que representa en economía urbana
  description: string;
}

/**
 * Tipos de Kernel soportados por el clasificador SVM
 */
export type KernelType = 
  | 'linear'  // Kernel lineal clásico: w·x + b = 0
  | 'rbf'     // Kernel de Base Radial (Gaussiano): exp(-γ ||x - x'||²)
  | 'poly';   // Kernel Polinómico: (x·x' + 1)^d

/**
 * Hiperparámetros configurables del modelo SVM
 */
export interface SVMHyperparameters {
  // Parámetro de regularización C: regula el balance entre margen amplio y penalización de errores
  C: number;
  // Función Kernel seleccionada
  kernel: KernelType;
  // Parámetro gamma (γ) para el kernel RBF: controla el radio de influencia de cada casa
  gamma: number;
  // Grado del polinomio (d) para el kernel polinómico
  polyDegree: number;
  // Precio umbral de corte ($): define qué casa es considerada Alta Gama (+1) vs Accesible (-1)
  priceThreshold: number;
}

/**
 * Información detallada de un punto que ha sido calificado como Vector de Soporte (SV)
 */
export interface SupportVectorInfo {
  // Posición del punto en el arreglo del dataset
  index: number;
  // Registro original de la vivienda con todos sus datos inmobiliarios
  house: HousingRecord;
  // Coordenadas del punto en el espacio normalizado [-1, 1]
  coords: number[];
  // Coordenadas originales sin normalizar (ej. [$85000, 7.2 habs])
  rawCoords: number[];
  // Multiplicador de Lagrange α_i asignado por el optimizador SMO
  alpha: number;
  // Etiqueta de clase real (+1 o -1)
  target: number;
  // Valor de holgura ξ_i (violación del margen, mayor a 0 si cruza el margen)
  slack: number;
  // Booleano: verdadero si el punto no solo toca el margen sino que lo viola
  isMarginViolator: boolean;
}

/**
 * Resultado integral generado tras entrenar el modelo SVM
 */
export interface SVMModelResult {
  // Vector normal de pesos w = [w_1, w_2, ...] (para el caso lineal)
  weights: number[];
  // Término de sesgo independiente (bias b)
  bias: number;
  // Ancho geométrico del margen: 2 / ||w||
  marginWidth: number;
  // Lista de todos los puntos identificados como Vectores de Soporte
  supportVectors: SupportVectorInfo[];
  // Exactitud global (Accuracy: proporción de aciertos sobre el total)
  accuracy: number;
  // Precisión (de las clasificadas como Lujo, cuántas eran reales)
  precision: number;
  // Recall / Sensibilidad (de todas las de Lujo, cuántas detectó el modelo)
  recall: number;
  // Puntuación F1 (media armónica entre precisión y recall)
  f1Score: number;
  // Matriz de confusión con conteos TP, FP, TN, FN
  confusionMatrix: {
    tp: number; // Verdaderos positivos
    fp: number; // Falsos positivos
    tn: number; // Verdaderos negativos
    fn: number; // Falsos negativos
  };
  // Sumatoria total de violaciones de holgura: ∑ ξ_i
  totalSlack: number;
  // Función para clasificar puntos en coordenadas normalizadas
  predict: (coords: number[]) => { score: number; label: number; distanceToHyperplane: number };
  // Función para clasificar puntos en valores reales inmobiliarios con probabilidad calibrada
  predictRaw: (rawPoint: Record<FeatureKey, number>) => { score: number; label: number; probability: number };
}

/**
 * Interruptores de visibilidad para cada capa y componente gráfico
 */
export interface SVMComponentHighlight {
  // Mostrar u ocultar la línea/plano del hiperplano de decisión (f(x) = 0)
  hyperplane: boolean;
  // Mostrar u ocultar las líneas/losas de margen positivo y negativo (f(x) = ±1)
  margins: boolean;
  // Resaltar con halos luminosos los Vectores de Soporte
  supportVectors: boolean;
  // Dibujar líneas de proyección de holgura (slack ξ) hacia el margen
  slackLines: boolean;
  // Mostrar el mapa de calor de las regiones de decisión en 2D
  decisionRegions: boolean;
  // Mostrar el vector normal w perpendicular al hiperplano
  normalVector: boolean;
}

/**
 * Pestañas principales de la aplicación
 */
export type AppTab = 
  | 'simulator'        // Simulador interactivo 2D y 3D
  | 'guided-learning'  // Tour pedagógico guiado paso a paso
  | 'challenges'       // Desafíos lúdicos y mini-juegos
  | 'predictor'        // Tasador de viviendas en tiempo real
  | 'math-lab';        // Laboratorio de fórmulas matemáticas interactivas
