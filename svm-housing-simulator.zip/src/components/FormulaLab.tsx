/**
 * LABORATORIO MATEMÁTICO INTERACTIVO DE SVM
 * Descompone la formulación primal y dual del problema de optimización cuadrática de SVM:
 * min (1/2)||w||² + C ∑ ξᵢ  sujeto a  yᵢ(w·xᵢ + b) ≥ 1 - ξᵢ
 * Permite hacer clic en cada símbolo (w, b, Margen, C, ξᵢ, αᵢ, K) para inspeccionar
 * su rol matemático, su equivalencia física en el mercado inmobiliario estadounidense
 * y el valor numérico calculado en tiempo real para el modelo actual.
 */

import React, { useState } from 'react';
import { SVMModelResult, SVMHyperparameters } from '../types/housing';
import { Sigma } from 'lucide-react';

/**
 * Propiedades del componente Laboratorio Matemático
 */
interface FormulaLabProps {
  // Modelo actual con pesos, sesgo, holgura y multiplicadores
  model: SVMModelResult;
  // Hiperparámetros de SVM actuales
  hyperparams: SVMHyperparameters;
}

export const FormulaLab: React.FC<FormulaLabProps> = ({ model, hyperparams }) => {
  // Símbolo matemático actualmente seleccionado para inspección
  const [selectedSymbol, setSelectedSymbol] = useState<string>('w');

  // Catálogo explicativo detallado de cada componente matemático de SVM
  const symbolExplanations: Record<string, { name: string; formulaSnippet: string; role: string; housingMeaning: string; currentValue: string }> = {
    w: {
      name: 'Vector de Pesos (Normal)',
      formulaSnippet: 'w = [w₁, w₂, ..., w_d]',
      role: 'Determina la inclinación y orientación del hiperplano en el espacio.',
      housingMeaning: 'Mide la importancia relativa de cada variable. Si w_ingreso > w_antigüedad, el modelo considera el ingreso más influyente para definir si una casa es de lujo.',
      currentValue: model.weights.map((w, i) => `w${i + 1} = ${w.toFixed(3)}`).join(', ') || 'N/A (Kernel no lineal)',
    },
    b: {
      name: 'Sesgo o Intercepto (Bias)',
      formulaSnippet: 'b ∈ ℝ',
      role: 'Desplaza el hiperplano alejándolo o acercándolo al origen de coordenadas.',
      housingMeaning: 'Actúa como el listón base del mercado inmobiliario. Calibra el umbral de corte global para balancear las clases.',
      currentValue: `b = ${model.bias.toFixed(3)}`,
    },
    margin: {
      name: 'Ancho del Margen Geométrico',
      formulaSnippet: 'Margen = 2 / ||w||',
      role: 'La distancia euclidiana total entre el margen positivo (+1) y el negativo (-1).',
      housingMeaning: 'La "zona de seguridad". Un margen más ancho significa que el clasificador es más robusto y menos propenso a equivocarse ante fluctuaciones del mercado.',
      currentValue: `Ancho = ${model.marginWidth.toFixed(3)} unidades normalizadas`,
    },
    C: {
      name: 'Parámetro de Regularización C',
      formulaSnippet: 'min (1/2)||w||² + C ∑ ξᵢ',
      role: 'Controla el balance entre maximizar el margen y minimizar los errores de clasificación.',
      housingMeaning: 'Un C alto obliga al modelo a no tolerar ninguna casa fuera de lugar. Un C bajo acepta casas atípicas (outliers) para mantener una frontera suave.',
      currentValue: `C = ${hyperparams.C}`,
    },
    xi: {
      name: 'Variables de Holgura (Slack Variables)',
      formulaSnippet: 'ξᵢ = max(0, 1 - yᵢ(w·xᵢ + b))',
      role: 'Miden la distancia en que un punto de datos invade el margen o cruza al lado incorrecto.',
      housingMeaning: 'Cuantifica qué tan anómala es una vivienda respecto a la norma general (ej. una mansión vendida muy barata por urgencia del vendedor).',
      currentValue: `∑ ξᵢ total = ${model.totalSlack.toFixed(2)}`,
    },
    alpha: {
      name: 'Multiplicadores de Lagrange (αᵢ)',
      formulaSnippet: '0 ≤ αᵢ ≤ C',
      role: 'Ponderación dual de cada vivienda en la solución óptima de SVM.',
      housingMeaning: 'Si αᵢ = 0, la casa no influye para nada. Si αᵢ > 0, esa casa es un Vector de Soporte que sostiene activamente la frontera.',
      currentValue: `${model.supportVectors.length} casas tienen α > 0 (Vectores de Soporte)`,
    },
    kernel: {
      name: 'Función Kernel K(x, x\')',
      formulaSnippet: hyperparams.kernel === 'rbf' ? 'exp(-γ ||x - x\'||²)' : hyperparams.kernel === 'poly' ? '(x·x\' + 1)^d' : 'x · x\'',
      role: 'Calcula el producto interno en un espacio dimensional superior sin transformar los datos explícitamente.',
      housingMeaning: 'Permite capturar dinámicas complejas (ej. viviendas caras agrupadas en zonas circulares o en anillos concéntricos alrededor de un lago o centro urbano).',
      currentValue: `Kernel actual: ${hyperparams.kernel.toUpperCase()} (γ = ${hyperparams.gamma})`,
    },
  };

  const currentInfo = symbolExplanations[selectedSymbol] || symbolExplanations.w;

  return (
    <div className="flex flex-col h-full bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-2xl space-y-6">
      {/* 1. ENCABEZADO DIDÁCTICO */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center border border-purple-500/30">
            <Sigma className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">Laboratorio Matemático de SVM</h2>
            <p className="text-xs text-slate-400">Haz clic en cada símbolo para entender su impacto físico en el mercado</p>
          </div>
        </div>
      </div>

      {/* 2. BARRA INTERACTIVA CON LA ECUACIÓN PRIMAL DE OPTIMIZACIÓN */}
      <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 text-center space-y-3">
        <span className="text-[11px] font-mono uppercase tracking-wider text-slate-500 block">
          Problema de Optimización Primal (Soft Margin SVM)
        </span>

        {/* Ecuación interactiva con botones clickeables */}
        <div className="flex flex-wrap items-center justify-center gap-2 font-mono text-base md:text-xl font-extrabold text-slate-300">
          <span className="text-slate-500">min</span>
          <button
            onClick={() => setSelectedSymbol('margin')}
            className={`px-2 py-1 rounded-lg border transition cursor-pointer ${
              selectedSymbol === 'margin' ? 'bg-indigo-600 text-white border-indigo-400 shadow-md' : 'bg-slate-900 text-indigo-400 border-indigo-500/30 hover:bg-slate-800'
            }`}
          >
            ½ ||w||²
          </button>
          <span className="text-slate-500">+</span>
          <button
            onClick={() => setSelectedSymbol('C')}
            className={`px-2 py-1 rounded-lg border transition cursor-pointer ${
              selectedSymbol === 'C' ? 'bg-amber-600 text-white border-amber-400 shadow-md' : 'bg-slate-900 text-amber-400 border-amber-500/30 hover:bg-slate-800'
            }`}
          >
            C
          </button>
          <button
            onClick={() => setSelectedSymbol('xi')}
            className={`px-2 py-1 rounded-lg border transition cursor-pointer ${
              selectedSymbol === 'xi' ? 'bg-rose-600 text-white border-rose-400 shadow-md' : 'bg-slate-900 text-rose-400 border-rose-500/30 hover:bg-slate-800'
            }`}
          >
            ∑ ξᵢ
          </button>
        </div>

        {/* Restricciones de Karush-Kuhn-Tucker (KKT) */}
        <div className="flex flex-wrap items-center justify-center gap-2 text-xs font-mono text-slate-400 pt-1">
          <span>Sujeto a:</span>
          <span className="text-slate-300">yᵢ (</span>
          <button
            onClick={() => setSelectedSymbol('w')}
            className={`px-1.5 py-0.5 rounded border transition cursor-pointer ${
              selectedSymbol === 'w' ? 'bg-indigo-600 text-white border-indigo-400' : 'bg-slate-900 text-indigo-400 border-slate-700'
            }`}
          >
            w
          </button>
          <span>· xᵢ +</span>
          <button
            onClick={() => setSelectedSymbol('b')}
            className={`px-1.5 py-0.5 rounded border transition cursor-pointer ${
              selectedSymbol === 'b' ? 'bg-indigo-600 text-white border-indigo-400' : 'bg-slate-900 text-indigo-400 border-slate-700'
            }`}
          >
            b
          </button>
          <span>) ≥ 1 -</span>
          <button
            onClick={() => setSelectedSymbol('xi')}
            className={`px-1.5 py-0.5 rounded border transition cursor-pointer ${
              selectedSymbol === 'xi' ? 'bg-rose-600 text-white border-rose-400' : 'bg-slate-900 text-rose-400 border-slate-700'
            }`}
          >
            ξᵢ
          </button>
        </div>

        {/* Botones para multiplicadores duales alfa y kernel */}
        <div className="flex justify-center gap-2 pt-2">
          <button
            onClick={() => setSelectedSymbol('alpha')}
            className={`text-xs px-2.5 py-1 rounded-lg font-mono border cursor-pointer ${
              selectedSymbol === 'alpha' ? 'bg-purple-600 text-white border-purple-400' : 'bg-slate-900 text-purple-400 border-purple-900/50'
            }`}
          >
            Multiplicadores Duales (αᵢ)
          </button>
          <button
            onClick={() => setSelectedSymbol('kernel')}
            className={`text-xs px-2.5 py-1 rounded-lg font-mono border cursor-pointer ${
              selectedSymbol === 'kernel' ? 'bg-cyan-600 text-white border-cyan-400' : 'bg-slate-900 text-cyan-400 border-cyan-900/50'
            }`}
          >
            Función Kernel K(x, x')
          </button>
        </div>
      </div>

      {/* 3. EXPLICACIÓN DETALLADA DEL SÍMBOLO SELECCIONADO */}
      <div className="bg-slate-950 p-6 rounded-2xl border border-slate-800 space-y-4 flex-1 overflow-y-auto pr-1">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-base font-bold text-white">{currentInfo.name}</h3>
            <span className="text-xs font-mono text-indigo-400">{currentInfo.formulaSnippet}</span>
          </div>
          <div className="bg-slate-900 px-3 py-1.5 rounded-xl border border-slate-800 text-xs font-mono text-emerald-400">
            {currentInfo.currentValue}
          </div>
        </div>

        <div className="space-y-3 text-xs leading-relaxed">
          <div>
            <strong className="text-slate-400 block mb-1">Rol Matemático en SVM:</strong>
            <p className="text-slate-300">{currentInfo.role}</p>
          </div>

          <div className="bg-indigo-950/25 border border-indigo-800/40 p-3.5 rounded-xl">
            <strong className="text-indigo-300 block mb-1">Significado en el Mercado de Viviendas (EE.UU.):</strong>
            <p className="text-slate-300">{currentInfo.housingMeaning}</p>
          </div>
        </div>
      </div>
    </div>
  );
};
