/**
 * BARRA DE MÉTRICAS EN TIEMPO REAL DE LA MÁQUINA DE SOPORTE VECTORIAL (SVM)
 * Muestra el porcentaje de exactitud (Accuracy), el ancho geométrico del margen (2/||w||),
 * el número y porcentaje de vectores de soporte, la sumatoria total de holguras (∑ξ),
 * y despliega la matriz de confusión interactiva con métricas de Precisión, Sensibilidad (Recall) y F1-Score.
 */

import React, { useState } from 'react';
import { SVMModelResult, SVMHyperparameters } from '../types/housing';
import { Activity, ShieldCheck, Maximize2, AlertTriangle, BarChart3 } from 'lucide-react';

/**
 * Propiedades recibidas por la Barra de Métricas
 */
interface MetricsBarProps {
  // Objeto con los resultados cuantitativos calculados por svmSolver
  model: SVMModelResult;
  // Hiperparámetros activos de la máquina de soporte vectorial
  hyperparams: SVMHyperparameters;
  // Cantidad total de viviendas en el conjunto de datos actual
  totalHouses: number;
}

export const MetricsBar: React.FC<MetricsBarProps> = ({ model, hyperparams, totalHouses }) => {
  // Estado para alternar la visibilidad de la ventana modal emergente de la matriz de confusión
  const [showConfusionMatrix, setShowConfusionMatrix] = useState(false);

  // Porcentaje de muestras que actúan como vectores de soporte: (SV / N) * 100
  const svPercentage = Math.round((model.supportVectors.length / totalHouses) * 100);

  return (
    <div className="relative bg-slate-900/80 backdrop-blur-md rounded-2xl border border-slate-800 p-3.5 shadow-lg">
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-3 items-center">
        {/* MÉTRICA 1: Exactitud Global (Accuracy = (TP + TN) / Total) */}
        <div className="flex items-center gap-3 bg-slate-950/70 p-2.5 rounded-xl border border-slate-800/80">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
            <Activity className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <div className="text-[10px] uppercase font-mono text-slate-400">Exactitud (Acc)</div>
            <div className="text-base font-bold text-white font-mono">
              {(model.accuracy * 100).toFixed(1)}%
            </div>
          </div>
        </div>

        {/* MÉTRICA 2: Ancho Geométrico del Margen (M = 2 / ||w||) */}
        <div className="flex items-center gap-3 bg-slate-950/70 p-2.5 rounded-xl border border-slate-800/80">
          <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0">
            <Maximize2 className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <div className="text-[10px] uppercase font-mono text-slate-400">Ancho Margen (2/||w||)</div>
            <div className="text-base font-bold text-indigo-300 font-mono">
              {model.marginWidth.toFixed(2)}
            </div>
          </div>
        </div>

        {/* MÉTRICA 3: Conteo y Porcentaje de Vectores de Soporte (Muestras Críticas) */}
        <div className="flex items-center gap-3 bg-slate-950/70 p-2.5 rounded-xl border border-slate-800/80">
          <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
            <ShieldCheck className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <div className="text-[10px] uppercase font-mono text-slate-400">Vectores Soporte</div>
            <div className="text-base font-bold text-amber-300 font-mono">
              {model.supportVectors.length} <span className="text-xs text-slate-500 font-normal">({svPercentage}%)</span>
            </div>
          </div>
        </div>

        {/* MÉTRICA 4: Sumatoria de Variables de Holgura (Penalización por Violación ∑ξ_i) */}
        <div className="flex items-center gap-3 bg-slate-950/70 p-2.5 rounded-xl border border-slate-800/80">
          <div className="w-8 h-8 rounded-lg bg-rose-500/20 text-rose-400 flex items-center justify-center shrink-0">
            <AlertTriangle className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <div className="text-[10px] uppercase font-mono text-slate-400">Violación Holgura (∑ξ)</div>
            <div className="text-base font-bold text-rose-300 font-mono">
              {model.totalSlack.toFixed(1)}
            </div>
          </div>
        </div>

        {/* BOTÓN 5: Desplegable de la Matriz de Confusión */}
        <div className="col-span-2 sm:col-span-4 lg:col-span-1 flex items-center justify-end">
          <button
            onClick={() => setShowConfusionMatrix(!showConfusionMatrix)}
            className="w-full lg:w-auto px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-2 transition border border-slate-700 cursor-pointer"
          >
            <BarChart3 className="w-4 h-4 text-indigo-400" />
            <span>Matriz Confusión</span>
          </button>
        </div>
      </div>

      {/* MODAL FLOTANTE DE LA MATRIZ DE CONFUSIÓN */}
      {showConfusionMatrix && (
        <div className="absolute right-4 top-full mt-2 z-50 bg-slate-950 border border-slate-800 p-4 rounded-xl shadow-2xl text-xs font-mono space-y-2 animate-fadeIn">
          {/* Encabezado con el tamaño total de la muestra N */}
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="font-bold text-white">Matriz de Confusión</span>
            <span className="text-[10px] text-slate-500">N = {totalHouses}</span>
          </div>

          {/* Cuadrícula 2x2: TP, FP, FN, TN */}
          <div className="grid grid-cols-2 gap-2 text-center">
            {/* Casillas Verdaderos Positivos: Alta Gama clasificada como Alta Gama */}
            <div className="bg-emerald-950/40 border border-emerald-900/60 p-2 rounded">
              <div className="text-[10px] text-emerald-400">Verdaderos Positivos (TP)</div>
              <div className="text-sm font-bold text-white">{model.confusionMatrix.tp}</div>
            </div>
            {/* Falsos Positivos: Accesible erróneamente clasificada como Alta Gama */}
            <div className="bg-rose-950/40 border border-rose-900/60 p-2 rounded">
              <div className="text-[10px] text-rose-400">Falsos Positivos (FP)</div>
              <div className="text-sm font-bold text-white">{model.confusionMatrix.fp}</div>
            </div>
            {/* Falsos Negativos: Alta Gama erróneamente clasificada como Accesible */}
            <div className="bg-rose-950/40 border border-rose-900/60 p-2 rounded">
              <div className="text-[10px] text-rose-400">Falsos Negativos (FN)</div>
              <div className="text-sm font-bold text-white">{model.confusionMatrix.fn}</div>
            </div>
            {/* Verdaderos Negativos: Accesible clasificada como Accesible */}
            <div className="bg-cyan-950/40 border border-cyan-900/60 p-2 rounded">
              <div className="text-[10px] text-cyan-400">Verdaderos Negativos (TN)</div>
              <div className="text-sm font-bold text-white">{model.confusionMatrix.tn}</div>
            </div>
          </div>

          {/* Desglose de Precisión, Sensibilidad (Recall) y Puntuación F1 armónica */}
          <div className="text-[10px] text-slate-400 pt-1 flex justify-between">
            <span>Precisión: {(model.precision * 100).toFixed(1)}%</span>
            <span>Recall: {(model.recall * 100).toFixed(1)}%</span>
            <span>F1-Score: {model.f1Score.toFixed(2)}</span>
          </div>
        </div>
      )}
    </div>
  );
};
