/**
 * GUÍA PEDAGÓGICA INTERACTIVA PASO A PASO DE SVM
 * Enseña los 5 fundamentos esenciales de las Máquinas de Soporte Vectorial con analogías del mundo inmobiliario,
 * ecuaciones matemáticas explicadas término a término y botones que aplican presets automáticos al simulador.
 */

import React, { useState } from 'react';
import { SVMHyperparameters, FeatureKey } from '../types/housing';
import { BookOpen, CheckCircle2, ArrowRight, ArrowLeft, Lightbulb, Play, Layers } from 'lucide-react';
import confetti from 'canvas-confetti';

/**
 * Propiedades del componente Guía Pedagógica
 */
interface PedagogicalGuideProps {
  // Callback para inyectar los hiperparámetros del paso actual directamente en el simulador interactivo
  onApplyPreset: (params: Partial<SVMHyperparameters>, feats?: [FeatureKey, FeatureKey]) => void;
  // Hiperparámetros que están configurados actualmente
  currentHyperparams: SVMHyperparameters;
}

/**
 * Estructura de cada lección didáctica
 */
interface Step {
  id: number;
  title: string;
  subtitle: string;
  badge: string;
  analogy: string;
  explanation: string;
  math: {
    formula: string;
    description: string;
  };
  presetAction?: {
    label: string;
    params: Partial<SVMHyperparameters>;
    feats?: [FeatureKey, FeatureKey];
  };
  keyTakeaway: string;
}

// Catálogo de lecciones pedagógicas estructuradas progresivamente
const STEPS: Step[] = [
  {
    id: 1,
    title: '1. El Hiperplano de Decisión',
    subtitle: 'La frontera geométrica que separa las clases',
    badge: 'Concepto Fundamental',
    analogy: 'Imagina trazar una carretera recta a través de una ciudad que divide a la perfección los barrios con casas de lujo de los barrios con casas asequibles.',
    explanation: 'En 2 dimensiones (ej. Ingreso vs Superficie), el hiperplano es simplemente una línea recta. En 3 dimensiones (Ingreso vs Habitaciones vs Antigüedad), es un plano plano en el espacio. En N dimensiones, es un hiperplano de dimensión N-1.',
    math: {
      formula: 'w · x + b = 0',
      description: 'Donde "w" es el vector normal (perpendicular) que orienta la frontera y "b" es el sesgo (bias) que la desplaza desde el origen.',
    },
    presetAction: {
      label: 'Ver Hiperplano Lineal Limpio',
      params: { C: 1.0, kernel: 'linear', priceThreshold: 500000 },
      feats: ['avgAreaIncome', 'squareFeet'],
    },
    keyTakeaway: 'Si w · x + b > 0, la casa se clasifica como Alta Gama (+1). Si es < 0, es Asequible (-1).',
  },
  {
    id: 2,
    title: '2. El Margen Máximo',
    subtitle: '¿Por qué no cualquier línea divisoria es buena?',
    badge: 'La Magia de SVM',
    analogy: 'Si construyes una carretera divisoria, no quieres que pase rozando la ventana de ninguna casa. Quieres el "bulevar más ancho posible" para evitar accidentes (errores futuros).',
    explanation: 'Muchas líneas podrían separar los dos grupos de casas, pero la Máquina de Soporte Vectorial busca la única línea que maximiza la distancia (el margen) a las casas más cercanas de ambos lados.',
    math: {
      formula: 'Ancho del Margen = 2 / ||w||',
      description: 'Maximizar el margen equivale matemáticamente a minimizar (1/2) ||w||², sujeto a que todas las casas queden del lado correcto.',
    },
    presetAction: {
      label: 'Mostrar Bandas de Margen ±1',
      params: { C: 10.0, kernel: 'linear' },
      feats: ['avgAreaIncome', 'avgRooms'],
    },
    keyTakeaway: 'A mayor margen de separación, mayor capacidad del modelo para clasificar correctamente casas nuevas que no vio durante el entrenamiento.',
  },
  {
    id: 3,
    title: '3. Los Héroes: Vectores de Soporte',
    subtitle: 'El 90% de los datos no importan',
    badge: 'Componente Clave',
    analogy: 'Imagina un puente colgante: solo los pilares y cables clave soportan todo el peso. Si eliminas las piedras del lecho del río, el puente no se cae.',
    explanation: 'Los Vectores de Soporte son únicamente los puntos (viviendas) críticos que tocan o violan los márgenes. Si eliminas el resto de las casas que están lejos de la frontera, ¡el hiperplano resultante es idéntico!',
    math: {
      formula: 'yᵢ (w · xᵢ + b) = 1   o   αᵢ > 0',
      description: 'Solo los datos con multiplicador de Lagrange αᵢ > 0 definen el hiperplano w = ∑ αᵢ yᵢ xᵢ.',
    },
    presetAction: {
      label: 'Resaltar Vectores de Soporte',
      params: { C: 1.0, kernel: 'linear' },
      feats: ['avgAreaIncome', 'avgHouseAge'],
    },
    keyTakeaway: 'Esto hace que SVM sea extraordinariamente eficiente en memoria y resistente a cambios en datos lejanos.',
  },
  {
    id: 4,
    title: '4. El Dilema del Parámetro C (Soft Margin)',
    subtitle: 'Equilibrio entre margen amplio y tolerancia a fallos',
    badge: 'Regularización',
    analogy: '¿Prefieres una regla estricta que castiga sin piedad cada excepción (C alto), o una regla flexible y realista que tolera alguna casa atípica para mantener una carretera despejada (C bajo)?',
    explanation: 'En el mundo real, los datos no son perfectamente separables: puede haber una casa barata en un barrio rico. Las variables de holgura (ξᵢ) miden cuánto invade una casa el margen.',
    math: {
      formula: 'Minimizar: (1/2) ||w||² + C ∑ ξᵢ',
      description: 'C controla el costo de las penalizaciones: C alto = margen estrecho pero sin violaciones (Hard Margin). C bajo = margen ancho tolerante (Soft Margin).',
    },
    presetAction: {
      label: 'Probar C Pequeño (Margen Blando)',
      params: { C: 0.05, kernel: 'linear' },
    },
    keyTakeaway: 'Un C bien ajustado previene el sobreajuste (overfitting) cuando el mercado inmobiliario tiene ruido.',
  },
  {
    id: 5,
    title: '5. El Truco del Kernel (Kernel Trick)',
    subtitle: 'Cómo doblar el espacio para separar lo inseparable',
    badge: 'Avanzado & Fascinante',
    analogy: 'Si tienes puntos rojos en un círculo central rodeados de puntos azules, ninguna tijera recta puede separarlos en una mesa plana. ¡Pero si levantas el centro de la hoja hacia arriba formando una colina, un cuchillo horizontal corta entre ambos!',
    explanation: 'El Truco del Kernel proyecta los datos a una dimensión superior (como en nuestra vista 3D) calculando productos internos K(x, x\') sin necesidad de calcular explícitamente las coordenadas gigantes.',
    math: {
      formula: 'K(x, x\') = exp(-γ ||x - x\'||²)',
      description: 'Kernel RBF Gaussiano: mide la similitud radial entre casas. Transforma fronteras curvas o circulares en problemas separables.',
    },
    presetAction: {
      label: 'Activar Kernel RBF Gaussiano',
      params: { C: 2.0, kernel: 'rbf', gamma: 1.5 },
      feats: ['avgHouseAge', 'squareFeet'],
    },
    keyTakeaway: 'Permite a SVM aprender relaciones no lineales ultra-complejas en el precio de las viviendas.',
  },
];

export const PedagogicalGuide: React.FC<PedagogicalGuideProps> = ({
  onApplyPreset,
}) => {
  // Índice del paso pedagógico que está activo en la visualización (0 a 4)
  const [activeStepIdx, setActiveStepIdx] = useState(0);
  const step = STEPS[activeStepIdx];

  // Aplica la configuración preestablecida del paso actual y lanza confeti animado
  const handleApplyPreset = () => {
    if (step.presetAction) {
      onApplyPreset(step.presetAction.params, step.presetAction.feats);
      confetti({
        particleCount: 40,
        spread: 60,
        origin: { y: 0.8 },
      });
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-2xl space-y-6">
      {/* 1. ENCABEZADO Y SELECTOR NUMÉRICO DE PASOS */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">Guía Interactiva: Aprende SVM Paso a Paso</h2>
            <p className="text-xs text-slate-400">Descubre cada componente matemático de forma lúdica e intuitiva</p>
          </div>
        </div>

        {/* Botones circulares con los números del 1 al 5 */}
        <div className="flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800">
          {STEPS.map((s, idx) => (
            <button
              key={s.id}
              onClick={() => setActiveStepIdx(idx)}
              className={`w-7 h-7 rounded-lg text-xs font-bold transition-all flex items-center justify-center cursor-pointer ${
                activeStepIdx === idx
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/30'
                  : 'text-slate-500 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {s.id}
            </button>
          ))}
        </div>
      </div>

      {/* 2. TARJETA DIDÁCTICA PRINCIPAL DEL PASO */}
      <div className="flex-1 overflow-y-auto space-y-6 pr-1">
        {/* Banner con título, insignia de concepto y botón de acción */}
        <div className="flex items-start justify-between gap-4 bg-gradient-to-r from-indigo-950/60 to-purple-950/40 p-5 rounded-2xl border border-indigo-800/40">
          <div className="space-y-1">
            <span className="inline-block px-2.5 py-0.5 rounded-md text-[11px] font-bold font-mono tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              {step.badge}
            </span>
            <h3 className="text-xl font-extrabold text-white">{step.title}</h3>
            <p className="text-sm text-slate-300 font-medium">{step.subtitle}</p>
          </div>

          {step.presetAction && (
            <button
              onClick={handleApplyPreset}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 text-white text-xs font-bold shadow-lg shadow-indigo-500/25 hover:opacity-95 transition flex items-center gap-2 shrink-0 cursor-pointer"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              {step.presetAction.label}
            </button>
          )}
        </div>

        {/* Comparativa: Analogía de la vida real vs Rigor geométrico */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800/80 space-y-2">
            <div className="flex items-center gap-2 text-amber-400 font-semibold text-xs uppercase tracking-wider font-mono">
              <Lightbulb className="w-4 h-4" />
              <span>Analogía con Casas de EE.UU.</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed italic">
              "{step.analogy}"
            </p>
          </div>

          <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800/80 space-y-2">
            <div className="flex items-center gap-2 text-indigo-400 font-semibold text-xs uppercase tracking-wider font-mono">
              <Layers className="w-4 h-4" />
              <span>Explicación Geométrica</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              {step.explanation}
            </p>
          </div>
        </div>

        {/* Desglose Matemático Formal */}
        <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider">
              Ecuación Matemática del Componente
            </span>
            <span className="text-[10px] text-slate-500 font-mono">Cálculo Vectorial SVM</span>
          </div>

          <div className="bg-slate-900/90 py-3 px-4 rounded-lg border border-slate-700/60 text-center font-mono text-base md:text-lg font-bold text-emerald-400 shadow-inner">
            {step.math.formula}
          </div>

          <p className="text-xs text-slate-400 leading-relaxed">
            {step.math.description}
          </p>
        </div>

        {/* Conclusión clave del paso */}
        <div className="flex items-center gap-3 bg-emerald-950/30 border border-emerald-800/40 p-3.5 rounded-xl text-xs text-emerald-300">
          <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
          <div>
            <strong className="font-semibold text-emerald-200">Conclusión clave: </strong>
            <span>{step.keyTakeaway}</span>
          </div>
        </div>
      </div>

      {/* 3. BARRA DE NAVEGACIÓN INFERIOR (ANTERIOR / SIGUIENTE) */}
      <div className="flex items-center justify-between pt-3 border-t border-slate-800">
        <button
          onClick={() => setActiveStepIdx((prev) => Math.max(0, prev - 1))}
          disabled={activeStepIdx === 0}
          className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800 disabled:opacity-40 disabled:hover:bg-transparent transition flex items-center gap-1.5 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          Anterior
        </button>

        <span className="text-xs font-mono text-slate-500">
          Paso {activeStepIdx + 1} de {STEPS.length}
        </span>

        <button
          onClick={() => setActiveStepIdx((prev) => Math.min(STEPS.length - 1, prev + 1))}
          disabled={activeStepIdx === STEPS.length - 1}
          className="px-4 py-2 rounded-xl text-xs font-semibold bg-indigo-600 text-white hover:bg-indigo-500 disabled:opacity-40 transition flex items-center gap-1.5 shadow-md shadow-indigo-600/30 cursor-pointer"
        >
          Siguiente
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
