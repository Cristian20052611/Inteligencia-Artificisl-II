/**
 * DESAFÍOS LÚDICOS Y GAMIFICADOS DE SVM
 * Ofrece 3 retos interactivos:
 * 1. "Caza al Vector": Adivinar cuál de las casas mostradas es un vector de soporte auténtico.
 * 2. "Domina el Parámetro C": Encontrar el valor de C óptimo para balancear margen y exactitud.
 * 3. "Tasación Misteriosa": Predecir la clasificación de una casa nunca antes vista evaluando f(x).
 */

import React, { useState } from 'react';
import { HousingRecord, FeatureKey, SVMHyperparameters, SVMModelResult } from '../types/housing';
import { Trophy, Check, X, Sparkles, Target, Zap } from 'lucide-react';
import confetti from 'canvas-confetti';

/**
 * Propiedades del componente de Desafíos
 */
interface SVMChallengesProps {
  // Lista de viviendas disponibles
  records: HousingRecord[];
  // Resultado del modelo SVM entrenado actualmente
  model: SVMModelResult;
  // Hiperparámetros activos
  hyperparams: SVMHyperparameters;
  // Tupla de características utilizadas
  features: [FeatureKey, FeatureKey];
  // Callback para cambiar el valor de C desde el desafío interactivo
  onTuneC: (newC: number) => void;
}

export const SVMChallenges: React.FC<SVMChallengesProps> = ({
  records,
  model,
  hyperparams,
  onTuneC,
}) => {
  // Estado del reto que se está jugando (1, 2 o 3)
  const [activeChallenge, setActiveChallenge] = useState<1 | 2 | 3>(1);

  // ESTADO DEL DESAFÍO 1: Candidatos para adivinar el vector de soporte
  const candidateHouses = records.slice(0, 4);
  const [selectedCandidateId, setSelectedCandidateId] = useState<string | null>(null);
  const [c1Feedback, setC1Feedback] = useState<{ isCorrect: boolean; text: string } | null>(null);

  // ESTADO DEL DESAFÍO 2: Ajuste óptimo del parámetro C
  const [cTargetMet, setCTargetMet] = useState(false);

  // ESTADO DEL DESAFÍO 3: Vivienda misteriosa de prueba en Denver
  const mysteryHouse = {
    address: '450 Willow Creek Rd',
    city: 'Denver',
    state: 'CO',
    avgAreaIncome: 86500,
    avgHouseAge: 5.2,
    avgRooms: 7.6,
    avgBedrooms: 3.8,
    areaPopulation: 31000,
    squareFeet: 2900,
  };
  const [c3Prediction, setC3Prediction] = useState<number | null>(null);
  const [c3Result, setC3Result] = useState<boolean | null>(null);

  // EVALUADOR DEL DESAFÍO 1: Comprueba si la casa elegida es realmente un Vector de Soporte
  const handleCheckC1 = (house: HousingRecord) => {
    setSelectedCandidateId(house.id);
    const isSV = model.supportVectors.some((sv) => sv.house.id === house.id);
    if (isSV) {
      setC1Feedback({
        isCorrect: true,
        text: `¡Correcto! Esta vivienda en ${house.city} se encuentra exactamente en la banda del margen o lo viola. Es uno de los ${model.supportVectors.length} pilares que sostienen el hiperplano.`,
      });
      // Lanzamos confeti al acertar
      confetti({ particleCount: 50, spread: 70, origin: { y: 0.7 } });
    } else {
      setC1Feedback({
        isCorrect: false,
        text: `Cerca, pero no. Esta casa está retirada de la frontera de decisión (en zona segura). Si la borramos del dataset, el hiperplano no se movería ni un milímetro.`,
      });
    }
  };

  // EVALUADOR DEL DESAFÍO 2: Evalúa si el valor de C elegido logra el compromiso ideal
  const handleTestC = (newCVal: number) => {
    onTuneC(newCVal);
    // Condición de éxito: C en el rango [0.2, 4.0] con exactitud superior al 85%
    if (newCVal >= 0.2 && newCVal <= 4.0 && model.accuracy >= 0.85) {
      setCTargetMet(true);
      confetti({ particleCount: 60, spread: 80, origin: { y: 0.6 } });
    } else {
      setCTargetMet(false);
    }
  };

  // EVALUADOR DEL DESAFÍO 3: Contrasta la predicción del usuario con la función de decisión del SVM
  const handlePredictC3 = (guess: number) => {
    setC3Prediction(guess);
    const pred = model.predictRaw(mysteryHouse);
    const correct = guess === pred.label;
    setC3Result(correct);
    if (correct) {
      confetti({ particleCount: 60, spread: 80, origin: { y: 0.6 } });
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-2xl space-y-6">
      {/* 1. SELECTOR SUPERIOR DE DESAFÍOS */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
            <Trophy className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">Desafíos Lúdicos de SVM</h2>
            <p className="text-xs text-slate-400">Pon a prueba tu intuición geométrica y matemática</p>
          </div>
        </div>

        {/* Botones para conmutar entre los tres desafíos */}
        <div className="flex items-center gap-2 bg-slate-950 p-1.5 rounded-xl border border-slate-800">
          <button
            onClick={() => setActiveChallenge(1)}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              activeChallenge === 1 ? 'bg-amber-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            1. Caza al Vector
          </button>
          <button
            onClick={() => setActiveChallenge(2)}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              activeChallenge === 2 ? 'bg-amber-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            2. Domina el Parámetro C
          </button>
          <button
            onClick={() => setActiveChallenge(3)}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              activeChallenge === 3 ? 'bg-amber-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            3. Tasación Misteriosa
          </button>
        </div>
      </div>

      {/* 2. DESAFÍO 1: CAZA AL VECTOR DE SOPORTE */}
      {activeChallenge === 1 && (
        <div className="space-y-5 flex-1 overflow-y-auto pr-1">
          <div className="bg-amber-950/20 border border-amber-800/40 p-4 rounded-xl space-y-1">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-xs">
              <Target className="w-4 h-4" />
              <span>Misión: Identifica cuál de estas 4 viviendas sostiene el hiperplano</span>
            </div>
            <p className="text-xs text-slate-300">
              Recuerda que solo los puntos situados exactamente sobre los márgenes o que los violan son Vectores de Soporte.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {candidateHouses.map((h) => {
              const isSV = model.supportVectors.some((sv) => sv.house.id === h.id);
              const isSelected = selectedCandidateId === h.id;

              return (
                <div
                  key={h.id}
                  onClick={() => handleCheckC1(h)}
                  className={`p-4 rounded-xl border text-left cursor-pointer transition-all ${
                    isSelected
                      ? isSV
                        ? 'bg-emerald-950/40 border-emerald-500 shadow-lg shadow-emerald-950/50'
                        : 'bg-rose-950/40 border-rose-500'
                      : 'bg-slate-950/80 border-slate-800 hover:border-indigo-500/50 hover:bg-slate-800/50'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-bold text-sm text-white">{h.city}, {h.state}</span>
                    <span className="text-[11px] font-mono text-emerald-400 font-semibold">${h.price.toLocaleString('en-US')}</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mb-2 truncate">{h.address}</p>
                  <div className="text-[10px] text-slate-400 space-y-0.5 font-mono">
                    <div>Ingreso: ${Math.round(h.avgAreaIncome).toLocaleString('en-US')}</div>
                    <div>Habitaciones: {h.avgRooms} habs</div>
                    <div>Antigüedad: {h.avgHouseAge} años</div>
                  </div>
                </div>
              );
            })}
          </div>

          {c1Feedback && (
            <div
              className={`p-4 rounded-xl border text-xs flex items-start gap-3 animate-fadeIn ${
                c1Feedback.isCorrect
                  ? 'bg-emerald-950/50 border-emerald-700/60 text-emerald-200'
                  : 'bg-rose-950/50 border-rose-700/60 text-rose-200'
              }`}
            >
              {c1Feedback.isCorrect ? (
                <Check className="w-5 h-5 text-emerald-400 shrink-0" />
              ) : (
                <X className="w-5 h-5 text-rose-400 shrink-0" />
              )}
              <div className="space-y-1">
                <span className="font-bold text-sm block">
                  {c1Feedback.isCorrect ? '¡Excelente deducción!' : 'Sigue intentándolo'}
                </span>
                <p className="leading-relaxed">{c1Feedback.text}</p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 3. DESAFÍO 2: DOMINAR EL PARÁMETRO C */}
      {activeChallenge === 2 && (
        <div className="space-y-5 flex-1 overflow-y-auto pr-1">
          <div className="bg-indigo-950/20 border border-indigo-800/40 p-4 rounded-xl space-y-1">
            <div className="flex items-center gap-2 text-indigo-400 font-bold text-xs">
              <Zap className="w-4 h-4" />
              <span>Misión: Encuentra el valor de C óptimo (Margen Blando)</span>
            </div>
            <p className="text-xs text-slate-300">
              Mueve el regulador de C. Si C es diminuto (0.01), el modelo ignora casi todas las infracciones y crea un margen gigante pero con baja precisión. Si C es extremo (100), el modelo se obsesiona con no fallar y contrae el margen. ¡Encuentra el punto dulce con Exactitud &gt; 85%!
            </p>
          </div>

          <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-300">Parámetro C (Regularización):</span>
              <span className="text-sm font-mono font-bold text-amber-400">{hyperparams.C}</span>
            </div>

            <input
              type="range"
              min="0.01"
              max="50"
              step="0.1"
              value={hyperparams.C}
              onChange={(e) => handleTestC(parseFloat(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />

            <div className="grid grid-cols-3 gap-3 pt-2 text-center text-xs font-mono">
              <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                <div className="text-slate-500 text-[10px]">Exactitud Actual</div>
                <div className="text-base font-bold text-emerald-400">{(model.accuracy * 100).toFixed(1)}%</div>
              </div>
              <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                <div className="text-slate-500 text-[10px]">Ancho de Margen</div>
                <div className="text-base font-bold text-indigo-400">{model.marginWidth.toFixed(2)}</div>
              </div>
              <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                <div className="text-slate-500 text-[10px]">Vectores Soporte</div>
                <div className="text-base font-bold text-amber-400">{model.supportVectors.length}</div>
              </div>
            </div>

            {cTargetMet ? (
              <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/60 text-xs text-emerald-200 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-emerald-400 shrink-0" />
                <span>
                  <strong>¡Objetivo Alcanzado!</strong> Has logrado un equilibrio magistral: margen amplio ({model.marginWidth.toFixed(2)}) y alta precisión ({(model.accuracy * 100).toFixed(1)}%).
                </span>
              </div>
            ) : (
              <div className="text-[11px] text-slate-400 text-center italic">
                Ajusta C entre 0.2 y 4.0 para alcanzar el balance óptimo
              </div>
            )}
          </div>
        </div>
      )}

      {/* 4. DESAFÍO 3: TASACIÓN MISTERIOSA */}
      {activeChallenge === 3 && (
        <div className="space-y-5 flex-1 overflow-y-auto pr-1">
          <div className="bg-purple-950/20 border border-purple-800/40 p-4 rounded-xl space-y-1">
            <div className="flex items-center gap-2 text-purple-400 font-bold text-xs">
              <Sparkles className="w-4 h-4" />
              <span>Misión: Clasifica la Vivienda No Vista</span>
            </div>
            <p className="text-xs text-slate-300">
              Un comprador llega con esta propiedad en Denver, CO. ¿El hiperplano del SVM actual la clasificará como Alta Gama o Asequible?
            </p>
          </div>

          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="font-bold text-white text-sm">{mysteryHouse.address} ({mysteryHouse.city}, {mysteryHouse.state})</span>
              <span className="text-xs font-mono text-purple-400">Caso de Prueba</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs font-mono">
              <div className="bg-slate-900 p-2 rounded">
                <span className="text-slate-500 text-[10px]">Ingreso Zona:</span>
                <div className="text-slate-200 font-semibold">${mysteryHouse.avgAreaIncome.toLocaleString('en-US')}</div>
              </div>
              <div className="bg-slate-900 p-2 rounded">
                <span className="text-slate-500 text-[10px]">Habitaciones:</span>
                <div className="text-slate-200 font-semibold">{mysteryHouse.avgRooms} habs</div>
              </div>
              <div className="bg-slate-900 p-2 rounded">
                <span className="text-slate-500 text-[10px]">Antigüedad:</span>
                <div className="text-slate-200 font-semibold">{mysteryHouse.avgHouseAge} años</div>
              </div>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                onClick={() => handlePredictC3(1)}
                className={`flex-1 py-2.5 rounded-xl font-bold text-xs border transition cursor-pointer ${
                  c3Prediction === 1 ? 'bg-amber-500 text-slate-950 border-amber-400' : 'bg-slate-900 text-amber-400 border-amber-500/40 hover:bg-amber-500/10'
                }`}
              >
                Clasificar como Alta Gama (+1)
              </button>
              <button
                onClick={() => handlePredictC3(-1)}
                className={`flex-1 py-2.5 rounded-xl font-bold text-xs border transition cursor-pointer ${
                  c3Prediction === -1 ? 'bg-cyan-500 text-slate-950 border-cyan-400' : 'bg-slate-900 text-cyan-400 border-cyan-500/40 hover:bg-cyan-500/10'
                }`}
              >
                Clasificar como Accesible (-1)
              </button>
            </div>

            {c3Result !== null && (
              <div
                className={`p-3.5 rounded-xl border text-xs flex items-center gap-3 animate-fadeIn ${
                  c3Result
                    ? 'bg-emerald-950/50 border-emerald-500/60 text-emerald-200'
                    : 'bg-rose-950/50 border-rose-500/60 text-rose-200'
                }`}
              >
                {c3Result ? (
                  <Check className="w-5 h-5 text-emerald-400 shrink-0" />
                ) : (
                  <X className="w-5 h-5 text-rose-400 shrink-0" />
                )}
                <div>
                  <strong className="block text-sm">
                    {c3Result ? '¡Acertaste!' : 'Incorrecto según el modelo'}
                  </strong>
                  <span>
                    El SVM calculó f(x) = {model.predictRaw(mysteryHouse).score.toFixed(3)}, situando la casa del lado {model.predictRaw(mysteryHouse).label === 1 ? 'positivo (Alta Gama)' : 'negativo (Accesible)'}.
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
