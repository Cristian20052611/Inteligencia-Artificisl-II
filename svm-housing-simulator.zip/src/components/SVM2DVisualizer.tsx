/**
 * VISUALIZADOR 2D INTERACTIVO DE MÁQUINAS DE SOPORTE VECTORIAL (SVM)
 * Renderiza en un Canvas HTML5 de alto rendimiento la proyección de dos características
 * del dataset inmobiliario, dibujando el hiperplano óptimo w·x + b = 0, los márgenes ±1,
 * el corredor de separación sombreado, los vectores de soporte con halos luminosos,
 * las líneas de holgura ξ_i, el vector normal w y las regiones de decisión.
 */

import React, { useRef, useEffect, useState, useMemo } from 'react';
import { HousingRecord, FeatureKey, SVMHyperparameters, SVMModelResult, SVMComponentHighlight } from '../types/housing';
import { NormalizedDataset } from '../ml/svmSolver';
import { FEATURE_METAS } from '../data/housingDataset';
import { PlusCircle, Info } from 'lucide-react';

/**
 * Propiedades recibidas por el componente visualizador 2D
 */
interface SVM2DVisualizerProps {
  // Datos normalizados y lista de viviendas
  dataset: NormalizedDataset;
  // Resultado del modelo SVM entrenado (pesos w, bias b, vectores de soporte, etc.)
  model: SVMModelResult;
  // Tupla con las dos características seleccionadas para los ejes [Eje X, Eje Y]
  features: [FeatureKey, FeatureKey];
  // Hiperparámetros actuales (C, Kernel, gamma, grado, umbral de precio)
  hyperparams: SVMHyperparameters;
  // Interruptores para encender o apagar componentes visuales específicos
  highlights: SVMComponentHighlight;
  // Callback ejecutado al hacer clic en el lienzo para añadir una vivienda personalizada
  onAddCustomHouse: (house: Partial<HousingRecord>) => void;
  // Callback ejecutado cuando el usuario hace clic sobre una vivienda existente para inspeccionarla
  onSelectHouse?: (house: HousingRecord) => void;
  // Identificador de la vivienda actualmente seleccionada para destacarla con un borde blanco
  selectedHouseId?: string | null;
}

export const SVM2DVisualizer: React.FC<SVM2DVisualizerProps> = ({
  dataset,
  model,
  features,
  hyperparams,
  highlights,
  onAddCustomHouse,
  onSelectHouse,
  selectedHouseId,
}) => {
  // Referencia al elemento <canvas> del DOM
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  // Referencia al contenedor envolvente para calcular dimensiones responsivas
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Estado que almacena la vivienda sobre la cual el usuario tiene el cursor posicionado
  const [hoveredPoint, setHoveredPoint] = useState<{
    index: number;
    house: HousingRecord;
    screenX: number;
    screenY: number;
    score: number;
    slack: number;
    isSV: boolean;
  } | null>(null);

  // Estado que almacena las coordenadas del cursor dentro del plano cartesiano en valores reales
  const [mouseCoord, setMouseCoord] = useState<{ xVal: number; yVal: number; screenX: number; screenY: number } | null>(null);

  // Metadatos de las características elegidas para los ejes X e Y
  const featureX = FEATURE_METAS[features[0]];
  const featureY = FEATURE_METAS[features[1]];

  // Valores extremos reales para des-normalizar y proyectar
  const { mins, maxs } = dataset;
  const minX = mins[0];
  const maxX = maxs[0];
  const minY = mins[1];
  const maxY = maxs[1];

  // Margen interno (padding) en píxeles para dejar espacio a los ejes y etiquetas
  const padding = 55;

  // Conjunto de índices de los Vectores de Soporte para búsqueda instantánea O(1)
  const svIndices = useMemo(() => {
    return new Set(model.supportVectors.map((sv) => sv.index));
  }, [model.supportVectors]);

  // Efecto principal de dibujo en Canvas cada vez que cambian los datos o hiperparámetros
  useEffect(() => {
    // Obtenemos el elemento Canvas del DOM
    const canvas = canvasRef.current;
    if (!canvas) return;
    // Obtenemos el contexto de renderizado 2D
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Soporte para pantallas de alta densidad (Retina / High-DPI)
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;

    // Ajustamos la resolución interna del canvas al pixel ratio del dispositivo
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    ctx.scale(dpr, dpr);

    // Ancho y alto efectivos del área de trazado cartesiano
    const plotW = width - padding * 2;
    const plotH = height - padding * 2;

    /**
     * Convierte coordenadas normalizadas [-1, 1] a píxeles de pantalla (X, Y)
     * Toma en cuenta que el eje Y en canvas está invertido (0 está arriba).
     */
    const normToScreen = (normX: number, normY: number) => {
      // normX en [-1, 1] se escala proporcionalmente al ancho
      const px = padding + ((normX + 1) / 2) * plotW;
      // normY en [-1, 1] se invierte para que +1 esté arriba y -1 abajo
      const py = height - padding - ((normY + 1) / 2) * plotH;
      return [px, py];
    };

    // Limpiamos el lienzo antes de dibujar el nuevo fotograma
    ctx.clearRect(0, 0, width, height);

    // Fondo degradado elegante de estilo pizarra oscura
    const bgGradient = ctx.createLinearGradient(0, 0, width, height);
    bgGradient.addColorStop(0, '#090d16');
    bgGradient.addColorStop(1, '#0f172a');
    ctx.fillStyle = bgGradient;
    ctx.fillRect(0, 0, width, height);

    // 1. DIBUJO DE LA REJILLA Y EJES CARTESIANOS
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;
    const gridDivs = 6; // 6 divisiones equidistantes

    for (let i = 0; i <= gridDivs; i++) {
      const t = i / gridDivs;
      const x = padding + t * plotW;
      const y = padding + t * plotH;

      // Línea de cuadrícula vertical
      ctx.beginPath();
      ctx.moveTo(x, padding);
      ctx.lineTo(x, height - padding);
      ctx.stroke();

      // Línea de cuadrícula horizontal
      ctx.beginPath();
      ctx.moveTo(padding, y);
      ctx.lineTo(width - padding, y);
      ctx.stroke();

      // Marcas numéricas y etiquetas formateadas del Eje X
      ctx.fillStyle = '#64748b';
      ctx.font = '10px "JetBrains Mono", monospace';
      ctx.textAlign = 'center';
      const xVal = minX + t * (maxX - minX);
      ctx.fillText(featureX.format(xVal), x, height - padding + 18);

      // Marcas numéricas y etiquetas formateadas del Eje Y
      ctx.textAlign = 'right';
      const yVal = maxY - t * (maxY - minY);
      ctx.fillText(featureY.format(yVal), padding - 10, y + 4);
    }

    // 2. REGIONES DE DECISIÓN (MAPA DE CALOR DE PROBABILIDAD / SCORE)
    if (highlights.decisionRegions) {
      const step = 6; // Tamaño del bloque en píxeles para renderizado fluido
      for (let px = padding; px < width - padding; px += step) {
        for (let py = padding; py < height - padding; py += step) {
          // Convertimos píxel a coordenada matemática normalizada [-1, 1]
          const nx = ((px - padding) / plotW) * 2 - 1;
          const ny = (1 - (py - padding) / plotH) * 2 - 1;
          // Evaluamos la función de decisión del SVM f(x) = w·x + b
          const { score } = model.predict([nx, ny]);

          if (score >= 0) {
            // Región clasificada como Alta Gama (resplandor ámbar/dorado)
            const alpha = Math.min(0.22, Math.max(0.04, Math.abs(score) * 0.08));
            ctx.fillStyle = `rgba(245, 158, 11, ${alpha})`;
          } else {
            // Región clasificada como Accesible (resplandor cian/turquesa)
            const alpha = Math.min(0.22, Math.max(0.04, Math.abs(score) * 0.08));
            ctx.fillStyle = `rgba(6, 182, 212, ${alpha})`;
          }
          ctx.fillRect(px, py, step, step);
        }
      }
    }

    // 3. TRAZADO DEL HIPERPLANO Y LOS MÁRGENES
    if (hyperparams.kernel === 'linear') {
      // En el caso lineal tenemos los dos pesos explícitos: w1 y w2
      const [w1, w2] = model.weights;
      const b = model.bias;

      /**
       * Traza la línea de contorno para un nivel dado: w1*nx + w2*ny + b = level
       * Despejando: ny = (level - b - w1*nx) / w2
       */
      const drawLinearContour = (level: number, color: string, isDashed: boolean, lineWidth: number) => {
        // Caso particular: línea completamente vertical (w2 ≈ 0)
        if (Math.abs(w2) < 1e-5) {
          const nx = (level - b) / (w1 || 1e-5);
          const [px] = normToScreen(nx, 0);
          ctx.beginPath();
          ctx.setLineDash(isDashed ? [6, 6] : []);
          ctx.strokeStyle = color;
          ctx.lineWidth = lineWidth;
          ctx.moveTo(px, padding);
          ctx.lineTo(px, height - padding);
          ctx.stroke();
          ctx.setLineDash([]);
          return;
        }

        // Trazamos uniendo los puntos extremos de la recta extendida fuera del marco
        const nxPoints = [-1.2, 1.2];
        const screenCoords: [number, number][] = [];
        for (const nx of nxPoints) {
          const ny = (level - b - w1 * nx) / w2;
          screenCoords.push(normToScreen(nx, ny) as [number, number]);
        }

        ctx.beginPath();
        ctx.setLineDash(isDashed ? [6, 6] : []);
        ctx.strokeStyle = color;
        ctx.lineWidth = lineWidth;
        ctx.moveTo(screenCoords[0][0], screenCoords[0][1]);
        ctx.lineTo(screenCoords[1][0], screenCoords[1][1]);
        ctx.stroke();
        ctx.setLineDash([]);
      };

      // Corredor de margen sombreado (franja de seguridad entre -1 y +1)
      if (highlights.margins && Math.abs(w2) >= 1e-5) {
        const nyP1 = (1 - b - w1 * -1.2) / w2;
        const nyP2 = (1 - b - w1 * 1.2) / w2;
        const nyM1 = (-1 - b - w1 * -1.2) / w2;
        const nyM2 = (-1 - b - w1 * 1.2) / w2;

        const pP1 = normToScreen(-1.2, nyP1);
        const pP2 = normToScreen(1.2, nyP2);
        const pM2 = normToScreen(1.2, nyM2);
        const pM1 = normToScreen(-1.2, nyM1);

        ctx.beginPath();
        ctx.moveTo(pP1[0], pP1[1]);
        ctx.lineTo(pP2[0], pP2[1]);
        ctx.lineTo(pM2[0], pM2[1]);
        ctx.lineTo(pM1[0], pM1[1]);
        ctx.closePath();
        ctx.fillStyle = 'rgba(99, 102, 241, 0.12)';
        ctx.fill();
      }

      // Dibujamos las líneas de margen positivo (+1) y negativo (-1)
      if (highlights.margins) {
        drawLinearContour(1, '#f59e0b', true, 2);  // Margen superior positivo (+1)
        drawLinearContour(-1, '#06b6d4', true, 2); // Margen inferior negativo (-1)
      }

      // Dibujamos la frontera de decisión principal (Hiperplano w·x + b = 0)
      if (highlights.hyperplane) {
        drawLinearContour(0, '#ffffff', false, 3.5);
      }
    } else {
      // CASO NO LINEAL (RBF GAUSSIANO O POLINÓMICO)
      // Muestreamos una cuadrícula densa para encontrar isolíneas de contorno
      const sampleN = 65;
      const gridScores: number[][] = [];
      for (let i = 0; i <= sampleN; i++) {
        gridScores[i] = [];
        const nx = -1 + (2 * i) / sampleN;
        for (let j = 0; j <= sampleN; j++) {
          const ny = -1 + (2 * j) / sampleN;
          gridScores[i][j] = model.predict([nx, ny]).score;
        }
      }

      /**
       * Dibuja isolíneas curvas no lineales cuando la superficie cruza el nivel deseado
       */
      const drawNonLinearIsoline = (threshold: number, color: string, dashed: boolean, lWidth: number) => {
        ctx.strokeStyle = color;
        ctx.lineWidth = lWidth;
        ctx.setLineDash(dashed ? [5, 5] : []);

        for (let i = 0; i < sampleN; i++) {
          for (let j = 0; j < sampleN; j++) {
            const v00 = gridScores[i][j] - threshold;
            const v10 = gridScores[i + 1][j] - threshold;
            const v01 = gridScores[i][j + 1] - threshold;
            const v11 = gridScores[i + 1][j + 1] - threshold;

            // Verificamos si la frontera cruza esta celda
            const minV = Math.min(v00, v10, v01, v11);
            const maxV = Math.max(v00, v10, v01, v11);
            if (minV <= 0 && maxV >= 0) {
              const nx = -1 + (2 * (i + 0.5)) / sampleN;
              const ny = -1 + (2 * (j + 0.5)) / sampleN;
              const [px, py] = normToScreen(nx, ny);
              ctx.beginPath();
              ctx.arc(px, py, lWidth, 0, Math.PI * 2);
              ctx.fillStyle = color;
              ctx.fill();
            }
          }
        }
        ctx.setLineDash([]);
      };

      if (highlights.margins) {
        drawNonLinearIsoline(1, '#f59e0b', true, 2);
        drawNonLinearIsoline(-1, '#06b6d4', true, 2);
      }
      if (highlights.hyperplane) {
        drawNonLinearIsoline(0, '#ffffff', false, 3.5);
      }
    }

    // 4. LÍNEAS DE HOLGURA (ξ_i) PARA PUNTOS QUE VIOLAN EL MARGEN
    if (highlights.slackLines) {
      dataset.raw.forEach((house, idx) => {
        const normCoord = dataset.features[idx];
        const target = dataset.targets[idx];
        const { score } = model.predict(normCoord);
        const functionalMargin = target * score;
        if (functionalMargin < 1) {
          // El punto está dentro del margen o clasificado erróneamente
          const [px, py] = normToScreen(normCoord[0], normCoord[1]);
          // Dibujamos un círculo punteado rojo de advertencia
          ctx.beginPath();
          ctx.strokeStyle = 'rgba(239, 68, 68, 0.7)';
          ctx.lineWidth = 1.5;
          ctx.setLineDash([3, 3]);
          ctx.arc(px, py, 14, 0, Math.PI * 2);
          ctx.stroke();
          ctx.setLineDash([]);
        }
      });
    }

    // 5. DIBUJO DE LAS VIVIENDAS COMO PUNTOS DISPERSOS
    dataset.raw.forEach((house, idx) => {
      const normCoord = dataset.features[idx];
      const target = dataset.targets[idx];
      const [px, py] = normToScreen(normCoord[0], normCoord[1]);
      const isSV = svIndices.has(idx);
      const isSelected = selectedHouseId === house.id;

      // Halo concéntrico para los VECTORES DE SOPORTE (puntos que determinan el margen)
      if (highlights.supportVectors && isSV) {
        ctx.save();
        ctx.beginPath();
        ctx.arc(px, py, 13, 0, Math.PI * 2);
        ctx.strokeStyle = target === 1 ? 'rgba(245, 158, 11, 0.95)' : 'rgba(6, 182, 212, 0.95)';
        ctx.lineWidth = 2.5;
        ctx.setLineDash([3, 2]);
        ctx.stroke();

        // Anillo de resplandor exterior suave
        ctx.beginPath();
        ctx.arc(px, py, 19, 0, Math.PI * 2);
        ctx.strokeStyle = target === 1 ? 'rgba(245, 158, 11, 0.35)' : 'rgba(6, 182, 212, 0.35)';
        ctx.lineWidth = 1.5;
        ctx.stroke();
        ctx.restore();
      }

      // Indicador de casa seleccionada con clic
      if (isSelected) {
        ctx.beginPath();
        ctx.arc(px, py, 17, 0, Math.PI * 2);
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 3;
        ctx.stroke();
      }

      // Círculo principal del punto de datos
      ctx.beginPath();
      ctx.arc(px, py, isSV ? 7.5 : 5.5, 0, Math.PI * 2);
      if (target === 1) {
        // Clase Alta Gama / Lujo: color dorado cálido
        ctx.fillStyle = '#f59e0b';
        ctx.shadowColor = 'rgba(245, 158, 11, 0.6)';
        ctx.shadowBlur = 8;
      } else {
        // Clase Accesible / Estándar: color cian frío
        ctx.fillStyle = '#06b6d4';
        ctx.shadowColor = 'rgba(6, 182, 212, 0.6)';
        ctx.shadowBlur = 8;
      }
      ctx.fill();
      ctx.shadowBlur = 0;

      // Punto central contrastante
      ctx.beginPath();
      ctx.arc(px, py, 2.5, 0, Math.PI * 2);
      ctx.fillStyle = '#0f172a';
      ctx.fill();
    });

    // 6. VECTOR NORMAL w (FLECHA PERPENDICULAR AL HIPERPLANO)
    if (highlights.normalVector && hyperparams.kernel === 'linear') {
      const [w1, w2] = model.weights;
      const b = model.bias;
      const wNorm = Math.sqrt(w1 * w1 + w2 * w2);
      if (wNorm > 0.05) {
        // Punto de origen centrado sobre el hiperplano
        const centerNx = 0;
        const centerNy = Math.abs(w2) > 1e-4 ? (-b - w1 * centerNx) / w2 : 0;
        const [originPx, originPy] = normToScreen(centerNx, Math.max(-0.8, Math.min(0.8, centerNy)));

        // Longitud en píxeles de la flecha indicadora
        const arrowLen = 50;
        const dirX = (w1 / wNorm) * arrowLen;
        const dirY = -(w2 / wNorm) * arrowLen; // La coordenada Y de pantalla está invertida

        ctx.beginPath();
        ctx.strokeStyle = '#ec4899';
        ctx.lineWidth = 3;
        ctx.moveTo(originPx, originPy);
        ctx.lineTo(originPx + dirX, originPy + dirY);
        ctx.stroke();

        // Cabeza de la flecha normal
        const angle = Math.atan2(dirY, dirX);
        ctx.beginPath();
        ctx.fillStyle = '#ec4899';
        ctx.moveTo(originPx + dirX, originPy + dirY);
        ctx.lineTo(
          originPx + dirX - 12 * Math.cos(angle - Math.PI / 6),
          originPy + dirY - 12 * Math.sin(angle - Math.PI / 6)
        );
        ctx.lineTo(
          originPx + dirX - 12 * Math.cos(angle + Math.PI / 6),
          originPy + dirY - 12 * Math.sin(angle + Math.PI / 6)
        );
        ctx.closePath();
        ctx.fill();

        // Etiqueta de texto explicativa
        ctx.fillStyle = '#ec4899';
        ctx.font = 'bold 12px "JetBrains Mono", monospace';
        ctx.fillText('Vector w (normal)', originPx + dirX + 8, originPy + dirY);
      }
    }

    // Marco exterior con borde definido
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(padding, padding, plotW, plotH);

  }, [dataset, model, features, hyperparams, highlights, selectedHouseId, svIndices]);

  // GESTIÓN DE EVENTOS DE MOUSE: Detección de proximidad y hover sobre casas
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;

    const plotW = rect.width - padding * 2;
    const plotH = rect.height - padding * 2;

    // Verificamos si el cursor se encuentra dentro del área de datos
    if (mx >= padding && mx <= rect.width - padding && my >= padding && my <= rect.height - padding) {
      const nx = ((mx - padding) / plotW) * 2 - 1;
      const ny = (1 - (my - padding) / plotH) * 2 - 1;

      // Des-normalizamos a valores reales para mostrarlos en el cursor
      const rawX = minX + ((nx + 1) / 2) * (maxX - minX);
      const rawY = minY + ((ny + 1) / 2) * (maxY - minY);

      setMouseCoord({ xVal: rawX, yVal: rawY, screenX: e.clientX, screenY: e.clientY });
    } else {
      setMouseCoord(null);
    }

    // Verificamos si el mouse coincide con alguna vivienda existente (radio de 14 píxeles)
    let hit: typeof hoveredPoint = null;
    let minDistance = 14;

    dataset.raw.forEach((house, idx) => {
      const normCoord = dataset.features[idx];
      const px = padding + ((normCoord[0] + 1) / 2) * plotW;
      const py = rect.height - padding - ((normCoord[1] + 1) / 2) * plotH;
      const dist = Math.hypot(mx - px, my - py);

      if (dist < minDistance) {
        minDistance = dist;
        const { score } = model.predict(normCoord);
        const target = dataset.targets[idx];
        const slack = Math.max(0, 1 - target * score);
        hit = {
          index: idx,
          house,
          screenX: e.clientX,
          screenY: e.clientY,
          score,
          slack,
          isSV: svIndices.has(idx),
        };
      }
    });

    setHoveredPoint(hit);
  };

  // Limpia el estado de hover cuando el cursor sale del canvas
  const handleMouseLeave = () => {
    setHoveredPoint(null);
    setMouseCoord(null);
  };

  // GESTIÓN DE CLIC: Selecciona una casa o crea una nueva vivienda en esa posición
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    // Si se hizo clic sobre una casa existente, la seleccionamos para abrir su ficha
    if (hoveredPoint && onSelectHouse) {
      onSelectHouse(hoveredPoint.house);
      return;
    }

    // Si se hizo clic en un espacio vacío, creamos una vivienda interactiva con esas coordenadas exactas
    if (mouseCoord) {
      const defaultRooms = 6.5;
      const defaultAge = 10;
      const defaultIncome = 70000;
      const defaultSqFt = 2200;
      const defaultPop = 32000;

      const newHouseData: Partial<HousingRecord> = {
        city: 'Vivienda Simulada',
        state: 'US',
        address: 'Punto Interactivo en Gráfica',
        avgAreaIncome: features[0] === 'avgAreaIncome' ? mouseCoord.xVal : (features[1] === 'avgAreaIncome' ? mouseCoord.yVal : defaultIncome),
        avgHouseAge: features[0] === 'avgHouseAge' ? mouseCoord.xVal : (features[1] === 'avgHouseAge' ? mouseCoord.yVal : defaultAge),
        avgRooms: features[0] === 'avgRooms' ? mouseCoord.xVal : (features[1] === 'avgRooms' ? mouseCoord.yVal : defaultRooms),
        avgBedrooms: 3.2,
        areaPopulation: features[0] === 'areaPopulation' ? mouseCoord.xVal : (features[1] === 'areaPopulation' ? mouseCoord.yVal : defaultPop),
        squareFeet: features[0] === 'squareFeet' ? mouseCoord.xVal : (features[1] === 'squareFeet' ? mouseCoord.yVal : defaultSqFt),
        price: hyperparams.priceThreshold,
        isCustom: true,
      };

      onAddCustomHouse(newHouseData);
    }
  };

  return (
    <div className="relative w-full h-full flex flex-col bg-slate-900/90 rounded-2xl border border-slate-800 overflow-hidden shadow-2xl">
      {/* Barra superior con leyenda interactiva */}
      <div className="flex flex-wrap items-center justify-between px-5 py-3 border-b border-slate-800/80 bg-slate-950/60 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <span className="text-xs font-semibold uppercase tracking-wider text-indigo-400 font-mono">
            Plano 2D:
          </span>
          <div className="flex items-center gap-1.5 text-sm font-medium text-slate-200">
            <span className="text-amber-400 font-bold">Eje X:</span>
            <span>{featureX.label}</span>
            <span className="text-slate-500">×</span>
            <span className="text-cyan-400 font-bold">Eje Y:</span>
            <span>{featureY.label}</span>
          </div>
        </div>

        {/* Leyenda de clases y vectores de soporte */}
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-amber-500 shadow-sm shadow-amber-500/50 inline-block" />
            <span className="text-slate-300 font-medium">Alta Gama (≥ ${Math.round(hyperparams.priceThreshold / 1000)}k)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-cyan-500 shadow-sm shadow-cyan-500/50 inline-block" />
            <span className="text-slate-300 font-medium">Accesible (&lt; ${Math.round(hyperparams.priceThreshold / 1000)}k)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3.5 h-3.5 rounded-full border-2 border-dashed border-amber-400 inline-block" />
            <span className="text-slate-300 font-medium">Vector de Soporte (SV)</span>
          </div>
        </div>
      </div>

      {/* Contenedor principal del Canvas */}
      <div ref={containerRef} className="relative flex-1 w-full min-h-[420px] bg-slate-950 cursor-crosshair">
        <canvas
          ref={canvasRef}
          className="w-full h-full block"
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
          onClick={handleCanvasClick}
        />

        {/* Rótulo estético del Eje X */}
        <div className="absolute bottom-2 left-1/2 -translate-x-1/2 text-xs font-semibold text-slate-400 bg-slate-900/80 px-3 py-1 rounded-full border border-slate-700/60 pointer-events-none">
          Eje X: {featureX.label} ({featureX.unit})
        </div>

        {/* Rótulo estético del Eje Y */}
        <div className="absolute top-1/2 left-3 -translate-y-1/2 -rotate-90 origin-left text-xs font-semibold text-slate-400 bg-slate-900/80 px-3 py-1 rounded-full border border-slate-700/60 pointer-events-none">
          Eje Y: {featureY.label} ({featureY.unit})
        </div>

        {/* Consejo didáctico flotante */}
        <div className="absolute top-4 left-5 pointer-events-none">
          <div className="flex items-center gap-2 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-800 text-xs text-slate-400 shadow-lg">
            <Info className="w-3.5 h-3.5 text-indigo-400" />
            <span>Haz clic en cualquier punto del plano para añadir una vivienda y ver cómo responde el hiperplano</span>
          </div>
        </div>

        {/* Tooltip flotante con detalles matemáticos al pasar el cursor */}
        {hoveredPoint && (
          <div
            className="fixed z-50 pointer-events-none transform -translate-x-1/2 -translate-y-full mb-3"
            style={{ left: hoveredPoint.screenX, top: hoveredPoint.screenY - 12 }}
          >
            <div className="bg-slate-900/95 backdrop-blur-md border border-slate-700 text-slate-200 p-3.5 rounded-xl shadow-2xl text-xs max-w-xs space-y-1.5">
              <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-1.5">
                <span className="font-bold text-sm text-white">{hoveredPoint.house.city}, {hoveredPoint.house.state}</span>
                {hoveredPoint.isSV && (
                  <span className="bg-amber-500/20 text-amber-300 font-bold px-2 py-0.5 rounded text-[10px] border border-amber-500/40">
                    VECTOR DE SOPORTE ⭐
                  </span>
                )}
              </div>
              <p className="text-slate-400 text-[11px] truncate">{hoveredPoint.house.address}</p>
              
              <div className="grid grid-cols-2 gap-x-3 gap-y-1 pt-1 font-mono text-[11px]">
                <div>
                  <span className="text-slate-500">Precio Real:</span>{' '}
                  <span className="text-emerald-400 font-semibold">${hoveredPoint.house.price.toLocaleString('en-US')}</span>
                </div>
                <div>
                  <span className="text-slate-500">Clase:</span>{' '}
                  <span className={hoveredPoint.house.price >= hyperparams.priceThreshold ? 'text-amber-400 font-semibold' : 'text-cyan-400 font-semibold'}>
                    {hoveredPoint.house.price >= hyperparams.priceThreshold ? 'Alta Gama (+1)' : 'Accesible (-1)'}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500">{featureX.shortLabel}:</span>{' '}
                  <span>{featureX.format(hoveredPoint.house[features[0]])}</span>
                </div>
                <div>
                  <span className="text-slate-500">{featureY.shortLabel}:</span>{' '}
                  <span>{featureY.format(hoveredPoint.house[features[1]])}</span>
                </div>
              </div>

              <div className="border-t border-slate-800 pt-1.5 flex items-center justify-between text-[11px] font-mono">
                <span className="text-slate-400">Score f(x) = w·x+b:</span>
                <span className={hoveredPoint.score >= 0 ? 'text-amber-400' : 'text-cyan-400'}>
                  {hoveredPoint.score.toFixed(3)}
                </span>
              </div>

              {hoveredPoint.slack > 0 && (
                <div className="flex items-center justify-between text-[11px] font-mono text-rose-400 bg-rose-950/30 px-2 py-0.5 rounded border border-rose-900/40">
                  <span>Holgura ξ (Violación):</span>
                  <span className="font-bold">{hoveredPoint.slack.toFixed(3)}</span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Coordenadas en tiempo real al mover el mouse en el plano */}
        {mouseCoord && !hoveredPoint && (
          <div
            className="fixed z-40 pointer-events-none transform -translate-x-1/2 -translate-y-full mb-3"
            style={{ left: mouseCoord.screenX, top: mouseCoord.screenY - 8 }}
          >
            <div className="bg-slate-900/90 backdrop-blur-sm border border-indigo-500/40 text-slate-200 px-2.5 py-1 rounded-lg shadow-lg text-[11px] font-mono flex items-center gap-2">
              <PlusCircle className="w-3.5 h-3.5 text-indigo-400" />
              <span>
                {featureX.shortLabel}: {featureX.format(mouseCoord.xVal)} | {featureY.shortLabel}: {featureY.format(mouseCoord.yVal)}
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
