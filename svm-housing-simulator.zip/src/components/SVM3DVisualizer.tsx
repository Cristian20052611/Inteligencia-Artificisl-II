/**
 * VISUALIZADOR 3D INTERACTIVO DE MÁQUINAS DE SOPORTE VECTORIAL (SVM) CON THREE.JS
 * Proyecta tres variables continuas del dataset en un espacio euclidiano tridimensional.
 * Dibuja esferas 3D para cada casa, anillos luminosos para los vectores de soporte,
 * el plano hiperplano separador (w₁·x + w₂·y + w₃·z + b = 0), las losas paralelas de margen (±1),
 * el vector normal w y la simulación pedagógica del "Truco del Kernel" (Kernel Trick Lifting).
 */

import React, { useEffect, useRef, useState, useMemo } from 'react';
import * as THREE from 'three';
import { HousingRecord, FeatureKey, SVMHyperparameters, SVMComponentHighlight } from '../types/housing';
import { FEATURE_METAS } from '../data/housingDataset';
import { prepareDataset, solveSVM } from '../ml/svmSolver';
import { RotateCw, Sparkles, Compass } from 'lucide-react';

/**
 * Propiedades del componente visualizador 3D
 */
interface SVM3DVisualizerProps {
  // Lista de viviendas a representar en 3D
  records: HousingRecord[];
  // Tupla de 3 variables seleccionadas para los ejes [Eje X, Eje Y, Eje Z]
  features3D: [FeatureKey, FeatureKey, FeatureKey];
  // Hiperparámetros configurados para el entrenamiento del clasificador
  hyperparams: SVMHyperparameters;
  // Interruptores para visibilidad de hiperplano, márgenes y vectores soporte
  highlights: SVMComponentHighlight;
  // Callback ejecutado al hacer clic en una casa 3D
  onSelectHouse?: (house: HousingRecord) => void;
  // Identificador de la casa seleccionada
  selectedHouseId?: string | null;
}

export const SVM3DVisualizer: React.FC<SVM3DVisualizerProps> = ({
  records,
  features3D,
  hyperparams,
  highlights,
  onSelectHouse,
  selectedHouseId,
}) => {
  // Referencia al contenedor HTML <div> donde Three.js monta su <canvas> WebGL
  const mountRef = useRef<HTMLDivElement | null>(null);
  // Referencia a la escena Three.js
  const sceneRef = useRef<THREE.Scene | null>(null);
  // Referencia a la cámara de perspectiva 3D
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  // Referencia al motor de renderizado WebGL
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  // Identificador del bucle de animación para cancelarlo limpiamente al desmontar
  const animFrameId = useRef<number | null>(null);

  // Estado que activa el modo demostrativo del "Truco del Kernel" (Lifting parabólico z = x² + y²)
  const [isKernelLiftView, setIsKernelLiftView] = useState(false);

  // Estado para la vivienda sobre la cual el cursor del mouse hace hover en el espacio 3D
  const [hovered3DHouse, setHovered3DHouse] = useState<{
    house: HousingRecord;
    screenX: number;
    screenY: number;
    isSV: boolean;
  } | null>(null);

  // Metadatos descriptivos de las 3 variables proyectadas
  const fx = FEATURE_METAS[features3D[0]];
  const fy = FEATURE_METAS[features3D[1]];
  const fz = FEATURE_METAS[features3D[2]];

  // Preparamos el conjunto de datos con las 3 dimensiones seleccionadas
  const dataset3D = useMemo(() => {
    return prepareDataset(records, features3D, hyperparams.priceThreshold);
  }, [records, features3D, hyperparams.priceThreshold]);

  // Entrenamos el clasificador SVM 3D para obtener el hiperplano plano en 3 dimensiones
  const model3D = useMemo(() => {
    return solveSVM(dataset3D, { ...hyperparams, kernel: 'linear' }, features3D);
  }, [dataset3D, hyperparams, features3D]);

  // Conjunto con los índices de los Vectores de Soporte 3D
  const svIndices = useMemo(() => {
    return new Set(model3D.supportVectors.map((sv) => sv.index));
  }, [model3D.supportVectors]);

  // Estado para el control orbital del ratón (rotación 360° y zoom)
  const isDragging = useRef(false);
  const prevMouse = useRef({ x: 0, y: 0 });
  // Coordenadas esféricas de la cámara: ángulo horizontal (theta), ángulo vertical (phi) y distancia (radius)
  const cameraAngle = useRef({ theta: Math.PI / 4, phi: Math.PI / 3, radius: 45 });

  /**
   * Actualiza la posición cartesiana de la cámara usando trigonometría esférica
   * x = r * sin(phi) * sin(theta)
   * y = r * cos(phi)
   * z = r * sin(phi) * cos(theta)
   */
  const updateCameraPosition = () => {
    if (!cameraRef.current) return;
    const { theta, phi, radius } = cameraAngle.current;
    cameraRef.current.position.x = radius * Math.sin(phi) * Math.sin(theta);
    cameraRef.current.position.y = radius * Math.cos(phi);
    cameraRef.current.position.z = radius * Math.sin(phi) * Math.cos(theta);
    // La cámara siempre enfoca al centro exacto del volumen de datos (0, 0, 0)
    cameraRef.current.lookAt(0, 0, 0);
  };

  // Efecto que inicializa y reconstruye la escena Three.js cuando cambian los datos o el modo
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Dimensiones reales del contenedor
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 550;

    // 1. CREACIÓN DE LA ESCENA 3D
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    // Color de fondo oscuro elegante que combina con la paleta de la aplicación
    scene.background = new THREE.Color(0x090d16);

    // 2. CÁMARA DE PERSPECTIVA (Campo visual de 45 grados)
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    cameraRef.current = camera;
    updateCameraPosition();

    // 3. RENDERIZADOR WEBGL DE ALTA CALIDAD CON ANTIALIASING
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    rendererRef.current = renderer;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // 4. ILUMINACIÓN AMBIENTAL Y DIRECCIONAL
    // Luz ambiental suave
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.75);
    scene.add(ambientLight);

    // Luz direccional blanca frontal para crear sombras y volumen en las esferas
    const dirLight1 = new THREE.DirectionalLight(0xffffff, 0.9);
    dirLight1.position.set(20, 40, 20);
    scene.add(dirLight1);

    // Luz de relleno violeta posterior para dar contraste estético
    const dirLight2 = new THREE.DirectionalLight(0x6366f1, 0.6);
    dirLight2.position.set(-20, -20, -20);
    scene.add(dirLight2);

    // 5. CAJA DELIMITADORA 3D Y CUADRÍCULA DE COORDENADAS
    const boxSize = 20; // Tamaño del cubo que contiene el espacio normalizado [-1, 1]
    const boxGeometry = new THREE.BoxGeometry(boxSize, boxSize, boxSize);
    const boxEdges = new THREE.EdgesGeometry(boxGeometry);
    const boxLine = new THREE.LineSegments(boxEdges, new THREE.LineBasicMaterial({ color: 0x1e293b, transparent: true, opacity: 0.6 }));
    scene.add(boxLine);

    // Rejilla de suelo en el plano inferior
    const gridHelper = new THREE.GridHelper(boxSize, 10, 0x334155, 0x1e293b);
    gridHelper.position.y = -boxSize / 2;
    scene.add(gridHelper);

    // 6. CREACIÓN DE LAS ESFERAS DE DATOS INMOBILIARIOS
    const spheresGroup = new THREE.Group();
    const sphereGeo = new THREE.SphereGeometry(0.55, 24, 24);
    const svSphereGeo = new THREE.SphereGeometry(0.8, 32, 32);

    // Material metálico dorado para viviendas de Alta Gama (+1)
    const luxuryMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      roughness: 0.25,
      metalness: 0.3,
      emissive: 0x78350f,
      emissiveIntensity: 0.2,
    });

    // Material metálico cian para viviendas Accesibles (-1)
    const standardMat = new THREE.MeshStandardMaterial({
      color: 0x06b6d4,
      roughness: 0.25,
      metalness: 0.3,
      emissive: 0x164e63,
      emissiveIntensity: 0.2,
    });

    // Geometría toroidal (anillo) para los Vectores de Soporte
    const svRingGeo = new THREE.TorusGeometry(1.2, 0.08, 16, 32);
    const svRingMat = new THREE.MeshBasicMaterial({ color: 0xfcd34d, wireframe: true });

    // Instanciamos cada vivienda en su coordenada 3D
    dataset3D.raw.forEach((house, idx) => {
      const normCoord = dataset3D.features[idx];
      const target = dataset3D.targets[idx];
      const isSV = svIndices.has(idx);

      // Mapeamos las coordenadas normalizadas [-1, 1] al tamaño del cubo [-boxSize/2, boxSize/2]
      let x = normCoord[0] * (boxSize / 2);
      let y = normCoord[1] * (boxSize / 2);
      let z = normCoord[2] * (boxSize / 2);

      // DEMOSTRACIÓN DEL TRUCO DEL KERNEL:
      // Si el modo lifting está activo, elevamos la coordenada Z en forma de paraboloide:
      // z = (x² + y² - 1)
      // Esto muestra cómo una frontera no lineal circular en 2D se vuelve linealmente separable en 3D
      if (isKernelLiftView) {
        const rSq = (normCoord[0] * normCoord[0] + normCoord[1] * normCoord[1]);
        z = (rSq - 1) * (boxSize / 2);
      }

      // Creamos la malla esférica con el tamaño y color correspondiente
      const sphere = new THREE.Mesh(isSV ? svSphereGeo : sphereGeo, target === 1 ? luxuryMat : standardMat);
      sphere.position.set(x, y, z);
      // Adjuntamos los datos inmobiliarios en userData para el raycaster al hacer hover
      sphere.userData = { house, idx, isSV };
      spheresGroup.add(sphere);

      // Añadimos el anillo orbitante a los Vectores de Soporte
      if (highlights.supportVectors && isSV) {
        const ring = new THREE.Mesh(svRingGeo, svRingMat);
        ring.position.set(x, y, z);
        ring.rotation.x = Math.PI / 2;
        spheresGroup.add(ring);
      }
    });
    scene.add(spheresGroup);

    // 7. PLANO HIPERPLANO DE DECISIÓN 3D Y LOSAS DE MARGEN
    if (highlights.hyperplane && model3D.weights.length >= 3) {
      const [w1, w2, w3] = model3D.weights;
      const b = model3D.bias;
      // Longitud (norma euclidiana) del vector de pesos tridimensional ||w||
      const wLength = Math.sqrt(w1 * w1 + w2 * w2 + w3 * w3);

      if (wLength > 0.01) {
        // Vector unitario normal perpendicular al plano: n = w / ||w||
        const normal = new THREE.Vector3(w1 / wLength, w2 / wLength, w3 / wLength);

        /**
         * Función generadora de mallas de planos SVM orientadas perpendicularmente a w
         */
        const createSvmPlane = (offsetLevel: number, colorHex: number, opacity: number) => {
          // Geometría del plano rectangular que corta el cubo
          const planeGeometry = new THREE.PlaneGeometry(boxSize * 1.4, boxSize * 1.4);
          const planeMaterial = new THREE.MeshStandardMaterial({
            color: colorHex,
            side: THREE.DoubleSide,
            transparent: true,
            opacity: opacity,
            roughness: 0.1,
            metalness: 0.1,
          });

          const planeMesh = new THREE.Mesh(planeGeometry, planeMaterial);
          // Orientamos el plano para que su normal apunte exactamente en la dirección del vector w
          const defaultNormal = new THREE.Vector3(0, 0, 1);
          const quaternion = new THREE.Quaternion().setFromUnitVectors(defaultNormal, normal);
          planeMesh.setRotationFromQuaternion(quaternion);

          // Desplazamiento perpendicular a lo largo de la normal: d = (offsetLevel - b) / ||w||
          const distFromOrigin = ((offsetLevel - b) / wLength) * (boxSize / 2);
          planeMesh.position.copy(normal.clone().multiplyScalar(distFromOrigin));

          return planeMesh;
        };

        // Malla del Hiperplano principal de decisión: w·x + b = 0
        const hyperplaneMesh = createSvmPlane(0, 0xffffff, 0.4);
        scene.add(hyperplaneMesh);

        // Losas de margen positivo (+1) y negativo (-1)
        if (highlights.margins) {
          const posMarginMesh = createSvmPlane(1, 0xf59e0b, 0.22);
          const negMarginMesh = createSvmPlane(-1, 0x06b6d4, 0.22);
          scene.add(posMarginMesh);
          scene.add(negMarginMesh);
        }

        // 8. FLECHA DEL VECTOR NORMAL w QUE SURGE DEL HIPERPLANO
        if (highlights.normalVector) {
          const arrowLength = 7;
          const arrowOrigin = normal.clone().multiplyScalar((-b / wLength) * (boxSize / 2));
          const arrowHelper = new THREE.ArrowHelper(normal, arrowOrigin, arrowLength, 0xec4899, 1.2, 0.8);
          scene.add(arrowHelper);
        }
      }
    }

    // 9. BUCLE DE ANIMACIÓN DE THREE.JS (60 FPS)
    const animate = () => {
      animFrameId.current = requestAnimationFrame(animate);
      renderer.render(scene, camera);
    };
    animate();

    // Gestor de redimensionamiento de ventana para mantener la relación de aspecto 3D
    const handleResize = () => {
      if (!container || !rendererRef.current || !cameraRef.current) return;
      const newW = container.clientWidth;
      const newH = container.clientHeight;
      cameraRef.current.aspect = newW / newH;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(newW, newH);
    };
    window.addEventListener('resize', handleResize);

    // Limpieza de recursos al desmontar el componente
    return () => {
      window.removeEventListener('resize', handleResize);
      if (animFrameId.current) cancelAnimationFrame(animFrameId.current);
      renderer.dispose();
    };
  }, [dataset3D, model3D, highlights, isKernelLiftView, svIndices]);

  // GESTORES DE EVENTOS DE ROTACIÓN ORBITAL 3D CON EL MOUSE
  const handleMouseDown = (e: React.MouseEvent) => {
    isDragging.current = true;
    prevMouse.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    // Si el usuario está arrastrando con el botón presionado, rotamos la cámara
    if (isDragging.current) {
      const deltaX = e.clientX - prevMouse.current.x;
      const deltaY = e.clientY - prevMouse.current.y;
      prevMouse.current = { x: e.clientX, y: e.clientY };

      // Sensibilidad orbital en ambos ejes
      cameraAngle.current.theta -= deltaX * 0.008;
      cameraAngle.current.phi = Math.max(0.1, Math.min(Math.PI - 0.1, cameraAngle.current.phi - deltaY * 0.008));
      updateCameraPosition();
      return;
    }

    // RAYCASTING: Detección óptica del puntero sobre las esferas 3D de viviendas
    if (!mountRef.current || !cameraRef.current || !sceneRef.current) return;
    const rect = mountRef.current.getBoundingClientRect();
    const mouseX = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const mouseY = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(new THREE.Vector2(mouseX, mouseY), cameraRef.current);

    // Buscamos intersecciones de rayo con las esferas en la escena
    const intersects = raycaster.intersectObjects(sceneRef.current.children, true);
    const hitSphere = intersects.find((hit) => hit.object.userData && hit.object.userData.house);

    if (hitSphere) {
      setHovered3DHouse({
        house: hitSphere.object.userData.house,
        screenX: e.clientX,
        screenY: e.clientY,
        isSV: hitSphere.object.userData.isSV,
      });
    } else {
      setHovered3DHouse(null);
    }
  };

  // Finaliza el arrastre del mouse
  const handleMouseUp = () => {
    isDragging.current = false;
  };

  // Zoom con la rueda del ratón (modifica el radio esférico de la cámara)
  const handleWheel = (e: React.WheelEvent) => {
    cameraAngle.current.radius = Math.max(20, Math.min(85, cameraAngle.current.radius + e.deltaY * 0.05));
    updateCameraPosition();
  };

  // Restablece la cámara a su perspectiva angular inicial
  const resetCamera = () => {
    cameraAngle.current = { theta: Math.PI / 4, phi: Math.PI / 3, radius: 45 };
    updateCameraPosition();
  };

  return (
    <div className="relative w-full h-full flex flex-col bg-slate-900/90 rounded-2xl border border-slate-800 overflow-hidden shadow-2xl">
      {/* Barra superior de controles del visor 3D */}
      <div className="flex flex-wrap items-center justify-between px-5 py-3 border-b border-slate-800/80 bg-slate-950/60 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <span className="text-xs font-semibold uppercase tracking-wider text-indigo-400 font-mono">
            Espacio 3D:
          </span>
          <div className="flex items-center gap-2 text-xs md:text-sm font-medium text-slate-200">
            <span className="text-amber-400 font-bold">X:</span> {fx.label}
            <span className="text-slate-500">·</span>
            <span className="text-cyan-400 font-bold">Y:</span> {fy.label}
            <span className="text-slate-500">·</span>
            <span className="text-purple-400 font-bold">Z:</span> {fz.label}
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Botón para alternar la demostración pedagógica del Truco del Kernel */}
          <button
            onClick={() => setIsKernelLiftView(!isKernelLiftView)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 border cursor-pointer ${
              isKernelLiftView
                ? 'bg-purple-600/30 text-purple-300 border-purple-500/60 shadow-lg shadow-purple-900/40'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            {isKernelLiftView ? 'Lifting Activo (Kernel Trick)' : 'Ver Truco del Kernel 3D'}
          </button>

          {/* Botón para centrar la cámara orbital */}
          <button
            onClick={resetCamera}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 border border-slate-700 transition cursor-pointer"
            title="Centrar Cámara"
          >
            <RotateCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Contenedor DOM para el Canvas WebGL 3D */}
      <div
        ref={mountRef}
        className="relative flex-1 w-full min-h-[440px] bg-slate-950 cursor-grab active:cursor-grabbing"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onWheel={handleWheel}
      />

      {/* Guía didáctica flotante de navegación 3D */}
      <div className="absolute bottom-4 left-4 pointer-events-none flex flex-col gap-2">
        <div className="bg-slate-900/85 backdrop-blur-md px-3 py-2 rounded-xl border border-slate-800 text-xs text-slate-300 shadow-xl space-y-1">
          <div className="flex items-center gap-2 font-mono text-[11px] text-slate-400">
            <Compass className="w-3.5 h-3.5 text-indigo-400" />
            <span>Arrastra para rotar 360° · Rueda para zoom</span>
          </div>
          <div className="flex items-center gap-3 text-[11px] font-mono">
            <span className="text-white font-semibold">Plano Hiperplano 3D:</span>
            <span className="text-slate-400">w₁·X + w₂·Y + w₃·Z + b = 0</span>
          </div>
          <div className="flex items-center gap-3 text-[11px] font-mono">
            <span className="text-amber-400">Márgenes ±1:</span>
            <span className="text-slate-400">Grosor de banda = {model3D.marginWidth.toFixed(2)}</span>
          </div>
        </div>
      </div>

      {/* Explicación flotante del Truco del Kernel cuando está activo */}
      {isKernelLiftView && (
        <div className="absolute top-16 right-4 max-w-sm bg-purple-950/90 backdrop-blur-md border border-purple-500/50 p-3.5 rounded-xl shadow-2xl text-xs space-y-1.5 animate-fadeIn">
          <div className="flex items-center gap-2 font-bold text-purple-200">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span>¿Cómo funciona el Truco del Kernel?</span>
          </div>
          <p className="text-purple-300/90 leading-relaxed text-[11px]">
            Los datos que en 2D parecen un círculo imposible de separar con una línea recta son proyectados a la 3ª dimensión (Z = X² + Y²). Al elevarlos parabólicamente, ¡un simple plano plano 3D ahora puede cortarlos limpiamente!
          </p>
        </div>
      )}

      {/* Ficha flotante al posar el cursor sobre una esfera 3D */}
      {hovered3DHouse && (
        <div
          className="fixed z-50 pointer-events-none transform -translate-x-1/2 -translate-y-full mb-3"
          style={{ left: hovered3DHouse.screenX, top: hovered3DHouse.screenY - 12 }}
        >
          <div className="bg-slate-900/95 backdrop-blur-md border border-slate-700 text-slate-200 p-3 rounded-xl shadow-2xl text-xs max-w-xs space-y-1">
            <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-1">
              <span className="font-bold text-white">{hovered3DHouse.house.city}, {hovered3DHouse.house.state}</span>
              {hovered3DHouse.isSV && (
                <span className="bg-amber-500/20 text-amber-300 font-bold px-1.5 py-0.5 rounded text-[10px] border border-amber-500/40">
                  SV ⭐
                </span>
              )}
            </div>
            <p className="text-slate-400 text-[11px] truncate">{hovered3DHouse.house.address}</p>
            <div className="text-[11px] font-mono text-emerald-400 font-bold">
              ${hovered3DHouse.house.price.toLocaleString('en-US')}
            </div>
            <div className="text-[10px] text-slate-400 font-mono">
              {fx.shortLabel}: {fx.format(hovered3DHouse.house[features3D[0]])} · {fy.shortLabel}: {fy.format(hovered3DHouse.house[features3D[1]])}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
