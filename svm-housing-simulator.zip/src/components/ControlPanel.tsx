/**
 * PANEL DE CONTROL DE HIPERPARÁMETROS Y VARIABLES DE SVM
 * Permite alternar entre 2D y 3D, elegir las variables inmobiliarias de los ejes,
 * ajustar la regularización C, la función Kernel (Lineal, RBF, Polinómico), gamma γ,
 * el umbral de precio de corte, y alternar la visibilidad de los componentes geométricos de SVM.
 */

import React from 'react';
import { FeatureKey, SVMHyperparameters, SVMComponentHighlight, KernelType } from '../types/housing';
import { FEATURE_METAS } from '../data/housingDataset';
import { Sliders, Layers, RefreshCw, PlusCircle, CheckSquare, Square } from 'lucide-react';

/**
 * Propiedades recibidas por el Panel de Control
 */
interface ControlPanelProps {
  // Indica si la visualización activa está en modo 3D (true) o 2D (false)
  mode3D: boolean;
  // Callback para alternar entre 2D y 3D
  onToggle3D: (is3D: boolean) => void;
  // Tupla de características elegidas para 2D [Eje X, Eje Y]
  features2D: [FeatureKey, FeatureKey];
  // Callback para cambiar las características 2D
  onChangeFeatures2D: (feats: [FeatureKey, FeatureKey]) => void;
  // Tupla de características elegidas para 3D [Eje X, Eje Y, Eje Z]
  features3D: [FeatureKey, FeatureKey, FeatureKey];
  // Callback para cambiar las características 3D
  onChangeFeatures3D: (feats: [FeatureKey, FeatureKey, FeatureKey]) => void;
  // Objeto con los hiperparámetros SVM actuales
  hyperparams: SVMHyperparameters;
  // Callback para modificar los hiperparámetros
  onChangeHyperparams: (params: SVMHyperparameters) => void;
  // Estados de activación de las capas visuales
  highlights: SVMComponentHighlight;
  // Callback para conmutar una capa visual específica
  onToggleHighlight: (key: keyof SVMComponentHighlight) => void;
  // Callback para añadir un lote de 30 viviendas adicionales
  onAddMoreData: () => void;
  // Callback para restaurar el dataset original de 60 viviendas
  onResetData: () => void;
  // Callback para cargar un preset pedagógico preconfigurado
  onLoadPreset: (presetName: 'clean' | 'noisy' | 'nonlinear') => void;
}

// Lista exhaustiva de todas las variables numéricas disponibles en el dataset
const ALL_FEATURE_KEYS: FeatureKey[] = [
  'avgAreaIncome',
  'avgHouseAge',
  'avgRooms',
  'avgBedrooms',
  'areaPopulation',
  'squareFeet',
];

export const ControlPanel: React.FC<ControlPanelProps> = ({
  mode3D,
  onToggle3D,
  features2D,
  onChangeFeatures2D,
  features3D,
  onChangeFeatures3D,
  hyperparams,
  onChangeHyperparams,
  highlights,
  onToggleHighlight,
  onAddMoreData,
  onResetData,
  onLoadPreset,
}) => {
  return (
    <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 space-y-5 shadow-2xl">
      {/* 1. SELECTOR DE DIMENSIÓN ESPACIAL (PLANO 2D VS ESPACIO 3D) */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div className="flex items-center gap-2 font-bold text-sm text-white">
          <Layers className="w-4 h-4 text-indigo-400" />
          <span>Dimensión Espacial</span>
        </div>
        <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800">
          {/* Botón para activar visualización en plano 2D */}
          <button
            onClick={() => onToggle3D(false)}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              !mode3D
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Plano 2D
          </button>
          {/* Botón para activar visualización en espacio 3D Three.js */}
          <button
            onClick={() => onToggle3D(true)}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              mode3D
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Espacio 3D
          </button>
        </div>
      </div>

      {/* 2. SELECTORES DE VARIABLES DE LOS EJES CARTESIANOS */}
      <div className="space-y-3">
        <div className="text-xs font-semibold text-slate-300 font-mono flex items-center justify-between">
          <span>Selección de Variables del Dataset</span>
          <span className="text-[10px] text-slate-500">EE.UU. Housing</span>
        </div>

        {!mode3D ? (
          // Selectores para modo 2D: Eje X y Eje Y
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="text-[10px] text-amber-400 font-bold block mb-1 font-mono">EJE X</label>
              <select
                value={features2D[0]}
                onChange={(e) => onChangeFeatures2D([e.target.value as FeatureKey, features2D[1]])}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:border-indigo-500 focus:outline-none font-medium"
              >
                {ALL_FEATURE_KEYS.map((key) => (
                  <option key={key} value={key} disabled={key === features2D[1]}>
                    {FEATURE_METAS[key].shortLabel} ({FEATURE_METAS[key].unit})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[10px] text-cyan-400 font-bold block mb-1 font-mono">EJE Y</label>
              <select
                value={features2D[1]}
                onChange={(e) => onChangeFeatures2D([features2D[0], e.target.value as FeatureKey])}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:border-indigo-500 focus:outline-none font-medium"
              >
                {ALL_FEATURE_KEYS.map((key) => (
                  <option key={key} value={key} disabled={key === features2D[0]}>
                    {FEATURE_METAS[key].shortLabel} ({FEATURE_METAS[key].unit})
                  </option>
                ))}
              </select>
            </div>
          </div>
        ) : (
          // Selectores para modo 3D: Eje X, Eje Y y Eje Z
          <div className="grid grid-cols-3 gap-2">
            <div>
              <label className="text-[10px] text-amber-400 font-bold block mb-1 font-mono">EJE X</label>
              <select
                value={features3D[0]}
                onChange={(e) => onChangeFeatures3D([e.target.value as FeatureKey, features3D[1], features3D[2]])}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2 py-1.5 text-xs text-white focus:border-indigo-500 focus:outline-none"
              >
                {ALL_FEATURE_KEYS.map((key) => (
                  <option key={key} value={key} disabled={key === features3D[1] || key === features3D[2]}>
                    {FEATURE_METAS[key].shortLabel}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[10px] text-cyan-400 font-bold block mb-1 font-mono">EJE Y</label>
              <select
                value={features3D[1]}
                onChange={(e) => onChangeFeatures3D([features3D[0], e.target.value as FeatureKey, features3D[2]])}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2 py-1.5 text-xs text-white focus:border-indigo-500 focus:outline-none"
              >
                {ALL_FEATURE_KEYS.map((key) => (
                  <option key={key} value={key} disabled={key === features3D[0] || key === features3D[2]}>
                    {FEATURE_METAS[key].shortLabel}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[10px] text-purple-400 font-bold block mb-1 font-mono">EJE Z</label>
              <select
                value={features3D[2]}
                onChange={(e) => onChangeFeatures3D([features3D[0], features3D[1], e.target.value as FeatureKey])}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2 py-1.5 text-xs text-white focus:border-indigo-500 focus:outline-none"
              >
                {ALL_FEATURE_KEYS.map((key) => (
                  <option key={key} value={key} disabled={key === features3D[0] || key === features3D[1]}>
                    {FEATURE_METAS[key].shortLabel}
                  </option>
                ))}
              </select>
            </div>
          </div>
        )}
      </div>

      {/* 3. CONFIGURACIÓN DE HIPERPARÁMETROS DEL CLASIFICADOR SVM */}
      <div className="space-y-3.5 border-t border-slate-800 pt-4">
        <div className="flex items-center justify-between text-xs font-semibold text-slate-300 font-mono">
          <span className="flex items-center gap-1.5">
            <Sliders className="w-3.5 h-3.5 text-amber-400" />
            <span>Hiperparámetros de SVM</span>
          </span>
        </div>

        {/* Selector de Tipo de Kernel */}
        <div>
          <label className="text-[11px] text-slate-400 block mb-1 font-mono">Tipo de Kernel</label>
          <div className="grid grid-cols-3 gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800">
            {(['linear', 'rbf', 'poly'] as KernelType[]).map((k) => (
              <button
                key={k}
                onClick={() => onChangeHyperparams({ ...hyperparams, kernel: k })}
                className={`py-1 rounded-lg text-xs font-mono font-bold capitalize transition cursor-pointer ${
                  hyperparams.kernel === k
                    ? 'bg-indigo-600 text-white shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {k === 'linear' ? 'Lineal' : k === 'rbf' ? 'RBF (Gauss)' : 'Polinómico'}
              </button>
            ))}
          </div>
        </div>

        {/* Control Deslizante de Regularización C */}
        <div className="space-y-1">
          <div className="flex justify-between text-xs font-mono">
            <span className="text-slate-400">Regularización C:</span>
            <span className="text-amber-400 font-bold">
              {hyperparams.C} ({hyperparams.C < 1 ? 'Margen Blando' : hyperparams.C > 10 ? 'Margen Rígido' : 'Equilibrado'})
            </span>
          </div>
          <input
            type="range"
            min="0.05"
            max="30"
            step="0.1"
            value={hyperparams.C}
            onChange={(e) => onChangeHyperparams({ ...hyperparams, C: parseFloat(e.target.value) })}
            className="w-full accent-amber-500 cursor-pointer"
          />
        </div>

        {/* Control Deslizante de Gamma (γ) si el Kernel RBF está activo */}
        {hyperparams.kernel === 'rbf' && (
          <div className="space-y-1 animate-fadeIn">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-400">Parámetro Gamma (γ):</span>
              <span className="text-purple-400 font-bold">{hyperparams.gamma.toFixed(2)}</span>
            </div>
            <input
              type="range"
              min="0.1"
              max="5"
              step="0.1"
              value={hyperparams.gamma}
              onChange={(e) => onChangeHyperparams({ ...hyperparams, gamma: parseFloat(e.target.value) })}
              className="w-full accent-purple-500 cursor-pointer"
            />
          </div>
        )}

        {/* Umbral de Precio de Corte ($) para definir las dos clases */}
        <div className="space-y-1">
          <div className="flex justify-between text-xs font-mono">
            <span className="text-slate-400">Umbral Precio Alta Gama:</span>
            <span className="text-emerald-400 font-bold">${Math.round(hyperparams.priceThreshold / 1000)}k</span>
          </div>
          <input
            type="range"
            min="300000"
            max="750000"
            step="10000"
            value={hyperparams.priceThreshold}
            onChange={(e) => onChangeHyperparams({ ...hyperparams, priceThreshold: parseInt(e.target.value, 10) })}
            className="w-full accent-emerald-500 cursor-pointer"
          />
        </div>
      </div>

      {/* 4. INTERRUPTORES DE CAPAS VISUALES DE COMPONENTES SVM */}
      <div className="space-y-2.5 border-t border-slate-800 pt-4">
        <div className="text-xs font-semibold text-slate-300 font-mono">
          Capas & Componentes a Mostrar
        </div>
        <div className="grid grid-cols-2 gap-2 text-xs">
          {/* Conmutador de la línea del hiperplano de decisión */}
          <button
            onClick={() => onToggleHighlight('hyperplane')}
            className={`p-2 rounded-lg border text-left flex items-center gap-2 cursor-pointer transition ${
              highlights.hyperplane ? 'bg-indigo-950/40 border-indigo-500/60 text-white' : 'bg-slate-950 border-slate-800 text-slate-400'
            }`}
          >
            {highlights.hyperplane ? <CheckSquare className="w-3.5 h-3.5 text-indigo-400" /> : <Square className="w-3.5 h-3.5" />}
            <span>Hiperplano (w·x+b=0)</span>
          </button>

          {/* Conmutador de las líneas o losas de margen ±1 */}
          <button
            onClick={() => onToggleHighlight('margins')}
            className={`p-2 rounded-lg border text-left flex items-center gap-2 cursor-pointer transition ${
              highlights.margins ? 'bg-indigo-950/40 border-indigo-500/60 text-white' : 'bg-slate-950 border-slate-800 text-slate-400'
            }`}
          >
            {highlights.margins ? <CheckSquare className="w-3.5 h-3.5 text-indigo-400" /> : <Square className="w-3.5 h-3.5" />}
            <span>Márgenes (±1)</span>
          </button>

          {/* Conmutador de los halos en los vectores de soporte */}
          <button
            onClick={() => onToggleHighlight('supportVectors')}
            className={`p-2 rounded-lg border text-left flex items-center gap-2 cursor-pointer transition ${
              highlights.supportVectors ? 'bg-amber-950/40 border-amber-500/60 text-amber-200' : 'bg-slate-950 border-slate-800 text-slate-400'
            }`}
          >
            {highlights.supportVectors ? <CheckSquare className="w-3.5 h-3.5 text-amber-400" /> : <Square className="w-3.5 h-3.5" />}
            <span>Vectores Soporte</span>
          </button>

          {/* Conmutador de la flecha del vector normal w */}
          <button
            onClick={() => onToggleHighlight('normalVector')}
            className={`p-2 rounded-lg border text-left flex items-center gap-2 cursor-pointer transition ${
              highlights.normalVector ? 'bg-pink-950/40 border-pink-500/60 text-pink-200' : 'bg-slate-950 border-slate-800 text-slate-400'
            }`}
          >
            {highlights.normalVector ? <CheckSquare className="w-3.5 h-3.5 text-pink-400" /> : <Square className="w-3.5 h-3.5" />}
            <span>Vector Normal w</span>
          </button>

          {/* Opciones exclusivas de 2D */}
          {!mode3D && (
            <>
              {/* Conmutador del mapa de color de las regiones de decisión */}
              <button
                onClick={() => onToggleHighlight('decisionRegions')}
                className={`p-2 rounded-lg border text-left flex items-center gap-2 cursor-pointer transition ${
                  highlights.decisionRegions ? 'bg-indigo-950/40 border-indigo-500/60 text-white' : 'bg-slate-950 border-slate-800 text-slate-400'
                }`}
              >
                {highlights.decisionRegions ? <CheckSquare className="w-3.5 h-3.5 text-indigo-400" /> : <Square className="w-3.5 h-3.5" />}
                <span>Regiones de Color</span>
              </button>

              {/* Conmutador de los indicadores circulares de holgura xi */}
              <button
                onClick={() => onToggleHighlight('slackLines')}
                className={`p-2 rounded-lg border text-left flex items-center gap-2 cursor-pointer transition ${
                  highlights.slackLines ? 'bg-rose-950/40 border-rose-500/60 text-rose-200' : 'bg-slate-950 border-slate-800 text-slate-400'
                }`}
              >
                {highlights.slackLines ? <CheckSquare className="w-3.5 h-3.5 text-rose-400" /> : <Square className="w-3.5 h-3.5" />}
                <span>Líneas Holgura (ξ)</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* 5. ACCIONES SOBRE EL DATASET Y PRESETS PEDAGÓGICOS */}
      <div className="border-t border-slate-800 pt-4 space-y-2">
        <div className="flex gap-2">
          {/* Botón para inyectar 30 casas más */}
          <button
            onClick={onAddMoreData}
            className="flex-1 py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition border border-slate-700 cursor-pointer"
          >
            <PlusCircle className="w-3.5 h-3.5 text-indigo-400" />
            <span>+30 Viviendas</span>
          </button>

          {/* Botón para reiniciar al dataset limpio de 60 casas */}
          <button
            onClick={onResetData}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition border border-slate-700 cursor-pointer"
            title="Restablecer Dataset Original"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>

        {/* Presets pedagógicos rápidos de un solo clic */}
        <div className="grid grid-cols-3 gap-1.5 pt-1 text-[11px] font-mono">
          <button
            onClick={() => onLoadPreset('clean')}
            className="p-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 text-center transition cursor-pointer"
          >
            Separable
          </button>
          <button
            onClick={() => onLoadPreset('noisy')}
            className="p-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 text-center transition cursor-pointer"
          >
            Con Ruido
          </button>
          <button
            onClick={() => onLoadPreset('nonlinear')}
            className="p-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 text-center transition cursor-pointer"
          >
            No Lineal
          </button>
        </div>
      </div>
    </div>
  );
};
