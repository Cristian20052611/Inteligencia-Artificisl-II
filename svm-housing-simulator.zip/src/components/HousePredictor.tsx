/**
 * TASADOR Y CLASIFICADOR DE VIVIENDAS EN TIEMPO REAL CON SVM
 * Permite al usuario diseñar una propiedad modificando sliders continuos de ingresos, superficie,
 * habitaciones y antigüedad. Evalúa de inmediato la función de decisión f(x) = w·x + b,
 * calcula la distancia al hiperplano, proyecta la probabilidad logística calibrada
 * y permite inyectar la propiedad en el simulador 2D/3D desencadenando un re-entrenamiento automático.
 */

import React, { useState } from 'react';
import { HousingRecord, FeatureKey, SVMModelResult, SVMHyperparameters } from '../types/housing';
import { Home, Plus, Compass } from 'lucide-react';
import confetti from 'canvas-confetti';

/**
 * Propiedades del componente Tasador
 */
interface HousePredictorProps {
  // Modelo SVM entrenado con pesos y multiplicadores duales
  model: SVMModelResult;
  // Hiperparámetros de SVM actuales
  hyperparams: SVMHyperparameters;
  // Callback para inyectar la vivienda creada en el dataset interactivo
  onAddHouse: (house: Partial<HousingRecord>) => void;
}

export const HousePredictor: React.FC<HousePredictorProps> = ({
  model,
  hyperparams,
  onAddHouse,
}) => {
  // 1. ESTADOS LOCALES DE LAS CARACTERÍSTICAS DE LA VIVIENDA SIMULADA
  const [address, setAddress] = useState('770 Ocean Drive');
  const [city, setCity] = useState('Miami Beach');
  const [state, setState] = useState('FL');
  const [income, setIncome] = useState(85000);
  const [age, setAge] = useState(6.5);
  const [rooms, setRooms] = useState(7.2);
  const [bedrooms, setBedrooms] = useState(3.8);
  const [population, setPopulation] = useState(34000);
  const [sqft, setSqft] = useState(2850);

  // Mapeo estructurado de las especificaciones de la vivienda para el clasificador
  const customSpecs: Record<FeatureKey, number> = {
    avgAreaIncome: income,
    avgHouseAge: age,
    avgRooms: rooms,
    avgBedrooms: bedrooms,
    areaPopulation: population,
    squareFeet: sqft,
  };

  // 2. EVALUACIÓN MATEMÁTICA EN TIEMPO REAL CON EL MODELO SVM
  const prediction = model.predictRaw(customSpecs);
  const isLuxury = prediction.label === 1;

  // Valor de tasación hedónica estimada para cotejar con el umbral
  const estimatedPrice = Math.round(
    income * 2.9 + rooms * 31000 + sqft * 60 - age * 2600 + population * 1.4
  );

  // 3. INYECCIÓN DE LA VIVIENDA EN EL DATASET CON CONFETI
  const handleInjectHouse = () => {
    onAddHouse({
      address,
      city,
      state,
      avgAreaIncome: income,
      avgHouseAge: age,
      avgRooms: rooms,
      avgBedrooms: bedrooms,
      areaPopulation: population,
      squareFeet: sqft,
      price: estimatedPrice,
      isCustom: true,
    });

    confetti({
      particleCount: 45,
      spread: 60,
      origin: { y: 0.8 },
    });
  };

  return (
    <div className="flex flex-col h-full bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-2xl space-y-6">
      {/* Encabezado */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
            <Home className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">Tasador & Clasificador SVM en Tiempo Real</h2>
            <p className="text-xs text-slate-400">Modifica las variables para ver la distancia al hiperplano</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 flex-1 overflow-y-auto pr-1">
        {/* COLUMNA 1: CONTROLES DESLIZANTES DE LA VIVIENDA */}
        <div className="space-y-4 bg-slate-950 p-5 rounded-xl border border-slate-800">
          <h3 className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider">
            Características de la Propiedad
          </h3>

          <div className="grid grid-cols-3 gap-2">
            <div>
              <label className="text-[10px] text-slate-500 block mb-1">Ciudad</label>
              <input
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white"
              />
            </div>
            <div>
              <label className="text-[10px] text-slate-500 block mb-1">Estado</label>
              <input
                type="text"
                value={state}
                onChange={(e) => setState(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white"
              />
            </div>
            <div>
              <label className="text-[10px] text-slate-500 block mb-1">Dirección</label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white"
              />
            </div>
          </div>

          {/* Slider de Ingreso Medio de la Zona */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-400">Ingreso Medio:</span>
              <span className="text-amber-400 font-bold">${income.toLocaleString('en-US')}/año</span>
            </div>
            <input
              type="range"
              min="35000"
              max="115000"
              step="1000"
              value={income}
              onChange={(e) => setIncome(Number(e.target.value))}
              className="w-full accent-indigo-500 cursor-pointer"
            />
          </div>

          {/* Slider de Número Promedio de Habitaciones */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-400">Habitaciones:</span>
              <span className="text-cyan-400 font-bold">{rooms} habs</span>
            </div>
            <input
              type="range"
              min="3.0"
              max="9.5"
              step="0.1"
              value={rooms}
              onChange={(e) => setRooms(Number(e.target.value))}
              className="w-full accent-cyan-500 cursor-pointer"
            />
          </div>

          {/* Slider de Antigüedad de la Vivienda */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-400">Antigüedad:</span>
              <span className="text-purple-400 font-bold">{age} años</span>
            </div>
            <input
              type="range"
              min="1"
              max="45"
              step="0.5"
              value={age}
              onChange={(e) => setAge(Number(e.target.value))}
              className="w-full accent-purple-500 cursor-pointer"
            />
          </div>

          {/* Slider de Superficie en Pies Cuadrados */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-400">Superficie Construida:</span>
              <span className="text-emerald-400 font-bold">{sqft.toLocaleString('en-US')} sq ft</span>
            </div>
            <input
              type="range"
              min="900"
              max="4500"
              step="50"
              value={sqft}
              onChange={(e) => setSqft(Number(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
          </div>

          {/* Botón para enviar la casa al simulador interactivo */}
          <button
            onClick={handleInjectHouse}
            className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 transition flex items-center justify-center gap-2 cursor-pointer mt-2"
          >
            <Plus className="w-4 h-4" />
            Inyectar en el Simulador 2D/3D y Reentrenar
          </button>
        </div>

        {/* COLUMNA 2: DIAGNÓSTICO MATEMÁTICO DEL VEREDICTO SVM */}
        <div className="space-y-4">
          <div
            className={`p-6 rounded-2xl border transition-all ${
              isLuxury
                ? 'bg-gradient-to-br from-amber-950/50 to-slate-950 border-amber-500/60 shadow-xl shadow-amber-950/40'
                : 'bg-gradient-to-br from-cyan-950/50 to-slate-950 border-cyan-500/60 shadow-xl shadow-cyan-950/40'
            }`}
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-mono font-bold tracking-wider uppercase text-slate-400">
                Veredicto del Hiperplano SVM
              </span>
              <span
                className={`px-3 py-1 rounded-full text-xs font-bold font-mono ${
                  isLuxury ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                }`}
              >
                Clase {prediction.label === 1 ? '+1' : '-1'}
              </span>
            </div>

            <div className="text-2xl font-extrabold text-white mb-1">
              {isLuxury ? 'Vivienda Alta Gama / Lujo' : 'Vivienda Estándar / Accesible'}
            </div>
            <p className="text-xs text-slate-300 mb-4">
              Precio estimado de tasación: <strong className="text-emerald-400 font-mono text-sm">${estimatedPrice.toLocaleString('en-US')}</strong> (Umbral clasificador: ${hyperparams.priceThreshold.toLocaleString('en-US')})
            </p>

            {/* Marcador de Score y Posición respecto al margen */}
            <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800/80 space-y-3 font-mono text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Valor de Decisión f(x) = w·x + b:</span>
                <span className={`font-bold text-sm ${isLuxury ? 'text-amber-400' : 'text-cyan-400'}`}>
                  {prediction.score >= 0 ? `+${prediction.score.toFixed(3)}` : prediction.score.toFixed(3)}
                </span>
              </div>

              {/* Barra de probabilidad sigmoidea calibrada */}
              <div>
                <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                  <span>Probabilidad Calibrada:</span>
                  <span>{(prediction.probability * 100).toFixed(1)}% Alta Gama</span>
                </div>
                <div className="h-2.5 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                  <div
                    className="h-full bg-gradient-to-r from-cyan-500 via-indigo-500 to-amber-500 transition-all duration-300"
                    style={{ width: `${Math.max(5, Math.min(95, prediction.probability * 100))}%` }}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-1 border-t border-slate-800 text-[11px]">
                <span className="text-slate-400">Posición respecto al Margen:</span>
                <span className="font-semibold text-slate-200">
                  {Math.abs(prediction.score) < 1.0 ? '⚠️ En zona de margen (Incertidumbre)' : '✅ Fuera de margen (Alta certeza)'}
                </span>
              </div>
            </div>
          </div>

          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs text-slate-400 space-y-2">
            <div className="flex items-center gap-2 font-bold text-slate-300">
              <Compass className="w-4 h-4 text-indigo-400" />
              <span>¿Cómo calcula SVM este veredicto?</span>
            </div>
            <p className="leading-relaxed text-[11px]">
              La propiedad se normaliza y se proyecta sobre el vector normal <strong>w</strong>. El signo de <code>w · x + b</code> determina la clase, y la magnitud indica cuántas unidades de margen separan la casa de la frontera neutral.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
