/**
 * DATASET DE PRECIOS DE VIVIENDA EN ESTADOS UNIDOS (USA HOUSING)
 * Contiene metadatos de las características urbanas, el conjunto representativo de 60 viviendas
 * reales y el generador estocástico con la correlación econométrica típica de precios.
 */

import { HousingRecord, FeatureKey, FeatureMeta } from '../types/housing';

/**
 * Diccionario de metadatos de cada característica disponible para el clasificador SVM
 */
export const FEATURE_METAS: Record<FeatureKey, FeatureMeta> = {
  // 1. Ingreso Medio de los hogares en el área geográfica censal
  avgAreaIncome: {
    key: 'avgAreaIncome',
    label: 'Ingreso Medio del Área',
    shortLabel: 'Ingreso',
    unit: 'USD/año',
    // Formatea el valor numérico como moneda estadounidense (ej. $75,000)
    format: (v) => `$${Math.round(v).toLocaleString('en-US')}`,
    min: 35000,
    max: 110000,
    description: 'Ingreso anual promedio de las familias en la zona censal.',
  },
  // 2. Antigüedad promedio de las propiedades en el vecindario
  avgHouseAge: {
    key: 'avgHouseAge',
    label: 'Antigüedad de la Vivienda',
    shortLabel: 'Antigüedad',
    unit: 'años',
    // Formatea con un decimal (ej. 5.6 años)
    format: (v) => `${v.toFixed(1)} años`,
    min: 1,
    max: 50,
    description: 'Años transcurridos desde la construcción de la vivienda.',
  },
  // 3. Cantidad total promedio de habitaciones
  avgRooms: {
    key: 'avgRooms',
    label: 'Habitaciones Totales',
    shortLabel: 'Habitaciones',
    unit: 'habs',
    // Formatea con un decimal (ej. 7.2 habs)
    format: (v) => `${v.toFixed(1)} habs`,
    min: 2,
    max: 10,
    description: 'Número promedio de habitaciones totales (dormitorios, salas, comedores).',
  },
  // 4. Cantidad promedio de dormitorios
  avgBedrooms: {
    key: 'avgBedrooms',
    label: 'Número de Dormitorios',
    shortLabel: 'Dormitorios',
    unit: 'dorm.',
    // Formatea con un decimal (ej. 3.4 dorm.)
    format: (v) => `${v.toFixed(1)} dorm.`,
    min: 1,
    max: 6,
    description: 'Número promedio de dormitorios en la vivienda.',
  },
  // 5. Densidad poblacional del vecindario
  areaPopulation: {
    key: 'areaPopulation',
    label: 'Población del Área',
    shortLabel: 'Población',
    unit: 'hab.',
    // Formatea como número entero con separador de miles
    format: (v) => `${Math.round(v).toLocaleString('en-US')} hab.`,
    min: 10000,
    max: 70000,
    description: 'Densidad y población de la comunidad o vecindario.',
  },
  // 6. Superficie construida habitable
  squareFeet: {
    key: 'squareFeet',
    label: 'Superficie Construida',
    shortLabel: 'Superficie',
    unit: 'sq ft',
    // Formatea en pies cuadrados (ej. 2,450 sq ft)
    format: (v) => `${Math.round(v).toLocaleString('en-US')} sq ft`,
    min: 800,
    max: 4800,
    description: 'Superficie en pies cuadrados de construcción de la propiedad.',
  },
};

/**
 * CONJUNTO INICIAL DE VIVIENDAS DE EE.UU.
 * Contiene 60 propiedades cuidadosamente calibradas que reflejan la distribución real
 * del dataset USA Housing a lo largo de diversas ciudades representativas (Los Angeles,
 * Austin, Seattle, Boston, Denver, Miami, Chicago, Nueva York, etc.).
 */
export const INITIAL_HOUSING_DATA: HousingRecord[] = [
  // Springfield, IL - Casa unifamiliar suburbana con ingreso medio-alto
  { id: 'h-01', address: '742 Evergreen Terrace', city: 'Springfield', state: 'IL', avgAreaIncome: 79545, avgHouseAge: 5.6, avgRooms: 7.0, avgBedrooms: 4.09, areaPopulation: 23086, squareFeet: 2450, price: 558000 },
  // Los Angeles, CA - Propiedad de alta gama en Wilshire Blvd
  { id: 'h-02', address: '10880 Wilshire Blvd', city: 'Los Angeles', state: 'CA', avgAreaIncome: 92350, avgHouseAge: 3.2, avgRooms: 8.2, avgBedrooms: 4.80, areaPopulation: 45200, squareFeet: 3400, price: 742000 },
  // Boston, MA - Casa histórica tradicional en zona céntrica
  { id: 'h-03', address: '221B Baker St', city: 'Boston', state: 'MA', avgAreaIncome: 61200, avgHouseAge: 18.5, avgRooms: 5.8, avgBedrooms: 2.90, areaPopulation: 34100, squareFeet: 1650, price: 389000 },
  // Austin, TX - Propiedad contemporánea en South Congress
  { id: 'h-04', address: '420 South Congress', city: 'Austin', state: 'TX', avgAreaIncome: 84100, avgHouseAge: 4.1, avgRooms: 7.4, avgBedrooms: 3.85, areaPopulation: 28400, squareFeet: 2780, price: 615000 },
  // Washington, DC - Residencia señorial de lujo
  { id: 'h-05', address: '1600 Pennsylvania Ave NW', city: 'Washington', state: 'DC', avgAreaIncome: 98400, avgHouseAge: 12.0, avgRooms: 8.9, avgBedrooms: 5.10, areaPopulation: 51200, squareFeet: 4200, price: 890000 },
  // New York, NY - Departamento amplio en Manhattan
  { id: 'h-06', address: '350 5th Ave', city: 'New York', state: 'NY', avgAreaIncome: 88500, avgHouseAge: 25.0, avgRooms: 6.2, avgBedrooms: 2.70, areaPopulation: 62000, squareFeet: 1850, price: 620000 },
  // Chicago, IL - Vivienda clásica de ladrillo en Grand Ave
  { id: 'h-07', address: '700 E Grand Ave', city: 'Chicago', state: 'IL', avgAreaIncome: 65400, avgHouseAge: 15.2, avgRooms: 6.0, avgBedrooms: 3.10, areaPopulation: 38900, squareFeet: 1920, price: 410000 },
  // Universal City, CA - Villa californiana en zona residencial
  { id: 'h-08', address: '100 Universal City Plaza', city: 'Universal City', state: 'CA', avgAreaIncome: 86900, avgHouseAge: 6.8, avgRooms: 7.6, avgBedrooms: 4.20, areaPopulation: 31500, squareFeet: 2950, price: 680000 },
  // Seattle, WA - Casa moderna cerca de Space Needle
  { id: 'h-09', address: '400 Broad St', city: 'Seattle', state: 'WA', avgAreaIncome: 91200, avgHouseAge: 7.5, avgRooms: 7.8, avgBedrooms: 3.90, areaPopulation: 36700, squareFeet: 3100, price: 710000 },
  // Miami, FL - Propiedad cerca de South Beach
  { id: 'h-10', address: '1111 Lincoln Rd', city: 'Miami', state: 'FL', avgAreaIncome: 74200, avgHouseAge: 8.9, avgRooms: 6.8, avgBedrooms: 3.40, areaPopulation: 29800, squareFeet: 2350, price: 530000 },
  // Los Angeles, CA - Casa estándar accesible con mayor antigüedad
  { id: 'h-11', address: '1200 S Figueroa St', city: 'Los Angeles', state: 'CA', avgAreaIncome: 58900, avgHouseAge: 22.0, avgRooms: 5.2, avgBedrooms: 2.40, areaPopulation: 41000, squareFeet: 1420, price: 345000 },
  // Austin, TX - Propiedad urbana en 2nd St
  { id: 'h-12', address: '500 W 2nd St', city: 'Austin', state: 'TX', avgAreaIncome: 71800, avgHouseAge: 11.4, avgRooms: 6.5, avgBedrooms: 3.20, areaPopulation: 26500, squareFeet: 2200, price: 485000 },
  // Denver, CO - Casa unifamiliar cerca de Union Station
  { id: 'h-13', address: '1701 Wynkoop St', city: 'Denver', state: 'CO', avgAreaIncome: 82400, avgHouseAge: 5.2, avgRooms: 7.2, avgBedrooms: 3.70, areaPopulation: 32800, squareFeet: 2600, price: 590000 },
  // Phoenix, AZ - Casa suburbana accesible de un piso
  { id: 'h-14', address: '100 North 3rd St', city: 'Phoenix', state: 'AZ', avgAreaIncome: 54100, avgHouseAge: 14.8, avgRooms: 5.6, avgBedrooms: 2.80, areaPopulation: 22400, squareFeet: 1700, price: 320000 },
  // Atlanta, GA - Residencia arbolada en Peachtree St
  { id: 'h-15', address: '200 Peachtree St', city: 'Atlanta', state: 'GA', avgAreaIncome: 67300, avgHouseAge: 13.0, avgRooms: 6.4, avgBedrooms: 3.30, areaPopulation: 35200, squareFeet: 2150, price: 440000 },
  // San Diego, CA - Casa costera de alta gama
  { id: 'h-16', address: '1400 6th Ave', city: 'San Diego', state: 'CA', avgAreaIncome: 89400, avgHouseAge: 4.8, avgRooms: 7.9, avgBedrooms: 4.10, areaPopulation: 39400, squareFeet: 3250, price: 730000 },
  // Nashville, TN - Vivienda suburbana tranquila
  { id: 'h-17', address: '222 2nd Ave S', city: 'Nashville', state: 'TN', avgAreaIncome: 63500, avgHouseAge: 16.5, avgRooms: 5.9, avgBedrooms: 3.00, areaPopulation: 25100, squareFeet: 1880, price: 395000 },
  // Charlotte, NC - Propiedad familiar en crecimiento
  { id: 'h-18', address: '500 E 4th St', city: 'Charlotte', state: 'NC', avgAreaIncome: 76800, avgHouseAge: 6.1, avgRooms: 6.9, avgBedrooms: 3.60, areaPopulation: 28900, squareFeet: 2480, price: 540000 },
  // Baltimore, MD - Casa adosada con antigüedad de 28 años
  { id: 'h-19', address: '100 E Pratt St', city: 'Baltimore', state: 'MD', avgAreaIncome: 48900, avgHouseAge: 28.5, avgRooms: 4.8, avgBedrooms: 2.20, areaPopulation: 38200, squareFeet: 1300, price: 265000 },
  // Houston, TX - Casa espaciosa en suburbio tejano
  { id: 'h-20', address: '1000 Main St', city: 'Houston', state: 'TX', avgAreaIncome: 69200, avgHouseAge: 9.8, avgRooms: 6.6, avgBedrooms: 3.50, areaPopulation: 44100, squareFeet: 2300, price: 470000 },
  // Minneapolis, MN - Casa con aislamiento térmico y buen metraje
  { id: 'h-21', address: '800 Nicollet Mall', city: 'Minneapolis', state: 'MN', avgAreaIncome: 75400, avgHouseAge: 10.2, avgRooms: 6.7, avgBedrooms: 3.40, areaPopulation: 27300, squareFeet: 2380, price: 510000 },
  // New York, NY - Penthouse de lujo cerca de Central Park
  { id: 'h-22', address: '1000 5th Ave', city: 'New York', state: 'NY', avgAreaIncome: 104500, avgHouseAge: 32.0, avgRooms: 8.5, avgBedrooms: 4.50, areaPopulation: 58000, squareFeet: 3600, price: 880000 },
  // Orlando, FL - Casa suburbana accesible
  { id: 'h-23', address: '200 S Orange Ave', city: 'Orlando', state: 'FL', avgAreaIncome: 52800, avgHouseAge: 19.4, avgRooms: 5.4, avgBedrooms: 2.60, areaPopulation: 31000, squareFeet: 1580, price: 310000 },
  // Portland, OR - Vivienda ecológica con jardín
  { id: 'h-24', address: '111 SW 5th Ave', city: 'Portland', state: 'OR', avgAreaIncome: 78200, avgHouseAge: 12.5, avgRooms: 7.1, avgBedrooms: 3.50, areaPopulation: 33400, squareFeet: 2520, price: 565000 },
  // Tulsa, OK - Casa unifamiliar accesible de bajo costo
  { id: 'h-25', address: '401 S Boston Ave', city: 'Tulsa', state: 'OK', avgAreaIncome: 46200, avgHouseAge: 24.1, avgRooms: 4.9, avgBedrooms: 2.30, areaPopulation: 19800, squareFeet: 1390, price: 245000 },
  // Tampa, FL - Residencia cercana a la bahía
  { id: 'h-26', address: '100 N Tampa St', city: 'Tampa', state: 'FL', avgAreaIncome: 64800, avgHouseAge: 11.0, avgRooms: 6.1, avgBedrooms: 3.10, areaPopulation: 26800, squareFeet: 2020, price: 425000 },
  // Cleveland, OH - Propiedad antigua con precio accesible
  { id: 'h-27', address: '600 Superior Ave', city: 'Cleveland', state: 'OH', avgAreaIncome: 42100, avgHouseAge: 35.0, avgRooms: 4.5, avgBedrooms: 2.10, areaPopulation: 36000, squareFeet: 1250, price: 215000 },
  // Charlotte, NC - Propiedad moderna de alta plusvalía
  { id: 'h-28', address: '100 N Tryon St', city: 'Charlotte', state: 'NC', avgAreaIncome: 83500, avgHouseAge: 3.9, avgRooms: 7.5, avgBedrooms: 3.90, areaPopulation: 31200, squareFeet: 2850, price: 625000 },
  // Nashville, TN - Casa renovada con buena ubicación
  { id: 'h-29', address: '150 4th Ave N', city: 'Nashville', state: 'TN', avgAreaIncome: 72900, avgHouseAge: 8.1, avgRooms: 6.8, avgBedrooms: 3.40, areaPopulation: 27900, squareFeet: 2280, price: 495000 },
  // Raleigh, NC - Vivienda en el Research Triangle Park
  { id: 'h-30', address: '300 S Tryon St', city: 'Raleigh', state: 'NC', avgAreaIncome: 85600, avgHouseAge: 4.5, avgRooms: 7.7, avgBedrooms: 4.00, areaPopulation: 29500, squareFeet: 2900, price: 640000 },
  // Houston, TX - Propiedad económica
  { id: 'h-31', address: '1100 Louisiana St', city: 'Houston', state: 'TX', avgAreaIncome: 56700, avgHouseAge: 17.2, avgRooms: 5.5, avgBedrooms: 2.70, areaPopulation: 42000, squareFeet: 1620, price: 335000 },
  // San Francisco, CA - Mansión en Pacific Heights (máximo precio)
  { id: 'h-32', address: '50 California St', city: 'San Francisco', state: 'CA', avgAreaIncome: 108200, avgHouseAge: 16.0, avgRooms: 8.4, avgBedrooms: 4.20, areaPopulation: 48900, squareFeet: 3500, price: 895000 },
  // Seattle, WA - Casa cerca de lago con alta demanda
  { id: 'h-33', address: '1201 3rd Ave', city: 'Seattle', state: 'WA', avgAreaIncome: 87400, avgHouseAge: 5.8, avgRooms: 7.4, avgBedrooms: 3.80, areaPopulation: 34500, squareFeet: 2820, price: 660000 },
  // Houston, TX - Casa de lujo en Post Oak
  { id: 'h-34', address: '1330 Post Oak Blvd', city: 'Houston', state: 'TX', avgAreaIncome: 94100, avgHouseAge: 4.2, avgRooms: 8.1, avgBedrooms: 4.40, areaPopulation: 33100, squareFeet: 3350, price: 735000 },
  // Cleveland, OH - Vivienda estándar modesta
  { id: 'h-35', address: '200 Public Square', city: 'Cleveland', state: 'OH', avgAreaIncome: 44800, avgHouseAge: 31.0, avgRooms: 4.7, avgBedrooms: 2.20, areaPopulation: 24500, squareFeet: 1320, price: 230000 },
  // Fort Lauderdale, FL - Residencia cercana a los canales náuticos
  { id: 'h-36', address: '200 E Las Olas Blvd', city: 'Fort Lauderdale', state: 'FL', avgAreaIncome: 81200, avgHouseAge: 7.2, avgRooms: 7.0, avgBedrooms: 3.60, areaPopulation: 26100, squareFeet: 2550, price: 585000 },
  // Charlotte, NC - Casa unifamiliar tradicional
  { id: 'h-37', address: '301 S College St', city: 'Charlotte', state: 'NC', avgAreaIncome: 66100, avgHouseAge: 14.0, avgRooms: 6.2, avgBedrooms: 3.10, areaPopulation: 29800, squareFeet: 2050, price: 430000 },
  // Milwaukee, WI - Casa accesible en barrio histórico
  { id: 'h-38', address: '100 E Wisconsin Ave', city: 'Milwaukee', state: 'WI', avgAreaIncome: 51200, avgHouseAge: 26.0, avgRooms: 5.1, avgBedrooms: 2.50, areaPopulation: 32000, squareFeet: 1510, price: 290000 },
  // Denver, CO - Residencia contemporánea con vistas a las Rocosas
  { id: 'h-39', address: '1801 California St', city: 'Denver', state: 'CO', avgAreaIncome: 86400, avgHouseAge: 4.7, avgRooms: 7.6, avgBedrooms: 3.90, areaPopulation: 31000, squareFeet: 2910, price: 655000 },
  // Memphis, TN - Propiedad con precio de entrada al mercado
  { id: 'h-40', address: '100 N Main St', city: 'Memphis', state: 'TN', avgAreaIncome: 41500, avgHouseAge: 33.2, avgRooms: 4.4, avgBedrooms: 2.00, areaPopulation: 35400, squareFeet: 1210, price: 205000 },
  // Los Angeles, CA - Casa intermedia en Los Angeles
  { id: 'h-41', address: '601 S Figueroa St', city: 'Los Angeles', state: 'CA', avgAreaIncome: 77500, avgHouseAge: 13.5, avgRooms: 6.9, avgBedrooms: 3.50, areaPopulation: 42500, squareFeet: 2420, price: 545000 },
  // San Francisco, CA - Residencia Victoriana restaurada
  { id: 'h-42', address: '555 California St', city: 'San Francisco', state: 'CA', avgAreaIncome: 102100, avgHouseAge: 14.8, avgRooms: 8.3, avgBedrooms: 4.10, areaPopulation: 47200, squareFeet: 3450, price: 860000 },
  // Miami, FL - Departamento con vista al mar
  { id: 'h-43', address: '100 N Biscayne Blvd', city: 'Miami', state: 'FL', avgAreaIncome: 73500, avgHouseAge: 10.4, avgRooms: 6.6, avgBedrooms: 3.30, areaPopulation: 31800, squareFeet: 2310, price: 515000 },
  // Dallas, TX - Propiedad en Dallas Arts District
  { id: 'h-44', address: '2200 Ross Ave', city: 'Dallas', state: 'TX', avgAreaIncome: 80900, avgHouseAge: 6.5, avgRooms: 7.3, avgBedrooms: 3.75, areaPopulation: 36200, squareFeet: 2680, price: 595000 },
  // Seattle, WA - Residencia de alta gama en Queen Anne
  { id: 'h-45', address: '1111 3rd Ave', city: 'Seattle', state: 'WA', avgAreaIncome: 95400, avgHouseAge: 3.8, avgRooms: 8.0, avgBedrooms: 4.20, areaPopulation: 35800, squareFeet: 3280, price: 760000 },
  // Chicago, IL - Departamento en Wacker Drive junto al río
  { id: 'h-46', address: '200 S Wacker Dr', city: 'Chicago', state: 'IL', avgAreaIncome: 70100, avgHouseAge: 18.0, avgRooms: 6.3, avgBedrooms: 3.00, areaPopulation: 45000, squareFeet: 2100, price: 460000 },
  // St. Louis, MO - Casa unifamiliar clásica de ladrillo
  { id: 'h-47', address: '101 S Hanley Rd', city: 'St. Louis', state: 'MO', avgAreaIncome: 57800, avgHouseAge: 21.0, avgRooms: 5.6, avgBedrooms: 2.80, areaPopulation: 26400, squareFeet: 1690, price: 350000 },
  // Charlotte, NC - Vivienda nueva en urbanización privada
  { id: 'h-48', address: '400 S Tryon St', city: 'Charlotte', state: 'NC', avgAreaIncome: 88100, avgHouseAge: 3.2, avgRooms: 7.8, avgBedrooms: 4.05, areaPopulation: 28700, squareFeet: 3050, price: 690000 },
  // Seattle, WA - Propiedad en Ballard
  { id: 'h-49', address: '1001 4th Ave', city: 'Seattle', state: 'WA', avgAreaIncome: 76100, avgHouseAge: 9.1, avgRooms: 6.9, avgBedrooms: 3.45, areaPopulation: 33900, squareFeet: 2410, price: 535000 },
  // Los Angeles, CA - Casa moderna en colina
  { id: 'h-50', address: '333 S Grand Ave', city: 'Los Angeles', state: 'CA', avgAreaIncome: 93800, avgHouseAge: 5.0, avgRooms: 8.1, avgBedrooms: 4.30, areaPopulation: 39100, squareFeet: 3380, price: 750000 },
  // Miami, FL - Villa en Brickell
  { id: 'h-51', address: '1221 Brickell Ave', city: 'Miami', state: 'FL', avgAreaIncome: 86100, avgHouseAge: 5.9, avgRooms: 7.5, avgBedrooms: 3.85, areaPopulation: 30400, squareFeet: 2880, price: 650000 },
  // Washington, DC - Residencia en Dupont Circle
  { id: 'h-52', address: '1100 15th St NW', city: 'Washington', state: 'DC', avgAreaIncome: 91800, avgHouseAge: 10.5, avgRooms: 7.7, avgBedrooms: 3.95, areaPopulation: 43200, squareFeet: 3150, price: 720000 },
  // Indianapolis, IN - Propiedad accesible para familias
  { id: 'h-53', address: '100 N Senate Ave', city: 'Indianapolis', state: 'IN', avgAreaIncome: 53600, avgHouseAge: 23.5, avgRooms: 5.3, avgBedrooms: 2.65, areaPopulation: 29000, squareFeet: 1600, price: 315000 },
  // Denver, CO - Casa en Cherry Creek
  { id: 'h-54', address: '1200 17th St', city: 'Denver', state: 'CO', avgAreaIncome: 79900, avgHouseAge: 7.8, avgRooms: 7.1, avgBedrooms: 3.60, areaPopulation: 31900, squareFeet: 2580, price: 575000 },
  // Chicago, IL - Condominio frente a Millennium Park
  { id: 'h-55', address: '300 E Randolph St', city: 'Chicago', state: 'IL', avgAreaIncome: 83900, avgHouseAge: 8.5, avgRooms: 7.4, avgBedrooms: 3.75, areaPopulation: 41200, squareFeet: 2790, price: 610000 },
  // Austin, TX - Casa de arquitecto en Congress Ave
  { id: 'h-56', address: '600 Congress Ave', city: 'Austin', state: 'TX', avgAreaIncome: 87800, avgHouseAge: 3.5, avgRooms: 7.7, avgBedrooms: 4.10, areaPopulation: 29100, squareFeet: 3000, price: 675000 },
  // Los Angeles, CA - Casa accesible cerca del distrito financiero
  { id: 'h-57', address: '777 S Figueroa St', city: 'Los Angeles', state: 'CA', avgAreaIncome: 68900, avgHouseAge: 16.2, avgRooms: 6.1, avgBedrooms: 3.05, areaPopulation: 43800, squareFeet: 2080, price: 450000 },
  // Miami, FL - Penthouse frente al mar
  { id: 'h-58', address: '200 S Biscayne Blvd', city: 'Miami', state: 'FL', avgAreaIncome: 96200, avgHouseAge: 4.0, avgRooms: 8.2, avgBedrooms: 4.40, areaPopulation: 34800, squareFeet: 3520, price: 780000 },
  // Houston, TX - Casa espaciosa tradicional
  { id: 'h-59', address: '1001 Fannin St', city: 'Houston', state: 'TX', avgAreaIncome: 62400, avgHouseAge: 15.0, avgRooms: 5.8, avgBedrooms: 2.95, areaPopulation: 39500, squareFeet: 1840, price: 385000 },
  // Detroit, MI - Casa con valor de remate accesible
  { id: 'h-60', address: '500 Woodward Ave', city: 'Detroit', state: 'MI', avgAreaIncome: 39500, avgHouseAge: 38.0, avgRooms: 4.2, avgBedrooms: 1.90, areaPopulation: 37500, squareFeet: 1150, price: 185000 },
];

/**
 * GENERADOR DE VIVIENDAS SINTÉTICAS CON CORRELACIÓN REAL
 * Permite al usuario generar dinámicamente lotes adicionales de 30 o 40 viviendas
 * respetando la ecuación econométrica observada en el mercado estadounidense real.
 */
export function generateSyntheticHouses(count: number = 40): HousingRecord[] {
  // Ciudades de referencia con sus ingresos base promedio
  const cities = [
    { city: 'Austin', state: 'TX', baseIncome: 82000 },
    { city: 'Seattle', state: 'WA', baseIncome: 90000 },
    { city: 'Denver', state: 'CO', baseIncome: 80000 },
    { city: 'Miami', state: 'FL', baseIncome: 74000 },
    { city: 'Cleveland', state: 'OH', baseIncome: 45000 },
    { city: 'San Jose', state: 'CA', baseIncome: 105000 },
    { city: 'Phoenix', state: 'AZ', baseIncome: 58000 },
    { city: 'Atlanta', state: 'GA', baseIncome: 69000 },
  ];

  // Arreglo para acumular los nuevos registros generados
  const results: HousingRecord[] = [];

  // Bucle para construir cada vivienda con correlación física real
  for (let i = 0; i < count; i++) {
    // Escogemos una ciudad aleatoria de la lista
    const loc = cities[Math.floor(Math.random() * cities.length)];
    // Ingreso medio con varianza estocástica normal
    const income = Math.round(loc.baseIncome + (Math.random() - 0.5) * 35000);
    // Antigüedad entre 2 y 34 años
    const age = +(2 + Math.random() * 32).toFixed(1);
    // Habitaciones correlacionadas positivamente con el nivel de ingresos
    const rooms = +(4.0 + (income / 110000) * 3.5 + (Math.random() - 0.5) * 1.5).toFixed(1);
    // Dormitorios correlacionados con el total de habitaciones
    const bedrooms = +(1.5 + (rooms / 9) * 3.2 + (Math.random() - 0.5) * 0.8).toFixed(2);
    // Población censal aleatoria en zona metropolitana
    const population = Math.round(15000 + Math.random() * 45000);
    // Superficie construida proporcional a las habitaciones
    const sqft = Math.round(1000 + (rooms * 280) + (Math.random() - 0.5) * 400);

    // FÓRMULA ECONOMÉTRICA DEL PRECIO EN EE.UU.:
    // Precio ≈ (Ingreso * 2.9) + (Habitaciones * $31,000) + (Pies² * $60) - (Años * $2,600) + (Población * 1.4) ± ruido
    const price = Math.round(
      income * 2.9 +
      rooms * 31000 +
      sqft * 60 -
      age * 2600 +
      population * 1.4 +
      (Math.random() - 0.5) * 30000
    );

    // Insertamos la vivienda sintética con sus límites acotados
    results.push({
      id: `syn-${i + 1}`,
      address: `${100 + i * 14} Suburban Way`,
      city: loc.city,
      state: loc.state,
      avgAreaIncome: Math.max(35000, Math.min(115000, income)),
      avgHouseAge: Math.max(1, age),
      avgRooms: Math.max(2.5, Math.min(9.5, rooms)),
      avgBedrooms: Math.max(1, Math.min(5.5, bedrooms)),
      areaPopulation: population,
      squareFeet: Math.max(800, Math.min(4800, sqft)),
      price: Math.max(160000, Math.min(950000, price)),
    });
  }

  // Retornamos la colección generada
  return results;
}
