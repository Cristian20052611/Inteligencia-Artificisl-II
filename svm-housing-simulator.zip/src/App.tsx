/**
 * APLICACIÓN PRINCIPAL: SIMULADOR PEDAGÓGICO DE MÁQUINAS DE SOPORTE VECTORIAL (SVM)
 * Coordina el estado global, el dataset de viviendas de EE.UU. (Housing Dataset),
 * el entrenamiento en tiempo real de SVM (2D y 3D), la navegación por pestañas didácticas,
 * y la comunicación entre los paneles de control, métricas, laboratorio matemático y visualizadores.
 */

import React, { useState, useMemo, useCallback } from 'react';
import {
  HousingRecord,
  FeatureKey,
  SVMHyperparameters,
  SVMComponentHighlight,
  AppTab,
} from './types/housing';
import { INITIAL_HOUSING_DATA, generateSyntheticHouses } from './data/housingDataset';
import { prepareDataset, solveSVM } from './ml/svmSolver';
import { SVM2DVisualizer } from './components/SVM2DVisualizer';
import { SVM3DVisualizer } from './components/SVM3DVisualizer';
import { ControlPanel } from './components/ControlPanel';
import { MetricsBar } from './components/MetricsBar';
import { PedagogicalGuide } from './components/PedagogicalGuide';
import { SVMChallenges } from './components/SVMChallenges';
import { HousePredictor } from './components/HousePredictor';
import { FormulaLab } from './components/FormulaLab';
import {
  Box,
  Layers,
  BookOpen,
  Trophy,
  Home,
  Sigma,
  Sparkles,
  X,
} from 'lucide-react';

export default function App() {
  // 1. ESTADO DE NAVEGACIÓN: Pestaña didáctica activa (Simulador, Guía, Desafíos, Tasador, Fórmulas)
  const [activeTab, setActiveTab] = useState<AppTab>('simulator');

  // 2. ESTADO DE DATOS: Registros de viviendas estadounidenses cargados en memoria
  const [records, setRecords] = useState<HousingRecord[]>(INITIAL_HOUSING_DATA);
  // Vivienda actualmente seleccionada para inspección minuciosa
  const [selectedHouse, setSelectedHouse] = useState<HousingRecord | null>(null);

  // 3. ESTADO DE DIMENSIÓN Y VARIABLES: Selección de 2D vs 3D y características de los ejes
  const [mode3D, setMode3D] = useState<boolean>(false);
  // Características seleccionadas para el plano bidimensional [Eje X, Eje Y]
  const [features2D, setFeatures2D] = useState<[FeatureKey, FeatureKey]>([
    'avgAreaIncome',
    'squareFeet',
  ]);
  // Características seleccionadas para el espacio tridimensional [Eje X, Eje Y, Eje Z]
  const [features3D, setFeatures3D] = useState<[FeatureKey, FeatureKey, FeatureKey]>([
    'avgAreaIncome',
    'squareFeet',
    'avgHouseAge',
  ]);

  // 4. ESTADO DE HIPERPARÁMETROS SVM: Regularización C, Kernel, Gamma, Grado y Umbral de precio
  const [hyperparams, setHyperparams] = useState<SVMHyperparameters>({
    C: 1.0, // Factor de penalización de margen blando
    kernel: 'linear', // Tipo de función Kernel por defecto
    gamma: 1.0, // Parámetro de alcance para Kernel RBF
    polyDegree: 2, // Grado para Kernel polinómico
    priceThreshold: 500000, // Umbral de $500,000 USD para separar Alta Gama (+1) de Accesible (-1)
  });

  // 5. ESTADO DE CAPAS VISUALES: Interruptores para mostrar u ocultar componentes geométricos
  const [highlights, setHighlights] = useState<SVMComponentHighlight>({
    hyperplane: true, // Línea/Plano separador w·x + b = 0
    margins: true, // Corredores y límites de margen w·x + b = ±1
    supportVectors: true, // Halos y anillos en vectores de soporte
    slackLines: true, // Indicadores de violaciones de holgura xi
    decisionRegions: true, // Mapa de calor con colores de clasificación
    normalVector: true, // Vector perpendicular w
  });

  // 6. ESTADO DE NOTIFICACIONES: Mensajes pedagógicos flotantes en pantalla
  const [bannerMessage, setBannerMessage] = useState<string | null>(null);

  /**
   * Muestra un aviso flotante y lo desvanece automáticamente a los 4 segundos
   */
  const showNotification = (msg: string) => {
    setBannerMessage(msg);
    setTimeout(() => {
      setBannerMessage(null);
    }, 4000);
  };

  // 7. PREPARACIÓN Y NORMALIZACIÓN DEL DATASET 2D EN MEMORIA
  const dataset2D = useMemo(() => {
    return prepareDataset(records, features2D, hyperparams.priceThreshold);
  }, [records, features2D, hyperparams.priceThreshold]);

  // 8. ENTRENAMIENTO MATEMÁTICO DEL MODELO SVM 2D MEDIANTE SMO
  const model2D = useMemo(() => {
    return solveSVM(dataset2D, hyperparams, features2D);
  }, [dataset2D, hyperparams, features2D]);

  // 9. CONMUTADOR DE CAPAS VISUALES INDIVIDUALES
  const handleToggleHighlight = (key: keyof SVMComponentHighlight) => {
    setHighlights((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  // 10. INSERCIÓN DE NUEVA VIVIENDA PERSONALIZADA CON RE-ENTRENAMIENTO INSTANTÁNEO
  const handleAddCustomHouse = useCallback((houseData: Partial<HousingRecord>) => {
    const newHouse: HousingRecord = {
      id: `custom-${Date.now()}`,
      address: houseData.address || 'Vivienda Personalizada',
      city: houseData.city || 'Simulador City',
      state: houseData.state || 'US',
      avgAreaIncome: houseData.avgAreaIncome || 75000,
      avgHouseAge: houseData.avgHouseAge || 8.0,
      avgRooms: houseData.avgRooms || 6.8,
      avgBedrooms: houseData.avgBedrooms || 3.4,
      areaPopulation: houseData.areaPopulation || 30000,
      squareFeet: houseData.squareFeet || 2400,
      price: houseData.price || hyperparams.priceThreshold,
      isCustom: true,
    };

    // Añadimos la casa al inicio del array para que el reentrenamiento sea reactivo
    setRecords((prev) => [newHouse, ...prev]);
    setSelectedHouse(newHouse);
    showNotification(`Vivienda agregada en ${newHouse.city}. ¡El SVM se ha reentrenado con el nuevo dato!`);
  }, [hyperparams.priceThreshold]);

  // 11. GENERACIÓN DE LOTE SINTÉTICO: Agrega 30 casas más con correlación estadística realista
  const handleAddMoreData = () => {
    const synthetic = generateSyntheticHouses(30);
    setRecords((prev) => [...prev, ...synthetic]);
    showNotification(`Se añadieron 30 viviendas adicionales con correlación real del mercado estadounidense.`);
  };

  // 12. RESTABLECIMIENTO DEL CONJUNTO DE DATOS ORIGINAL (60 VIVIENDAS BASE)
  const handleResetData = () => {
    setRecords(INITIAL_HOUSING_DATA);
    setSelectedHouse(null);
    showNotification('Dataset restaurado al conjunto original de 60 viviendas.');
  };

  // 13. CARGA DE PRESETS DIDÁCTICOS (Separable, Con Ruido, No Lineal)
  const handleLoadPreset = (preset: 'clean' | 'noisy' | 'nonlinear') => {
    if (preset === 'clean') {
      // Caso ideal: clases netamente separables con margen duro y nítido
      setHyperparams({
        C: 5.0,
        kernel: 'linear',
        gamma: 1.0,
        polyDegree: 2,
        priceThreshold: 480000,
      });
      setFeatures2D(['avgAreaIncome', 'squareFeet']);
      setFeatures3D(['avgAreaIncome', 'squareFeet', 'avgRooms']);
      showNotification('Preset activado: Clases altamente separables con margen nítido.');
    } else if (preset === 'noisy') {
      // Caso con solapamiento: margen blando con holguras xi elevadas
      setHyperparams({
        C: 0.15,
        kernel: 'linear',
        gamma: 1.0,
        polyDegree: 2,
        priceThreshold: 530000,
      });
      setFeatures2D(['avgHouseAge', 'areaPopulation']);
      setFeatures3D(['avgHouseAge', 'areaPopulation', 'avgRooms']);
      showNotification('Preset activado: Datos solapados con variables de holgura ξ y margen blando (C=0.15).');
    } else if (preset === 'nonlinear') {
      // Caso circular concéntrico: requiere Kernel Gaussiano RBF para separar con curva
      setHyperparams({
        C: 3.0,
        kernel: 'rbf',
        gamma: 2.2,
        polyDegree: 3,
        priceThreshold: 510000,
      });
      setFeatures2D(['avgHouseAge', 'squareFeet']);
      setFeatures3D(['avgHouseAge', 'squareFeet', 'avgAreaIncome']);
      showNotification('Preset activado: Frontera curva no lineal mediante Kernel Gaussiano RBF.');
    }
  };

  // 14. APLICAR CONFIGURACIÓN DESDE LA GUÍA PEDAGÓGICA
  const handleApplyGuidePreset = (
    params: Partial<SVMHyperparameters>,
    feats?: [FeatureKey, FeatureKey]
  ) => {
    setHyperparams((prev) => ({ ...prev, ...params }));
    if (feats) setFeatures2D(feats);
    setActiveTab('simulator');
    showNotification('Configuración aplicada al simulador interactivo.');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* BARRA SUPERIOR DE ENCABEZADO Y NAVEGACIÓN */}
      <header className="border-b border-slate-800/80 bg-slate-950/80 backdrop-blur-xl sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {/* Logotipo vectorial con gradiente sutil */}
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-amber-500 flex items-center justify-center shadow-lg shadow-indigo-600/30">
              <Box className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-extrabold text-base md:text-lg tracking-tight text-white">
                  SVM Housing Simulator
                </h1>
                <span className="text-[10px] uppercase font-mono font-bold tracking-wider px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 hidden sm:inline-block">
                  USA Real Estate
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden md:block">
                Simulador pedagógico de Máquinas de Soporte Vectorial en 2D y 3D
              </p>
            </div>
          </div>

          {/* BOTONES DE LAS PESTAÑAS DE NAVEGACIÓN */}
          <nav className="flex items-center gap-1 bg-slate-900/90 p-1 rounded-xl border border-slate-800">
            {/* Pestaña: Simulador 2D / 3D */}
            <button
              onClick={() => setActiveTab('simulator')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'simulator'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Simulador</span>
            </button>

            {/* Pestaña: Guía Pedagógica paso a paso */}
            <button
              onClick={() => setActiveTab('guided-learning')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'guided-learning'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Aprende Paso a Paso</span>
              <span className="sm:hidden">Guía</span>
            </button>

            {/* Pestaña: Desafíos gamificados */}
            <button
              onClick={() => setActiveTab('challenges')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'challenges'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Trophy className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Desafíos</span>
            </button>

            {/* Pestaña: Tasador y Clasificador Interactivo */}
            <button
              onClick={() => setActiveTab('predictor')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'predictor'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Home className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Tasador</span>
            </button>

            {/* Pestaña: Laboratorio Matemático y Fórmulas */}
            <button
              onClick={() => setActiveTab('math-lab')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'math-lab'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Sigma className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Fórmulas</span>
            </button>
          </nav>
        </div>
      </header>

      {/* TOAST FLOTANTE DE NOTIFICACIÓN INFORMATIVA */}
      {bannerMessage && (
        <div className="fixed top-20 right-6 z-50 animate-bounce">
          <div className="bg-indigo-600 text-white px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-2 text-xs font-semibold border border-indigo-400/50">
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>{bannerMessage}</span>
          </div>
        </div>
      )}

      {/* CUERPO PRINCIPAL DE LA APLICACIÓN */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        {/* PESTAÑA 1: SIMULADOR INTERACTIVO 2D Y 3D */}
        {activeTab === 'simulator' && (
          <div className="space-y-5">
            {/* Barra de métricas cuantitativas calculadas en tiempo real */}
            <MetricsBar
              model={model2D}
              hyperparams={hyperparams}
              totalHouses={records.length}
            />

            {/* Rejilla responsive: Visualizador (8 columnas) + Panel de Control (4 columnas) */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Columna Izquierda: Lienzo 2D o Escenario 3D */}
              <div className="lg:col-span-8 flex flex-col h-[580px]">
                {!mode3D ? (
                  <SVM2DVisualizer
                    dataset={dataset2D}
                    model={model2D}
                    features={features2D}
                    hyperparams={hyperparams}
                    highlights={highlights}
                    onAddCustomHouse={handleAddCustomHouse}
                    onSelectHouse={setSelectedHouse}
                    selectedHouseId={selectedHouse?.id}
                  />
                ) : (
                  <SVM3DVisualizer
                    records={records}
                    features3D={features3D}
                    hyperparams={hyperparams}
                    highlights={highlights}
                    onSelectHouse={setSelectedHouse}
                    selectedHouseId={selectedHouse?.id}
                  />
                )}
              </div>

              {/* Columna Derecha: Panel de Configuración de Hiperparámetros y Variables */}
              <div className="lg:col-span-4">
                <ControlPanel
                  mode3D={mode3D}
                  onToggle3D={setMode3D}
                  features2D={features2D}
                  onChangeFeatures2D={setFeatures2D}
                  features3D={features3D}
                  onChangeFeatures3D={setFeatures3D}
                  hyperparams={hyperparams}
                  onChangeHyperparams={setHyperparams}
                  highlights={highlights}
                  onToggleHighlight={handleToggleHighlight}
                  onAddMoreData={handleAddMoreData}
                  onResetData={handleResetData}
                  onLoadPreset={handleLoadPreset}
                />
              </div>
            </div>

            {/* Ficha descriptiva emergente si el usuario hace clic sobre una vivienda */}
            {selectedHouse && (
              <div className="bg-slate-900/95 border border-indigo-500/50 p-4 rounded-2xl shadow-2xl flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
                    <Home className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-white text-sm">
                        {selectedHouse.address}, {selectedHouse.city} ({selectedHouse.state})
                      </h4>
                      {selectedHouse.isCustom && (
                        <span className="bg-purple-500/20 text-purple-300 text-[10px] font-mono px-2 py-0.5 rounded border border-purple-500/30">
                          Personalizada
                        </span>
                      )}
                    </div>
                    <div className="flex flex-wrap gap-4 text-xs font-mono text-slate-400 mt-0.5">
                      <span>Precio: <strong className="text-emerald-400">${selectedHouse.price.toLocaleString('en-US')}</strong></span>
                      <span>Ingreso: <strong>${Math.round(selectedHouse.avgAreaIncome).toLocaleString('en-US')}</strong></span>
                      <span>Habitaciones: <strong>{selectedHouse.avgRooms}</strong></span>
                      <span>Antigüedad: <strong>{selectedHouse.avgHouseAge} años</strong></span>
                      <span>Superficie: <strong>{selectedHouse.squareFeet} sq ft</strong></span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => setSelectedHouse(null)}
                  className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition cursor-pointer"
                  title="Cerrar detalle"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        )}

        {/* PESTAÑA 2: GUÍA DIDÁCTICA PASO A PASO */}
        {activeTab === 'guided-learning' && (
          <div className="h-[650px]">
            <PedagogicalGuide
              onApplyPreset={handleApplyGuidePreset}
              currentHyperparams={hyperparams}
            />
          </div>
        )}

        {/* PESTAÑA 3: DESAFÍOS GAMIFICADOS Y RETOS DE OPTIMIZACIÓN */}
        {activeTab === 'challenges' && (
          <div className="h-[650px]">
            <SVMChallenges
              records={records}
              model={model2D}
              hyperparams={hyperparams}
              features={features2D}
              onTuneC={(newC) => setHyperparams((prev) => ({ ...prev, C: newC }))}
            />
          </div>
        )}

        {/* PESTAÑA 4: TASADOR Y CLASIFICADOR INMOBILIARIO */}
        {activeTab === 'predictor' && (
          <div className="h-[650px]">
            <HousePredictor
              model={model2D}
              hyperparams={hyperparams}
              onAddHouse={(house) => {
                handleAddCustomHouse(house);
                setActiveTab('simulator');
              }}
            />
          </div>
        )}

        {/* PESTAÑA 5: LABORATORIO DE FÓRMULAS MATEMÁTICAS Y LAGRANGIANOS */}
        {activeTab === 'math-lab' && (
          <div className="h-[650px]">
            <FormulaLab model={model2D} hyperparams={hyperparams} />
          </div>
        )}
      </main>

      {/* PIE DE PÁGINA PEDAGÓGICO */}
      <footer className="border-t border-slate-900 bg-slate-950 px-6 py-4 text-center text-xs text-slate-500 font-mono">
        <span>Simulador de Máquinas de Soporte Vectorial (SVM) · Dataset USA Housing · Implementación matemática en tiempo real</span>
      </footer>
    </div>
  );
}
