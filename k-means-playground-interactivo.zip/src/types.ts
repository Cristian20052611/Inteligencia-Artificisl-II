/**
 * Tipos e interfaces para el simulador interactivo de K-Means
 */

export type DistanceMetric = 'euclidean' | 'manhattan' | 'chebyshev';

export type InitMethod = 'kmeans_plus_plus' | 'random' | 'forgy' | 'manual' | 'adversarial';

export type AlgorithmStep = 'init' | 'assign' | 'update' | 'converged' | 'max_iter';

export type AppMode = 'sandbox' | 'comparison' | 'challenges' | 'theory';

export interface Point {
  id: string;
  x: number; // 0 to 1 normalized
  y: number; // 0 to 1 normalized
  cluster?: number; // Cluster index assigned (-1 or undefined if unassigned)
  distToCentroid?: number;
}

export interface Centroid {
  id: number;
  x: number;
  y: number;
  color: string;
  assignedCount: number;
  history: { x: number; y: number }[];
}

export interface KMeansHyperparameters {
  k: number;
  initMethod: InitMethod;
  distanceMetric: DistanceMetric;
  maxIterations: number;
  tolerance: number; // Convergence delta threshold (in normalized units)
}

export interface KMeansState {
  points: Point[];
  centroids: Centroid[];
  step: AlgorithmStep;
  iteration: number;
  isStepAssignNext: boolean; // true if next action is assign, false if update
  wcss: number; // Within-Cluster Sum of Squares (Inertia)
  silhouetteScore: number;
  hasConverged: boolean;
  maxCentroidDelta: number;
}

export interface DatasetPreset {
  id: string;
  name: string;
  description: string;
  recommendedK: number;
  iconName: string;
  generate: () => Point[];
}

export interface ElbowDataPoint {
  k: number;
  wcss: number;
  silhouette: number;
}

export interface Challenge {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  datasetName: string;
  dataset: Point[];
  k: number;
  goal: string;
  hint: string;
  type: 'manual_placement' | 'elbow_guess' | 'shape_trap';
  targetWcss?: number;
}
