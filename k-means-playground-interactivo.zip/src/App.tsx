import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  AppMode,
  Centroid,
  DistanceMetric,
  InitMethod,
  KMeansHyperparameters,
  KMeansState,
  Point,
} from './types';
import {
  calculateDistance,
  calculateSilhouetteScore,
  calculateWCSS,
  CLUSTER_COLORS,
  createPoint,
  DATASET_PRESETS,
  initializeCentroids,
  stepKMeans,
} from './utils/kmeans';
import { Header } from './components/Header';
import { KMeansCanvas } from './components/KMeansCanvas';
import { ControlPanel } from './components/ControlPanel';
import { ElbowModal } from './components/ElbowModal';
import { ComparisonView } from './components/ComparisonView';
import { ChallengeMode } from './components/ChallengeMode';
import { TheoryGuide } from './components/TheoryGuide';
import {
  Sparkles,
  Info,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  TrendingDown,
  MousePointerClick,
  Layers,
} from 'lucide-react';

export default function App() {
  // 1. Estado de Navegación
  const [appMode, setAppMode] = useState<AppMode>('sandbox');
  const [selectedPresetId, setSelectedPresetId] = useState<string>('three_blobs');
  const [isElbowOpen, setIsElbowOpen] = useState<boolean>(false);

  // 2. Hiperparámetros
  const [hyperparams, setHyperparams] = useState<KMeansHyperparameters>({
    k: 3,
    initMethod: 'kmeans_plus_plus',
    distanceMetric: 'euclidean',
    maxIterations: 50,
    tolerance: 0.001,
  });

  // 3. Puntos de Datos y Estado del Algoritmo
  const [points, setPoints] = useState<Point[]>(() => {
    const preset = DATASET_PRESETS.find((d) => d.id === 'three_blobs') || DATASET_PRESETS[0];
    return preset.generate();
  });

  const [manualCentroidPositions, setManualCentroidPositions] = useState<{ x: number; y: number }[]>([]);

  const [kMeansState, setKMeansState] = useState<KMeansState>(() => {
    const initialCentroids = initializeCentroids(
      points,
      hyperparams.k,
      hyperparams.initMethod,
      hyperparams.distanceMetric
    );
    return {
      points,
      centroids: initialCentroids,
      step: 'init',
      iteration: 0,
      isStepAssignNext: true,
      wcss: 0,
      silhouetteScore: 0,
      hasConverged: false,
      maxCentroidDelta: 1,
    };
  });

  // 4. Controles de Reproducción y Visualización
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [animationSpeed, setAnimationSpeed] = useState<number>(380); // ms
  const [showVoronoi, setShowVoronoi] = useState<boolean>(true);
  const [showTrails, setShowTrails] = useState<boolean>(true);
  const [showConnectors, setShowConnectors] = useState<boolean>(true);
  const [sprayMode, setSprayMode] = useState<boolean>(false);

  // Inicializar o re-inicializar centroides
  const resetAlgorithm = useCallback(
    (keepCentroidPositions = false) => {
      setIsRunning(false);

      let centroids: Centroid[];
      if (keepCentroidPositions && kMeansState.centroids.length > 0) {
        // Mantener posición inicial reseteando el historial
        centroids = kMeansState.centroids.map((c) => ({
          ...c,
          history: [c.history[0] || { x: c.x, y: c.y }],
          assignedCount: 0,
        }));
      } else {
        centroids = initializeCentroids(
          points,
          hyperparams.k,
          hyperparams.initMethod,
          hyperparams.distanceMetric,
          manualCentroidPositions
        );
      }

      setKMeansState({
        points: points.map((p) => ({ ...p, cluster: undefined })),
        centroids,
        step: 'init',
        iteration: 0,
        isStepAssignNext: true,
        wcss: 0,
        silhouetteScore: 0,
        hasConverged: false,
        maxCentroidDelta: 1,
      });
    },
    [points, hyperparams, manualCentroidPositions, kMeansState.centroids]
  );

  // Cambio de dataset preset
  const handleSelectPreset = (presetId: string) => {
    setSelectedPresetId(presetId);
    const preset = DATASET_PRESETS.find((d) => d.id === presetId);
    if (!preset) return;

    const newPoints = preset.generate();
    setPoints(newPoints);
    setHyperparams((prev) => ({ ...prev, k: preset.recommendedK }));

    const centroids = initializeCentroids(
      newPoints,
      preset.recommendedK,
      hyperparams.initMethod,
      hyperparams.distanceMetric
    );

    setKMeansState({
      points: newPoints,
      centroids,
      step: 'init',
      iteration: 0,
      isStepAssignNext: true,
      wcss: 0,
      silhouetteScore: 0,
      hasConverged: false,
      maxCentroidDelta: 1,
    });
    setIsRunning(false);
  };

  const handleRandomizeDataset = () => {
    handleSelectPreset(selectedPresetId);
  };

  // Reaccionar a cambios en hiperparámetros K, Init, Métrica
  const handleUpdateHyperparams = (newParams: Partial<KMeansHyperparameters>) => {
    setHyperparams((prev) => {
      const updated = { ...prev, ...newParams };
      return updated;
    });
  };

  // Cuando cambie K o el método de inicialización o métrica, reiniciar estado
  useEffect(() => {
    const centroids = initializeCentroids(
      points,
      hyperparams.k,
      hyperparams.initMethod,
      hyperparams.distanceMetric,
      manualCentroidPositions
    );

    setKMeansState({
      points: points.map((p) => ({ ...p, cluster: undefined })),
      centroids,
      step: 'init',
      iteration: 0,
      isStepAssignNext: true,
      wcss: 0,
      silhouetteScore: 0,
      hasConverged: false,
      maxCentroidDelta: 1,
    });
    setIsRunning(false);
  }, [hyperparams.k, hyperparams.initMethod, hyperparams.distanceMetric]);

  // Avanzar un paso
  const handleNextStep = useCallback(() => {
    setKMeansState((prevState) => {
      const next = stepKMeans(prevState, hyperparams);
      if (next.hasConverged) {
        setIsRunning(false);
      }
      return next;
    });
  }, [hyperparams]);

  // Loop de Reproducción Automática
  useEffect(() => {
    if (!isRunning) return;

    if (kMeansState.hasConverged || kMeansState.iteration >= hyperparams.maxIterations) {
      setIsRunning(false);
      return;
    }

    const timer = setTimeout(() => {
      handleNextStep();
    }, animationSpeed);

    return () => clearTimeout(timer);
  }, [isRunning, kMeansState, animationSpeed, hyperparams.maxIterations, handleNextStep]);

  // Atajos de Teclado (Espacio = Play/Pause, S = Siguiente Paso, R = Reset)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignorar si el usuario está en un input o select
      if (
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLSelectElement ||
        e.target instanceof HTMLTextAreaElement
      ) {
        return;
      }

      if (e.code === 'Space') {
        e.preventDefault();
        setIsRunning((prev) => !prev);
      } else if (e.code === 'KeyS') {
        e.preventDefault();
        if (!isRunning && !kMeansState.hasConverged) {
          handleNextStep();
        }
      } else if (e.code === 'KeyR') {
        e.preventDefault();
        resetAlgorithm(true);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isRunning, kMeansState.hasConverged, handleNextStep, resetAlgorithm]);

  // Agregar punto interactivo en el lienzo
  const handleAddPoint = (newCoord: { x: number; y: number }) => {
    const newPt = createPoint(newCoord.x, newCoord.y);
    setPoints((prev) => [...prev, newPt]);
    setKMeansState((prev) => ({
      ...prev,
      points: [...prev.points, newPt],
      hasConverged: false,
      step: 'init',
      isStepAssignNext: true,
    }));
  };

  // Mover centroide arrastrándolo en tiempo real
  const handleMoveCentroid = (id: number, pos: { x: number; y: number }) => {
    setKMeansState((prev) => {
      const updatedCentroids = prev.centroids.map((c) =>
        c.id === id ? { ...c, x: pos.x, y: pos.y } : c
      );

      // Re-asignar instantáneamente para retroalimentación en vivo
      let updatedPoints = prev.points;
      if (prev.step !== 'init') {
        updatedPoints = prev.points.map((p) => {
          let minDist = Infinity;
          let bestCluster = 0;
          for (let i = 0; i < updatedCentroids.length; i++) {
            const d = calculateDistance(p, updatedCentroids[i], hyperparams.distanceMetric);
            if (d < minDist) {
              minDist = d;
              bestCluster = i;
            }
          }
          return { ...p, cluster: bestCluster };
        });
      }

      const wcss = calculateWCSS(updatedPoints, updatedCentroids, hyperparams.distanceMetric);
      const silhouette = calculateSilhouetteScore(
        updatedPoints,
        updatedCentroids,
        hyperparams.distanceMetric
      );

      return {
        ...prev,
        centroids: updatedCentroids,
        points: updatedPoints,
        wcss,
        silhouetteScore: silhouette,
      };
    });
  };

  // Manejo de colocación manual de centroides
  const handleAddCentroidManual = (pos: { x: number; y: number }) => {
    if (kMeansState.centroids.length >= hyperparams.k) return;

    const newId = kMeansState.centroids.length;
    const newCentroid: Centroid = {
      id: newId,
      x: pos.x,
      y: pos.y,
      color: CLUSTER_COLORS[newId % CLUSTER_COLORS.length],
      assignedCount: 0,
      history: [{ x: pos.x, y: pos.y }],
    };

    setKMeansState((prev) => ({
      ...prev,
      centroids: [...prev.centroids, newCentroid],
    }));
  };

  const handleAddRandomPoints = (count: number) => {
    const newPts: Point[] = [];
    for (let i = 0; i < count; i++) {
      newPts.push(createPoint(0.05 + Math.random() * 0.9, 0.05 + Math.random() * 0.9));
    }
    const combined = [...points, ...newPts];
    setPoints(combined);
    setKMeansState((prev) => ({
      ...prev,
      points: [...prev.points, ...newPts],
      hasConverged: false,
      step: 'init',
      isStepAssignNext: true,
    }));
  };

  const handleClearPoints = () => {
    setPoints([]);
    setKMeansState({
      points: [],
      centroids: [],
      step: 'init',
      iteration: 0,
      isStepAssignNext: true,
      wcss: 0,
      silhouetteScore: 0,
      hasConverged: false,
      maxCentroidDelta: 0,
    });
    setIsRunning(false);
  };

  return (
    <div id="app-root" className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* Barra de Navegación Superior */}
      <Header
        currentMode={appMode}
        onSelectMode={setAppMode}
        selectedPresetId={selectedPresetId}
        onSelectPreset={handleSelectPreset}
        onRandomizeDataset={handleRandomizeDataset}
        pointCount={points.length}
      />

      {/* Contenido Principal */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 flex flex-col gap-6">
        {/* ================= MODO 1: EXPLORADOR SANDBOX ================= */}
        {appMode === 'sandbox' && (
          <div className="flex flex-col gap-6">
            {/* Banner de Estado Didáctico Paso a Paso */}
            <div
              id="step-status-banner"
              className={`flex items-center justify-between gap-3 rounded-2xl border px-4 py-3 text-xs backdrop-blur-md transition-all ${
                kMeansState.hasConverged
                  ? 'border-emerald-500/40 bg-emerald-950/40 text-emerald-200'
                  : kMeansState.step === 'init'
                  ? 'border-indigo-500/30 bg-indigo-950/40 text-indigo-200'
                  : kMeansState.isStepAssignNext
                  ? 'border-sky-500/30 bg-sky-950/40 text-sky-200'
                  : 'border-amber-500/30 bg-amber-950/40 text-amber-200'
              }`}
            >
              <div className="flex items-center gap-2.5">
                {kMeansState.hasConverged ? (
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                ) : (
                  <span className="flex h-2.5 w-2.5 rounded-full bg-indigo-400 animate-ping" />
                )}
                <span className="font-medium">
                  {kMeansState.hasConverged
                    ? `🎉 ¡Convergencia lograda en ${kMeansState.iteration} iteraciones! Los centroides se estabilizaron (Δ < ε).`
                    : kMeansState.step === 'init'
                    ? `Paso 0: Centroides posicionados usando [${hyperparams.initMethod}]. Presiona 'Auto-Ejecutar' o 'Paso' para comenzar.`
                    : kMeansState.isStepAssignNext
                    ? `Siguiente Fase: Asignar cada punto al centroide más cercano según distancia [${hyperparams.distanceMetric}].`
                    : `Siguiente Fase: Recalcular la media aritmética de cada clúster y desplazar los centroides.`}
                </span>
              </div>

              <div className="hidden sm:flex items-center gap-2 text-[11px] text-slate-400 font-mono">
                <span>Atajos: [Espacio] Play/Pausa · [S] Siguiente · [R] Reset</span>
              </div>
            </div>

            {/* Lienzo Principal Interactivo */}
            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span className="flex items-center gap-1.5">
                  <MousePointerClick className="h-3.5 w-3.5 text-indigo-400" />
                  <span>
                    Haz <strong>clic</strong> para añadir datos · Arrastra <strong>centroides</strong> para evaluar reasignación
                  </span>
                </span>
                <span className="font-mono text-[11px]">
                  K = {hyperparams.k} · {points.length} puntos · Métrica:{' '}
                  <strong className="text-indigo-300 capitalize">{hyperparams.distanceMetric}</strong>
                </span>
              </div>

              <KMeansCanvas
                points={kMeansState.points}
                centroids={kMeansState.centroids}
                metric={hyperparams.distanceMetric}
                showVoronoi={showVoronoi}
                showTrails={showTrails}
                showConnectors={showConnectors}
                isManualInitMode={
                  hyperparams.initMethod === 'manual' &&
                  kMeansState.centroids.length < hyperparams.k
                }
                manualPointsNeeded={hyperparams.k - kMeansState.centroids.length}
                onAddPoint={handleAddPoint}
                onAddCentroidManual={handleAddCentroidManual}
                onMoveCentroid={handleMoveCentroid}
                sprayMode={sprayMode}
                heightClass="h-[480px]"
              />
            </div>

            {/* Panel de Controles e Hiperparámetros */}
            <ControlPanel
              hyperparams={hyperparams}
              onUpdateHyperparams={handleUpdateHyperparams}
              state={kMeansState}
              isRunning={isRunning}
              onTogglePlay={() => setIsRunning(!isRunning)}
              onNextStep={handleNextStep}
              onReset={() => resetAlgorithm(true)}
              onReinitCentroids={() => resetAlgorithm(false)}
              onOpenElbowModal={() => setIsElbowOpen(true)}
              animationSpeed={animationSpeed}
              onChangeSpeed={setAnimationSpeed}
              showVoronoi={showVoronoi}
              onToggleVoronoi={() => setShowVoronoi(!showVoronoi)}
              showTrails={showTrails}
              onToggleTrails={() => setShowTrails(!showTrails)}
              showConnectors={showConnectors}
              onToggleConnectors={() => setShowConnectors(!showConnectors)}
              sprayMode={sprayMode}
              onToggleSprayMode={() => setSprayMode(!sprayMode)}
              onAddRandomPoints={handleAddRandomPoints}
              onClearPoints={handleClearPoints}
            />
          </div>
        )}

        {/* ================= MODO 2: COMPARADOR A/B ================= */}
        {appMode === 'comparison' && <ComparisonView basePoints={points} />}

        {/* ================= MODO 3: RETOS LÚDICOS ================= */}
        {appMode === 'challenges' && <ChallengeMode />}

        {/* ================= MODO 4: GUÍA TEÓRICA ================= */}
        {appMode === 'theory' && <TheoryGuide />}
      </main>

      {/* Modal Interactivo del Método del Codo */}
      <ElbowModal
        isOpen={isElbowOpen}
        onClose={() => setIsElbowOpen(false)}
        points={points}
        currentK={hyperparams.k}
        onSelectK={(newK) => {
          handleUpdateHyperparams({ k: newK });
        }}
      />
    </div>
  );
}
