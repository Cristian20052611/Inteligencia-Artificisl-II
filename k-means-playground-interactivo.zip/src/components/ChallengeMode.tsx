import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import {
  Trophy,
  Award,
  Sparkles,
  HelpCircle,
  CheckCircle,
  RotateCcw,
  Zap,
  Target,
  Brain,
} from 'lucide-react';
import { Centroid, Point } from '../types';
import {
  calculateWCSS,
  CLUSTER_COLORS,
  createPoint,
  runKMeansToConvergence,
} from '../utils/kmeans';
import { KMeansCanvas } from './KMeansCanvas';

export const ChallengeMode: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'intuition' | 'elbow_quiz' | 'concentric_trap'>(
    'intuition'
  );

  /* ================= Reto 1: Intuición Humana vs K-Means ================= */
  const [intuitionPoints] = useState<Point[]>(() => {
    const pts: Point[] = [];
    const centers = [
      { x: 0.28, y: 0.32, count: 45 },
      { x: 0.72, y: 0.35, count: 50 },
      { x: 0.5, y: 0.75, count: 55 },
    ];
    centers.forEach((c) => {
      for (let i = 0; i < c.count; i++) {
        pts.push(
          createPoint(
            c.x + (Math.random() - 0.5) * 0.14,
            c.y + (Math.random() - 0.5) * 0.14
          )
        );
      }
    });
    return pts;
  });

  const [humanCentroids, setHumanCentroids] = useState<{ x: number; y: number }[]>([]);
  const [humanResult, setHumanResult] = useState<{
    humanWcss: number;
    aiWcss: number;
    won: boolean;
    ratio: number;
  } | null>(null);

  const handleAddHumanCentroid = (pos: { x: number; y: number }) => {
    if (humanCentroids.length >= 3) return;
    setHumanCentroids((prev) => [...prev, pos]);
  };

  const evaluateHumanVsAI = () => {
    if (humanCentroids.length < 3) return;

    // Calcular WCSS de la intuición humana
    const humanCentroidObjs: Centroid[] = humanCentroids.map((c, i) => ({
      id: i,
      x: c.x,
      y: c.y,
      color: CLUSTER_COLORS[i],
      assignedCount: 0,
      history: [{ x: c.x, y: c.y }],
    }));

    // Asignar puntos al más cercano
    const assignedPoints = intuitionPoints.map((p) => {
      let minDist = Infinity;
      let cluster = 0;
      humanCentroidObjs.forEach((c, i) => {
        const d = Math.sqrt((p.x - c.x) ** 2 + (p.y - c.y) ** 2);
        if (d < minDist) {
          minDist = d;
          cluster = i;
        }
      });
      return { ...p, cluster };
    });

    const humanWcss = calculateWCSS(assignedPoints, humanCentroidObjs, 'euclidean');

    // Referencia K-Means++ óptimo
    const aiResult = runKMeansToConvergence(intuitionPoints, {
      k: 3,
      initMethod: 'kmeans_plus_plus',
      distanceMetric: 'euclidean',
      maxIterations: 40,
      tolerance: 0.001,
    });

    const aiWcss = aiResult.wcss;
    const ratio = Number(((humanWcss / aiWcss) * 100).toFixed(1));
    const won = humanWcss <= aiWcss * 1.12; // A menos de 12% del óptimo algorítmico

    setHumanResult({ humanWcss, aiWcss, won, ratio });

    if (won) {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });
    }
  };

  const resetHumanGame = () => {
    setHumanCentroids([]);
    setHumanResult(null);
  };

  /* ================= Reto 2: Detective del Codo ================= */
  const [secretK, setSecretK] = useState<number>(() => Math.floor(Math.random() * 3) + 3); // 3, 4, o 5
  const [quizPoints, setQuizPoints] = useState<Point[]>(() => generateSecretDataset(secretK));
  const [guessedK, setGuessedK] = useState<number | null>(null);
  const [quizSolved, setQuizSolved] = useState<boolean | null>(null);

  function generateSecretDataset(kVal: number): Point[] {
    const pts: Point[] = [];
    const angleStep = (Math.PI * 2) / kVal;
    for (let i = 0; i < kVal; i++) {
      const cx = 0.5 + 0.28 * Math.cos(i * angleStep + 0.3);
      const cy = 0.5 + 0.28 * Math.sin(i * angleStep + 0.3);
      const count = 35 + Math.floor(Math.random() * 20);
      for (let j = 0; j < count; j++) {
        pts.push(
          createPoint(
            cx + (Math.random() - 0.5) * 0.12,
            cy + (Math.random() - 0.5) * 0.12
          )
        );
      }
    }
    return pts;
  }

  const handleGuessK = (val: number) => {
    setGuessedK(val);
    const correct = val === secretK;
    setQuizSolved(correct);

    if (correct) {
      confetti({
        particleCount: 100,
        spread: 80,
        origin: { y: 0.6 },
      });
    }
  };

  const resetQuiz = () => {
    const newK = Math.floor(Math.random() * 3) + 3;
    setSecretK(newK);
    setQuizPoints(generateSecretDataset(newK));
    setGuessedK(null);
    setQuizSolved(null);
  };

  return (
    <div id="challenge-mode-root" className="flex flex-col gap-6">
      {/* Selector de Retos */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400">
            <Trophy className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white">Desafíos Lúdicos de K-Means</h2>
            <p className="text-xs text-slate-400">
              Pon a prueba tu intuición y descubre los límites y secretos del aprendizaje no supervisado.
            </p>
          </div>
        </div>

        <div className="flex rounded-xl bg-slate-900 border border-slate-800 p-1 text-xs">
          <button
            onClick={() => setActiveTab('intuition')}
            className={`rounded-lg px-3 py-1.5 font-medium transition ${
              activeTab === 'intuition'
                ? 'bg-indigo-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            🎯 Reto 1: Humano vs IA
          </button>
          <button
            onClick={() => setActiveTab('elbow_quiz')}
            className={`rounded-lg px-3 py-1.5 font-medium transition ${
              activeTab === 'elbow_quiz'
                ? 'bg-indigo-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            🕵️ Reto 2: Detective del Codo
          </button>
          <button
            onClick={() => setActiveTab('concentric_trap')}
            className={`rounded-lg px-3 py-1.5 font-medium transition ${
              activeTab === 'concentric_trap'
                ? 'bg-indigo-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            🌀 Reto 3: La Gran Trampa
          </button>
        </div>
      </div>

      {/* Reto 1: Humano vs IA */}
      {activeTab === 'intuition' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-300">
                Lienzo de Desafío (Coloca 3 centroides haciendo clic)
              </span>
              <span className="text-xs font-mono text-amber-300">
                Centroides colocados: {humanCentroids.length} / 3
              </span>
            </div>

            <KMeansCanvas
              points={intuitionPoints}
              centroids={humanCentroids.map((c, i) => ({
                id: i,
                x: c.x,
                y: c.y,
                color: CLUSTER_COLORS[i],
                assignedCount: 0,
                history: [{ x: c.x, y: c.y }],
              }))}
              metric="euclidean"
              isManualInitMode={humanCentroids.length < 3}
              manualPointsNeeded={3 - humanCentroids.length}
              onAddCentroidManual={handleAddHumanCentroid}
              heightClass="h-[400px]"
              showVoronoi={true}
            />
          </div>

          <div className="flex flex-col gap-4 rounded-2xl border border-slate-800 bg-slate-900/80 p-5">
            <div className="flex items-center gap-2">
              <Brain className="h-5 w-5 text-indigo-400" />
              <h3 className="font-bold text-sm text-white">Humano vs K-Means++</h3>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              El ojo humano es excepcionalmente bueno detectando patrones en 2D. Ubica los 3
              centroides donde creas que minimizan la dispersión total de los puntos.
            </p>

            <div className="flex flex-col gap-2 pt-2">
              <button
                onClick={evaluateHumanVsAI}
                disabled={humanCentroids.length < 3}
                className="w-full flex items-center justify-center gap-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 py-2.5 text-xs font-bold text-white shadow-lg disabled:opacity-40 disabled:cursor-not-allowed transition"
              >
                <Zap className="h-4 w-4" />
                <span>Evaluar mi Intuición</span>
              </button>

              <button
                onClick={resetHumanGame}
                className="w-full flex items-center justify-center gap-1.5 rounded-xl border border-slate-700 bg-slate-800 py-2 text-xs text-slate-300 hover:bg-slate-750 transition"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                <span>Volver a Intentar</span>
              </button>
            </div>

            {/* Resultado */}
            {humanResult && (
              <div
                className={`mt-3 rounded-xl p-4 border text-xs flex flex-col gap-2 ${
                  humanResult.won
                    ? 'border-emerald-500/40 bg-emerald-950/40 text-emerald-200'
                    : 'border-amber-500/40 bg-amber-950/40 text-amber-200'
                }`}
              >
                <div className="flex items-center gap-2 font-bold text-sm">
                  {humanResult.won ? (
                    <>
                      <Award className="h-5 w-5 text-emerald-400" />
                      <span>¡Excelente intuición geométrica!</span>
                    </>
                  ) : (
                    <>
                      <HelpCircle className="h-5 w-5 text-amber-400" />
                      <span>K-Means++ optimizó mejor la dispersión</span>
                    </>
                  )}
                </div>

                <div className="space-y-1 font-mono text-[11px] pt-1">
                  <div>Tu Inercia (WCSS): <strong>{humanResult.humanWcss.toFixed(2)}</strong></div>
                  <div>Inercia K-Means++: <strong>{humanResult.aiWcss.toFixed(2)}</strong></div>
                  <div>Eficiencia respecto a IA: <strong>{humanResult.ratio}%</strong></div>
                </div>

                <p className="text-[11px] text-slate-400 pt-1">
                  {humanResult.won
                    ? 'Lograste posicionar los centros dentro del rango óptimo global.'
                    : 'K-Means calcula la media aritmética exacta de cada cluster, logrando el mínimo matemático local.'}
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Reto 2: Detective del Codo */}
      {activeTab === 'elbow_quiz' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-300">
                Dataset Misterioso (Sin etiquetas de supervisión)
              </span>
              <span className="text-xs text-slate-400 font-mono">
                {quizPoints.length} puntos no supervisados
              </span>
            </div>

            <KMeansCanvas
              points={
                quizSolved
                  ? runKMeansToConvergence(quizPoints, {
                      k: secretK,
                      initMethod: 'kmeans_plus_plus',
                      distanceMetric: 'euclidean',
                      maxIterations: 40,
                      tolerance: 0.001,
                    }).points
                  : quizPoints.map((p) => ({ ...p, cluster: undefined }))
              }
              centroids={
                quizSolved
                  ? runKMeansToConvergence(quizPoints, {
                      k: secretK,
                      initMethod: 'kmeans_plus_plus',
                      distanceMetric: 'euclidean',
                      maxIterations: 40,
                      tolerance: 0.001,
                    }).centroids
                  : []
              }
              metric="euclidean"
              heightClass="h-[400px]"
              showVoronoi={quizSolved === true}
            />
          </div>

          <div className="flex flex-col gap-4 rounded-2xl border border-slate-800 bg-slate-900/80 p-5">
            <div className="flex items-center gap-2">
              <Target className="h-5 w-5 text-indigo-400" />
              <h3 className="font-bold text-sm text-white">¿Cuántos Clústeres Reales Hay?</h3>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              En Machine Learning no supervisado no tenemos etiquetas. Observa la distribución de los
              puntos e intenta descifrar el verdadero valor intrínseco de <strong className="text-white">K</strong>.
            </p>

            <div className="flex flex-col gap-2 pt-2">
              <label className="text-xs text-slate-300 font-medium">Elige tu predicción:</label>
              <div className="grid grid-cols-4 gap-2">
                {[2, 3, 4, 5].map((kVal) => (
                  <button
                    key={kVal}
                    onClick={() => handleGuessK(kVal)}
                    disabled={quizSolved === true}
                    className={`rounded-xl py-3 text-sm font-mono font-bold transition border ${
                      guessedK === kVal
                        ? quizSolved
                          ? 'border-emerald-500 bg-emerald-600 text-white'
                          : 'border-rose-500 bg-rose-600 text-white'
                        : 'border-slate-700 bg-slate-800 text-slate-200 hover:bg-slate-750'
                    }`}
                  >
                    K = {kVal}
                  </button>
                ))}
              </div>

              {quizSolved !== null && (
                <div
                  className={`mt-3 p-3 rounded-xl border text-xs flex flex-col gap-1 ${
                    quizSolved
                      ? 'border-emerald-500/40 bg-emerald-950/40 text-emerald-200'
                      : 'border-rose-500/40 bg-rose-950/40 text-rose-200'
                  }`}
                >
                  <span className="font-bold">
                    {quizSolved
                      ? `🎉 ¡Exacto! Había K = ${secretK} clústeres reales.`
                      : `❌ No es K = ${guessedK}. Intenta con otro valor.`}
                  </span>
                  {quizSolved && (
                    <span className="text-[11px] text-slate-400">
                      ¡Fíjate cómo el lienzo acaba de colorear las regiones de Voronoi perfectas!
                    </span>
                  )}
                </div>
              )}

              <button
                onClick={resetQuiz}
                className="mt-3 flex items-center justify-center gap-1.5 rounded-xl border border-slate-700 bg-slate-800 py-2 text-xs text-slate-300 hover:bg-slate-750 transition"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                <span>Generar Otro Dataset Secreto</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reto 3: La Gran Trampa */}
      {activeTab === 'concentric_trap' && (
        <div className="flex flex-col gap-4 rounded-3xl border border-rose-900/40 bg-slate-900/90 p-6">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400">
              <Target className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                El Talón de Aquiles de K-Means: Geometría Convexa
              </h3>
              <p className="text-xs text-slate-400">
                ¿Por qué K-Means no puede separar anillos concéntricos o formas arbitrarias?
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
            <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
              <p>
                K-Means asume implícitamente que los clústeres son <strong className="text-white">esféricos (convexos)</strong> y de dispersión similar.
              </p>
              <div className="rounded-xl bg-slate-950 p-3 border border-slate-800 space-y-2">
                <div className="text-amber-300 font-semibold flex items-center gap-1.5">
                  <Sparkles className="h-4 w-4" /> La Trampa Matemática:
                </div>
                <p className="text-slate-400">
                  Como la distancia se mide en línea recta al centroide, las regiones de decisión son{' '}
                  <strong className="text-slate-200">polígonos de Voronoi con límites rectos</strong>. Un polígono recto nunca puede rodear o envolver a otro.
                </p>
              </div>
              <p className="text-slate-400">
                Para estructuras en anillo o curvas densas, los científicos de datos usan algoritmos basados en densidad como <strong className="text-cyan-300">DBSCAN</strong> o proyecciones espectrales (<strong className="text-indigo-300">Spectral Clustering</strong>).
              </p>
            </div>

            <div className="rounded-2xl border border-slate-800 bg-slate-950 p-3">
              <span className="text-[11px] text-slate-400 block mb-2 font-medium">
                Demostración con K=2 en Anillos Concéntricos:
              </span>
              <KMeansCanvas
                points={runKMeansToConvergence(
                  (() => {
                    const pts: Point[] = [];
                    for (let i = 0; i < 40; i++) {
                      const r = Math.random() * 0.1;
                      const th = Math.random() * Math.PI * 2;
                      pts.push(createPoint(0.5 + r * Math.cos(th), 0.5 + r * Math.sin(th)));
                    }
                    for (let i = 0; i < 90; i++) {
                      const r = 0.28 + (Math.random() - 0.5) * 0.04;
                      const th = Math.random() * Math.PI * 2;
                      pts.push(createPoint(0.5 + r * Math.cos(th), 0.5 + r * Math.sin(th)));
                    }
                    return pts;
                  })(),
                  {
                    k: 2,
                    initMethod: 'kmeans_plus_plus',
                    distanceMetric: 'euclidean',
                    maxIterations: 30,
                    tolerance: 0.001,
                  }
                ).points}
                centroids={runKMeansToConvergence(
                  (() => {
                    const pts: Point[] = [];
                    for (let i = 0; i < 40; i++) {
                      const r = Math.random() * 0.1;
                      const th = Math.random() * Math.PI * 2;
                      pts.push(createPoint(0.5 + r * Math.cos(th), 0.5 + r * Math.sin(th)));
                    }
                    for (let i = 0; i < 90; i++) {
                      const r = 0.28 + (Math.random() - 0.5) * 0.04;
                      const th = Math.random() * Math.PI * 2;
                      pts.push(createPoint(0.5 + r * Math.cos(th), 0.5 + r * Math.sin(th)));
                    }
                    return pts;
                  })(),
                  {
                    k: 2,
                    initMethod: 'kmeans_plus_plus',
                    distanceMetric: 'euclidean',
                    maxIterations: 30,
                    tolerance: 0.001,
                  }
                ).centroids}
                metric="euclidean"
                heightClass="h-[260px]"
                showVoronoi={true}
              />
              <span className="text-[10px] text-rose-300 block mt-2 text-center">
                ⚠️ Observa cómo parte el círculo en 2 mitades (izquierda/derecha) en vez de (interior/exterior)
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
