import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Centroid, DistanceMetric, Point } from '../types';
import { calculateDistance, CLUSTER_COLORS } from '../utils/kmeans';

interface KMeansCanvasProps {
  points: Point[];
  centroids: Centroid[];
  metric: DistanceMetric;
  showVoronoi?: boolean;
  showTrails?: boolean;
  showConnectors?: boolean;
  isManualInitMode?: boolean;
  manualPointsNeeded?: number;
  onAddPoint?: (point: { x: number; y: number }) => void;
  onAddCentroidManual?: (pos: { x: number; y: number }) => void;
  onMoveCentroid?: (id: number, pos: { x: number; y: number }) => void;
  sprayMode?: boolean;
  heightClass?: string;
}

export const KMeansCanvas: React.FC<KMeansCanvasProps> = ({
  points,
  centroids,
  metric,
  showVoronoi = true,
  showTrails = true,
  showConnectors = true,
  isManualInitMode = false,
  manualPointsNeeded = 0,
  onAddPoint,
  onAddCentroidManual,
  onMoveCentroid,
  sprayMode = false,
  heightClass = 'h-[500px]',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [dimensions, setDimensions] = useState({ width: 600, height: 500 });
  const [draggedCentroidId, setDraggedCentroidId] = useState<number | null>(null);
  const [isMouseDown, setIsMouseDown] = useState(false);
  const lastSprayTime = useRef<number>(0);

  // ResizeObserver para alta resolución y responsive sizing
  useEffect(() => {
    if (!containerRef.current) return;
    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect;
        if (width > 0 && height > 0) {
          setDimensions({ width: Math.floor(width), height: Math.floor(height) });
        }
      }
    });

    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);

  // Conversión de coordenadas
  const toCanvasCoords = useCallback(
    (normX: number, normY: number) => {
      return {
        x: normX * dimensions.width,
        y: normY * dimensions.height,
      };
    },
    [dimensions]
  );

  const toNormalizedCoords = useCallback(
    (clientX: number, clientY: number) => {
      if (!canvasRef.current) return { x: 0.5, y: 0.5 };
      const rect = canvasRef.current.getBoundingClientRect();
      const x = Math.max(0.02, Math.min(0.98, (clientX - rect.left) / rect.width));
      const y = Math.max(0.02, Math.min(0.98, (clientY - rect.top) / rect.height));
      return { x, y };
    },
    []
  );

  // Render Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    canvas.width = dimensions.width * dpr;
    canvas.height = dimensions.height * dpr;
    ctx.scale(dpr, dpr);

    const { width, height } = dimensions;

    // 1. Fondo oscuro tecnológico refinado
    ctx.fillStyle = '#090d16';
    ctx.fillRect(0, 0, width, height);

    // Cuadrícula sutil
    ctx.strokeStyle = '#151c2e';
    ctx.lineWidth = 1;
    const gridSize = 40;
    for (let x = gridSize; x < width; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    for (let y = gridSize; y < height; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    // 2. Regiones de Voronoi (Tessellation coloreada según métrica de distancia)
    if (showVoronoi && centroids.length > 0) {
      const step = 6; // Grid resolution optimizada para 60fps
      const cols = Math.ceil(width / step);
      const rows = Math.ceil(height / step);

      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          const sampleX = (c * step + step / 2) / width;
          const sampleY = (r * step + step / 2) / height;

          let minDist = Infinity;
          let nearestCluster = 0;

          for (let i = 0; i < centroids.length; i++) {
            const d = calculateDistance({ x: sampleX, y: sampleY }, centroids[i], metric);
            if (d < minDist) {
              minDist = d;
              nearestCluster = i;
            }
          }

          const baseColor = CLUSTER_COLORS[nearestCluster % CLUSTER_COLORS.length];
          // Hex a RGBA suave
          ctx.fillStyle = `${baseColor}16`; // ~9% de opacidad suave
          ctx.fillRect(c * step, r * step, step, step);
        }
      }
    }

    // 3. Líneas de conexión tenue entre puntos y sus centroides asignados
    if (showConnectors && centroids.length > 0) {
      ctx.lineWidth = 0.8;
      for (const p of points) {
        if (p.cluster !== undefined && centroids[p.cluster]) {
          const centroid = centroids[p.cluster];
          const ptCanvas = toCanvasCoords(p.x, p.y);
          const centCanvas = toCanvasCoords(centroid.x, centroid.y);

          ctx.strokeStyle = `${centroid.color}28`; // ~15% opacidad
          ctx.beginPath();
          ctx.moveTo(ptCanvas.x, ptCanvas.y);
          ctx.lineTo(centCanvas.x, centCanvas.y);
          ctx.stroke();
        }
      }
    }

    // 4. Trayectorias históricas de los centroides (Centroid Trails)
    if (showTrails && centroids.length > 0) {
      for (const c of centroids) {
        if (c.history.length > 1) {
          ctx.lineWidth = 2.5;
          ctx.strokeStyle = c.color;
          ctx.setLineDash([4, 4]);

          ctx.beginPath();
          const start = toCanvasCoords(c.history[0].x, c.history[0].y);
          ctx.moveTo(start.x, start.y);

          for (let h = 1; h < c.history.length; h++) {
            const next = toCanvasCoords(c.history[h].x, c.history[h].y);
            ctx.lineTo(next.x, next.y);
          }
          ctx.stroke();
          ctx.setLineDash([]); // Reset dash

          // Pequeñas marcas de paso
          for (let h = 0; h < c.history.length - 1; h++) {
            const mark = toCanvasCoords(c.history[h].x, c.history[h].y);
            ctx.fillStyle = c.color;
            ctx.beginPath();
            ctx.arc(mark.x, mark.y, 2.5, 0, Math.PI * 2);
            ctx.fill();
          }
        }
      }
    }

    // 5. Puntos de datos
    for (const p of points) {
      const { x, y } = toCanvasCoords(p.x, p.y);
      const isAssigned = p.cluster !== undefined && p.cluster >= 0;
      const color = isAssigned && centroids[p.cluster!]
        ? centroids[p.cluster!].color
        : '#94a3b8'; // Gris pizarra si está sin asignar

      // Halo sutil
      ctx.fillStyle = `${color}30`;
      ctx.beginPath();
      ctx.arc(x, y, 6, 0, Math.PI * 2);
      ctx.fill();

      // Punto central
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.arc(x, y, 3.5, 0, Math.PI * 2);
      ctx.fill();

      // Borde claro
      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 1;
      ctx.stroke();
    }

    // 6. Centroides (Iconos distintivos de diamante/estrella con pulso)
    for (const c of centroids) {
      const { x, y } = toCanvasCoords(c.x, c.y);

      // Halo exterior brillante
      const gradient = ctx.createRadialGradient(x, y, 6, x, y, 22);
      gradient.addColorStop(0, `${c.color}66`);
      gradient.addColorStop(1, `${c.color}00`);
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(x, y, 22, 0, Math.PI * 2);
      ctx.fill();

      // Anillo blanco de foco
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(x, y, 11, 0, Math.PI * 2);
      ctx.stroke();

      // Centroide central coloreado
      ctx.fillStyle = c.color;
      ctx.beginPath();
      ctx.arc(x, y, 8.5, 0, Math.PI * 2);
      ctx.fill();

      // Cruz / Estrella en el centro del centroide
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(x - 4, y);
      ctx.lineTo(x + 4, y);
      ctx.moveTo(x, y - 4);
      ctx.lineTo(x, y + 4);
      ctx.stroke();

      // Etiqueta del centroide
      ctx.font = 'bold 11px "JetBrains Mono", monospace';
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'bottom';
      ctx.shadowColor = '#000000';
      ctx.shadowBlur = 4;
      ctx.fillText(`C${c.id + 1}`, x, y - 14);
      ctx.shadowBlur = 0; // Reset
    }
  }, [
    dimensions,
    points,
    centroids,
    metric,
    showVoronoi,
    showTrails,
    showConnectors,
    toCanvasCoords,
  ]);

  // Manejo de Interacción del Ratón
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const coords = toNormalizedCoords(e.clientX, e.clientY);
    setIsMouseDown(true);

    // Modo inicialización manual de centroides
    if (isManualInitMode && onAddCentroidManual && manualPointsNeeded > 0) {
      onAddCentroidManual(coords);
      return;
    }

    // Verificar si se hizo clic cerca de un centroide existente para arrastrarlo
    const hitRadiusNorm = 24 / dimensions.width;
    for (const c of centroids) {
      const d = Math.sqrt((c.x - coords.x) ** 2 + (c.y - coords.y) ** 2);
      if (d < hitRadiusNorm) {
        setDraggedCentroidId(c.id);
        return;
      }
    }

    // Si está en modo spray o dibujo
    if (sprayMode && onAddPoint) {
      sprayPoints(coords.x, coords.y);
    } else if (onAddPoint) {
      onAddPoint(coords);
    }
  };

  const sprayPoints = (centerX: number, centerY: number) => {
    if (!onAddPoint) return;
    const count = 4;
    for (let i = 0; i < count; i++) {
      const r = Math.random() * 0.04;
      const theta = Math.random() * Math.PI * 2;
      onAddPoint({
        x: Math.max(0.02, Math.min(0.98, centerX + r * Math.cos(theta))),
        y: Math.max(0.02, Math.min(0.98, centerY + r * Math.sin(theta))),
      });
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const coords = toNormalizedCoords(e.clientX, e.clientY);

    // Si arrastra un centroide
    if (draggedCentroidId !== null && onMoveCentroid) {
      onMoveCentroid(draggedCentroidId, coords);
      return;
    }

    // Spray continuo al mover el ratón con el botón apretado
    if (isMouseDown && sprayMode && onAddPoint) {
      const now = Date.now();
      if (now - lastSprayTime.current > 40) {
        sprayPoints(coords.x, coords.y);
        lastSprayTime.current = now;
      }
    }
  };

  const handleMouseUp = () => {
    setIsMouseDown(false);
    setDraggedCentroidId(null);
  };

  return (
    <div
      ref={containerRef}
      id="kmeans-canvas-container"
      className={`relative w-full ${heightClass} overflow-hidden rounded-2xl border border-slate-800/80 bg-slate-950 shadow-2xl select-none`}
    >
      <canvas
        ref={canvasRef}
        id="kmeans-interactive-canvas"
        className={`w-full h-full block ${
          draggedCentroidId !== null
            ? 'cursor-grabbing'
            : isManualInitMode
            ? 'cursor-crosshair'
            : sprayMode
            ? 'cursor-crosshair'
            : 'cursor-pointer'
        }`}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      />

      {/* Overlay de instrucciones según el modo */}
      {isManualInitMode && manualPointsNeeded > 0 && (
        <div
          id="manual-init-overlay"
          className="absolute top-4 left-4 z-10 flex items-center gap-2.5 rounded-xl border border-amber-500/40 bg-amber-950/80 px-3.5 py-2 text-xs font-medium text-amber-200 backdrop-blur-md shadow-lg animate-pulse"
        >
          <span className="flex h-2.5 w-2.5 rounded-full bg-amber-400" />
          Haz clic en el lienzo para colocar el centroide #{centroids.length + 1} (Faltan {manualPointsNeeded})
        </div>
      )}

      {/* Indicador de arrastre */}
      <div
        id="canvas-hint"
        className="absolute bottom-3 right-4 z-10 pointer-events-none flex items-center gap-2 rounded-lg bg-slate-900/75 px-2.5 py-1 text-[11px] text-slate-400 backdrop-blur-sm border border-slate-800/60"
      >
        <span>💡 Arrastra centroides para ver la reasignación en vivo</span>
      </div>
    </div>
  );
};
