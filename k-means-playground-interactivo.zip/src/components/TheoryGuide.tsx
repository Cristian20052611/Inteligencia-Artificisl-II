import React from 'react';
import {
  BookOpen,
  GitBranch,
  Layers,
  Sparkles,
  Zap,
  CheckCircle,
  AlertTriangle,
  Compass,
} from 'lucide-react';

export const TheoryGuide: React.FC = () => {
  return (
    <div id="theory-guide-root" className="flex flex-col gap-6 max-w-5xl mx-auto">
      {/* Cabecera */}
      <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
        <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-indigo-500/10 border border-indigo-500/30 text-indigo-400">
          <BookOpen className="h-5 w-5" />
        </div>
        <div>
          <h2 className="text-base font-bold text-white">
            Guía Teórica Interactiva: Algoritmo K-Means
          </h2>
          <p className="text-xs text-slate-400">
            Fundamentos matemáticos, hiperparámetros y mejores prácticas explicados sin tecnicismos innecesarios.
          </p>
        </div>
      </div>

      {/* Grid de 2 Columnas de Conceptos Principales */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* 1. ¿Qué es el Aprendizaje No Supervisado? */}
        <div className="flex flex-col gap-3 rounded-2xl border border-slate-800 bg-slate-900/80 p-5">
          <div className="flex items-center gap-2 text-sm font-bold text-indigo-300">
            <Compass className="h-4 w-4 text-indigo-400" />
            <span>1. Aprendizaje No Supervisado (Clustering)</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            A diferencia de la clasificación o regresión (supervisadas), aquí{' '}
            <strong className="text-white">no disponemos de etiquetas o respuestas correctas previas</strong>.
            El algoritmo debe descubrir la estructura oculta y los grupos naturales en los datos basándose
            únicamente en su similitud geométrica.
          </p>
          <div className="rounded-xl bg-slate-950 p-3 border border-slate-800 text-[11px] text-slate-400">
            💡 <strong className="text-slate-200">Objetivo Matemático:</strong> Minimizar la inercia intra-cluster
            (WCSS), agrupando puntos cercanos entre sí y separando los grupos distintos.
          </div>
        </div>

        {/* 2. El Ciclo de Lloyd (Las 2 Fases) */}
        <div className="flex flex-col gap-3 rounded-2xl border border-slate-800 bg-slate-900/80 p-5">
          <div className="flex items-center gap-2 text-sm font-bold text-emerald-300">
            <GitBranch className="h-4 w-4 text-emerald-400" />
            <span>2. El Ciclo de Lloyd: Alternancia Paso a Paso</span>
          </div>
          <div className="space-y-2 text-xs text-slate-300">
            <div className="flex items-start gap-2">
              <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-indigo-900/80 text-[10px] font-bold text-indigo-300">
                1
              </span>
              <div>
                <strong className="text-white">Paso de Asignación:</strong> Cada dato se asigna al
                centroide más próximo según la distancia seleccionada.
              </div>
            </div>
            <div className="flex items-start gap-2">
              <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-emerald-900/80 text-[10px] font-bold text-emerald-300">
                2
              </span>
              <div>
                <strong className="text-white">Paso de Actualización:</strong> Cada centroide se mueve a
                la posición media (<span className="font-mono text-indigo-300">centro de gravedad</span>)
                de todos los puntos que le fueron asignados.
              </div>
            </div>
          </div>
          <p className="text-[11px] text-slate-400">
            Se repiten estos dos pasos hasta que ningún centroide se mueva más de la tolerancia{' '}
            <span className="font-mono text-slate-300">ε</span>.
          </p>
        </div>
      </div>

      {/* Tabla Comparativa de Hiperparámetros */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 shadow-xl">
        <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
          <Layers className="h-4 w-4 text-indigo-400" />
          <span>Comparativa Detallada de Hiperparámetros</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="py-2.5 px-3 font-semibold">Hiperparámetro</th>
                <th className="py-2.5 px-3 font-semibold">Opciones Principales</th>
                <th className="py-2.5 px-3 font-semibold">Impacto en los Resultados</th>
                <th className="py-2.5 px-3 font-semibold">Recomendación</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              <tr>
                <td className="py-3 px-3 font-bold text-white font-mono">K (Clusters)</td>
                <td className="py-3 px-3">Entero (k ≥ 1)</td>
                <td className="py-3 px-3">
                  Muy bajo = subajuste (mezcla grupos). Muy alto = sobreajuste (fragmenta grupos reales).
                </td>
                <td className="py-3 px-3 text-indigo-400">
                  Usar el <strong className="text-indigo-300">Método del Codo</strong> y Coeficiente de Silueta.
                </td>
              </tr>
              <tr>
                <td className="py-3 px-3 font-bold text-white font-mono">Inicialización</td>
                <td className="py-3 px-3">K-Means++, Random, Forgy</td>
                <td className="py-3 px-3">
                  Random puede quedar atrapado en mínimos locales pésimos. K-Means++ dispersa los centroides iniciales.
                </td>
                <td className="py-3 px-3 text-emerald-400">
                  Siempre preferir <strong className="text-emerald-300">K-Means++</strong>.
                </td>
              </tr>
              <tr>
                <td className="py-3 px-3 font-bold text-white font-mono">Métrica de Distancia</td>
                <td className="py-3 px-3">Euclidiana (L2), Manhattan (L1), Chebyshev (L∞)</td>
                <td className="py-3 px-3">
                  Modifica la geometría de las fronteras de Voronoi (redondas vs rombos vs cuadrados).
                </td>
                <td className="py-3 px-3 text-slate-300">
                  Euclidiana para datos continuos estándar; Manhattan si hay coordenadas en rejilla o variables robustas a outliers.
                </td>
              </tr>
              <tr>
                <td className="py-3 px-3 font-bold text-white font-mono">Tolerancia ε y Max Iter</td>
                <td className="py-3 px-3">0.001..0.01 / 20..300</td>
                <td className="py-3 px-3">
                  Controla cuándo se declara la convergencia para detener el cálculo.
                </td>
                <td className="py-3 px-3 text-slate-400">
                  Valores pequeños como 0.001 garantizan estabilidad sin costo computacional excesivo.
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Fortalezas y Limitaciones */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="rounded-2xl border border-emerald-900/30 bg-emerald-950/20 p-4 space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold text-emerald-300">
            <CheckCircle className="h-4 w-4" />
            <span>Fortalezas de K-Means</span>
          </div>
          <ul className="text-xs text-slate-300 space-y-1.5 list-disc list-inside">
            <li>Extremadamente veloz: complejidad temporal lineal O(n · k · iteraciones).</li>
            <li>Escalable a millones de registros en bases de datos masivas.</li>
            <li>Interpretación geométrica intuitiva: cada cluster tiene un representante claro (centroide).</li>
          </ul>
        </div>

        <div className="rounded-2xl border border-amber-900/30 bg-amber-950/20 p-4 space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
            <AlertTriangle className="h-4 w-4" />
            <span>Limitaciones Clave</span>
          </div>
          <ul className="text-xs text-slate-300 space-y-1.5 list-disc list-inside">
            <li>Requiere fijar K a priori (no descubre automáticamente el número de grupos).</li>
            <li>Sensible a datos atípicos (outliers) que arrastran los centroides hacia los extremos.</li>
            <li>Solo detecta clústeres esféricos/convexos de varianza similar (falla en anillos o lunas).</li>
          </ul>
        </div>
      </div>
    </div>
  );
};
