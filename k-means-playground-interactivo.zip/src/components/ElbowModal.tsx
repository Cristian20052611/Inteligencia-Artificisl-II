import React, { useMemo } from 'react';
import { X, TrendingDown, Check, Sparkles, AlertCircle } from 'lucide-react';
import { ElbowDataPoint } from '../types';
import { computeElbowCurve } from '../utils/kmeans';
import { Point } from '../types';

interface ElbowModalProps {
  isOpen: boolean;
  onClose: () => void;
  points: Point[];
  currentK: number;
  onSelectK: (k: number) => void;
}

export const ElbowModal: React.FC<ElbowModalProps> = ({
  isOpen,
  onClose,
  points,
  currentK,
  onSelectK,
}) => {
  const elbowData = useMemo(() => {
    if (!isOpen || points.length === 0) return [];
    return computeElbowCurve(points, 8);
  }, [isOpen, points]);

  // Encontrar el "codo" matemático aproximado calculando segundas diferencias
  const detectedOptimalK = useMemo(() => {
    if (elbowData.length < 3) return 3;

    // Buscar el punto donde la reducción de WCSS disminuye drásticamente
    let maxSecondDiff = -Infinity;
    let bestK = 3;

    for (let i = 1; i < elbowData.length - 1; i++) {
      const prev = elbowData[i - 1].wcss;
      const curr = elbowData[i].wcss;
      const next = elbowData[i + 1].wcss;

      // Segunda derivada discreta: (curr - prev) - (next - curr)
      const drop1 = prev - curr;
      const drop2 = curr - next;
      const difference = drop1 - drop2;

      if (difference > maxSecondDiff) {
        maxSecondDiff = difference;
        bestK = elbowData[i].k;
      }
    }

    return bestK;
  }, [elbowData]);

  if (!isOpen) return null;

  // Normalización para gráficos SVG
  const maxWcss = Math.max(...elbowData.map((d) => d.wcss), 0.001);
  const minWcss = Math.min(...elbowData.map((d) => d.wcss), 0);

  const svgWidth = 520;
  const svgHeight = 220;
  const padding = 45;

  const getX = (k: number) => {
    return padding + ((k - 1) / (elbowData.length - 1 || 1)) * (svgWidth - padding * 2);
  };

  const getY = (wcss: number) => {
    const range = maxWcss - minWcss || 1;
    return (
      svgHeight -
      padding -
      ((wcss - minWcss) / range) * (svgHeight - padding * 2)
    );
  };

  const pathD = elbowData.reduce((acc, d, i) => {
    const x = getX(d.k);
    const y = getY(d.wcss);
    return i === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
  }, '');

  return (
    <div
      id="elbow-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 animate-in fade-in duration-200"
    >
      <div
        id="elbow-modal-card"
        className="relative w-full max-w-2xl rounded-3xl border border-slate-800 bg-slate-900 p-6 shadow-2xl overflow-hidden"
      >
        {/* Encabezado */}
        <div className="flex items-start justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-indigo-500/10 border border-indigo-500/30 text-indigo-400">
              <TrendingDown className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">El Método del Codo (Elbow Method)</h2>
              <p className="text-xs text-slate-400">
                ¿Cómo elegir el número óptimo de clústeres K sin supervisión?
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-xl p-2 text-slate-400 hover:bg-slate-800 hover:text-white transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Explicación Teórica Concisa */}
        <div className="mt-4 rounded-2xl bg-indigo-950/30 border border-indigo-900/40 p-4 text-xs text-indigo-200 flex items-start gap-3">
          <Sparkles className="h-5 w-5 text-indigo-400 shrink-0 mt-0.5" />
          <div>
            <strong className="text-indigo-300">Regla del Codo:</strong> A medida que aumentamos{' '}
            <strong className="text-white">K</strong>, la inercia (WCSS) siempre disminuye. El punto
            óptimo es el <span className="underline decoration-indigo-400">"codo"</span> del brazo,
            donde la curva deja de caer en picado y se aplana. Añadir más clústeres más allá del
            codo solo fragmenta grupos naturales sin aportar ganancia informativa real.
          </div>
        </div>

        {/* Gráfico SVG de Inercia */}
        <div className="mt-5 rounded-2xl border border-slate-800/80 bg-slate-950 p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-300">
              Curva de Inercia (WCSS) vs K
            </span>
            <span className="text-[11px] text-indigo-400 flex items-center gap-1">
              <span className="h-2 w-2 rounded-full bg-amber-400" />
              Codo Sugerido:{' '}
              <strong className="text-white font-mono">K = {detectedOptimalK}</strong>
            </span>
          </div>

          <div className="w-full overflow-x-auto">
            <svg
              viewBox={`0 0 ${svgWidth} ${svgHeight}`}
              className="w-full h-auto max-h-[220px]"
            >
              {/* Cuadrícula de fondo */}
              {[1, 2, 3, 4, 5, 6, 7, 8].map((k) => (
                <line
                  key={k}
                  x1={getX(k)}
                  y1={padding}
                  x2={getX(k)}
                  y2={svgHeight - padding}
                  stroke="#1e293b"
                  strokeWidth="1"
                  strokeDasharray="2,2"
                />
              ))}

              {/* Área bajo la curva */}
              {pathD && (
                <path
                  d={`${pathD} L ${getX(elbowData[elbowData.length - 1]?.k || 8)} ${
                    svgHeight - padding
                  } L ${getX(1)} ${svgHeight - padding} Z`}
                  fill="url(#elbow-grad)"
                  opacity="0.25"
                />
              )}

              {/* Gradiente */}
              <defs>
                <linearGradient id="elbow-grad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#6366f1" />
                  <stop offset="100%" stopColor="#6366f1" stopOpacity="0" />
                </linearGradient>
              </defs>

              {/* Línea principal */}
              <path
                d={pathD}
                fill="none"
                stroke="#6366f1"
                strokeWidth="3"
                strokeLinecap="round"
                strokeLinejoin="round"
              />

              {/* Puntos y Etiquetas */}
              {elbowData.map((d) => {
                const x = getX(d.k);
                const y = getY(d.wcss);
                const isSelected = d.k === currentK;
                const isOptimal = d.k === detectedOptimalK;

                return (
                  <g key={d.k} className="cursor-pointer" onClick={() => onSelectK(d.k)}>
                    {/* Resaltado del óptimo */}
                    {isOptimal && (
                      <circle
                        cx={x}
                        y={y}
                        r="14"
                        fill="none"
                        stroke="#f59e0b"
                        strokeWidth="1.5"
                        strokeDasharray="3,3"
                        className="animate-spin origin-center"
                      />
                    )}

                    {/* Nodo */}
                    <circle
                      cx={x}
                      y={y}
                      r={isSelected ? 7 : isOptimal ? 6 : 4.5}
                      fill={isSelected ? '#38bdf8' : isOptimal ? '#f59e0b' : '#6366f1'}
                      stroke="#0f172a"
                      strokeWidth="2"
                    />

                    {/* Etiqueta Eje X */}
                    <text
                      x={x}
                      y={svgHeight - padding + 18}
                      textAnchor="middle"
                      fill={isSelected ? '#38bdf8' : '#94a3b8'}
                      fontSize="11"
                      fontWeight={isSelected ? 'bold' : 'normal'}
                      fontFamily="JetBrains Mono"
                    >
                      K={d.k}
                    </text>

                    {/* Valor WCSS encima del punto */}
                    <text
                      x={x}
                      y={y - 10}
                      textAnchor="middle"
                      fill="#cbd5e1"
                      fontSize="10"
                      fontFamily="JetBrains Mono"
                    >
                      {d.wcss.toFixed(1)}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>
        </div>

        {/* Selector interactivo de K */}
        <div className="mt-4 flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-800">
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <span>Seleccionar K directamente:</span>
            <div className="flex gap-1">
              {elbowData.map((d) => (
                <button
                  key={d.k}
                  onClick={() => onSelectK(d.k)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold transition ${
                    currentK === d.k
                      ? 'bg-indigo-600 text-white shadow-md'
                      : d.k === detectedOptimalK
                      ? 'border border-amber-500/50 bg-amber-950/40 text-amber-300 hover:bg-amber-900/50'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-750'
                  }`}
                >
                  K={d.k}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={() => {
              onSelectK(detectedOptimalK);
              onClose();
            }}
            className="flex items-center gap-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 px-4 py-2 text-xs font-semibold text-white shadow-md shadow-indigo-900/40 transition"
          >
            <Check className="h-4 w-4" />
            <span>Aplicar K Óptimo ({detectedOptimalK}) y Cerrar</span>
          </button>
        </div>
      </div>
    </div>
  );
};
