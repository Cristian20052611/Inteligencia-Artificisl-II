import React from 'react';
import {
  Sparkles,
  Sliders,
  Scale,
  Trophy,
  BookOpen,
  Shuffle,
  Layers,
} from 'lucide-react';
import { AppMode, DatasetPreset } from '../types';
import { DATASET_PRESETS } from '../utils/kmeans';

interface HeaderProps {
  currentMode: AppMode;
  onSelectMode: (mode: AppMode) => void;
  selectedPresetId: string;
  onSelectPreset: (presetId: string) => void;
  onRandomizeDataset: () => void;
  pointCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentMode,
  onSelectMode,
  selectedPresetId,
  onSelectPreset,
  onRandomizeDataset,
  pointCount,
}) => {
  return (
    <header
      id="app-header"
      className="border-b border-slate-800/80 bg-slate-950/90 backdrop-blur-md sticky top-0 z-40"
    >
      <div className="max-w-7xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-4">
        {/* Marca / Título */}
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-tr from-indigo-600 to-violet-500 shadow-md shadow-indigo-600/30 text-white font-bold text-lg">
            K
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-extrabold text-white tracking-tight">
                K-Means Playground
              </h1>
              <span className="rounded-full border border-indigo-500/30 bg-indigo-950/60 px-2 py-0.5 text-[10px] font-semibold text-indigo-300">
                No Supervisado
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              Visualizador interactivo en tiempo real de agrupamiento & hiperparámetros
            </p>
          </div>
        </div>

        {/* Selector de Modos de la Aplicación */}
        <div
          id="mode-tabs"
          className="flex items-center rounded-2xl bg-slate-900 border border-slate-800/80 p-1 text-xs"
        >
          <button
            id="tab-sandbox"
            onClick={() => onSelectMode('sandbox')}
            className={`flex items-center gap-1.5 rounded-xl px-3.5 py-2 font-semibold transition ${
              currentMode === 'sandbox'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Sliders className="h-3.5 w-3.5" />
            <span>Explorador</span>
          </button>

          <button
            id="tab-comparison"
            onClick={() => onSelectMode('comparison')}
            className={`flex items-center gap-1.5 rounded-xl px-3.5 py-2 font-semibold transition ${
              currentMode === 'comparison'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Scale className="h-3.5 w-3.5" />
            <span>Comparador A/B</span>
          </button>

          <button
            id="tab-challenges"
            onClick={() => onSelectMode('challenges')}
            className={`flex items-center gap-1.5 rounded-xl px-3.5 py-2 font-semibold transition ${
              currentMode === 'challenges'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Trophy className="h-3.5 w-3.5 text-amber-400" />
            <span>Retos Lúdicos</span>
          </button>

          <button
            id="tab-theory"
            onClick={() => onSelectMode('theory')}
            className={`flex items-center gap-1.5 rounded-xl px-3.5 py-2 font-semibold transition ${
              currentMode === 'theory'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <BookOpen className="h-3.5 w-3.5" />
            <span>Guía Teórica</span>
          </button>
        </div>

        {/* Selector de Datasets de Prueba */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 text-xs text-slate-400">
            <Layers className="h-3.5 w-3.5 text-slate-500" />
            <span className="hidden sm:inline">Dataset:</span>
          </div>

          <select
            id="select-dataset-preset"
            value={selectedPresetId}
            onChange={(e) => onSelectPreset(e.target.value)}
            className="rounded-xl border border-slate-700 bg-slate-800 px-3 py-1.5 text-xs font-medium text-slate-200 outline-none transition focus:border-indigo-500"
          >
            {DATASET_PRESETS.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name}
              </option>
            ))}
          </select>

          <button
            id="btn-randomize-dataset"
            onClick={onRandomizeDataset}
            className="flex items-center gap-1 rounded-xl border border-slate-700 bg-slate-800 p-2 text-xs text-slate-300 hover:bg-slate-750 hover:text-white transition"
            title="Generar nueva variación aleatoria del dataset"
          >
            <Shuffle className="h-3.5 w-3.5" />
          </button>

          <span className="hidden md:inline-block rounded-lg bg-slate-900 border border-slate-800 px-2 py-1 text-[11px] font-mono text-slate-400">
            {pointCount} pts
          </span>
        </div>
      </div>
    </header>
  );
};
