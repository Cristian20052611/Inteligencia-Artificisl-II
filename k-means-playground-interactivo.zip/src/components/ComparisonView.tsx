import React, { useState, useEffect } from 'react';
import {
  Play,
  RotateCcw,
  Sparkles,
  ArrowRight,
  TrendingDown,
  CheckCircle2,
  Sliders,
  Scale,
} from 'lucide-react';
import { Centroid, DistanceMetric, InitMethod, Point } from '../types';
import {
  initializeCentroids,
  stepKMeans,
  calculateWCSS,
  calculateSilhouetteScore,
  CLUSTER_COLORS,
} from '../utils/kmeans';
import { KMeansCanvas } from './KMeansCanvas';

interface ComparisonViewProps {
  basePoints: Point[];
}

interface ModelSetup {
  id: 'A' | 'B';
  name: string;
  k: number;
  initMethod: InitMethod;
  distanceMetric: DistanceMetric;
  centroids: Centroid[];
  points: Point[];
  iteration: number;
  hasConverged: boolean;
  isStepAssignNext: boolean;
  wcss: number;
  silhouette: number;
}

export const ComparisonView: React.FC<ComparisonViewProps> = ({ basePoints }) => {
  // Configuración de Modelos A y B
  const [setupA, setSetupA] = useState<{
    k: number;
    initMethod: InitMethod;
    distanceMetric: DistanceMetric;
  }>({
    k: 3,
    initMethod: 'kmeans_plus_plus',
    distanceMetric: 'euclidean',
  });

  const [setupB, setSetupB] = useState<{
    k: number;
    initMethod: InitMethod;
    distanceMetric: DistanceMetric;
  }>({
    k: 3,
    initMethod: 'random',
    distanceMetric: 'euclidean',
  });

  const [stateA, setStateA] = useState<ModelSetup>({
    id: 'A',
    name: 'Modelo A (K-Means++)',
    ...setupA,
    centroids: [],
    points: basePoints,
    iteration: 0,
    hasConverged: false,
    isStepAssignNext: true,
    wcss: 0,
    silhouette: 0,
  });

  const [stateB, setStateB] = useState<ModelSetup>({
    id: 'B',
    name: 'Modelo B (Random Uniforme)',
    ...setupB,
    centroids: [],
    points: basePoints,
    iteration: 0,
    hasConverged: false,
    isStepAssignNext: true,
    wcss: 0,
    silhouette: 0,
  });

  const [isRunning, setIsRunning] = useState(false);

  // Inicializar ambos modelos
  const initModels = () => {
    setIsRunning(false);

    const centroidsA = initializeCentroids(
      basePoints,
      setupA.k,
      setupA.initMethod,
      setupA.distanceMetric
    );
    const centroidsB = initializeCentroids(
      basePoints,
      setupB.k,
      setupB.initMethod,
      setupB.distanceMetric
    );

    setStateA({
      id: 'A',
      name: `Modelo A (${setupA.initMethod === 'kmeans_plus_plus' ? 'K-Means++' : setupA.initMethod}, ${setupA.distanceMetric})`,
      ...setupA,
      centroids: centroidsA,
      points: basePoints.map((p) => ({ ...p, cluster: undefined })),
      iteration: 0,
      hasConverged: false,
      isStepAssignNext: true,
      wcss: 0,
      silhouette: 0,
    });

    setStateB({
      id: 'B',
      name: `Modelo B (${setupB.initMethod === 'kmeans_plus_plus' ? 'K-Means++' : setupB.initMethod}, ${setupB.distanceMetric})`,
      ...setupB,
      centroids: centroidsB,
      points: basePoints.map((p) => ({ ...p, cluster: undefined })),
      iteration: 0,
      hasConverged: false,
      isStepAssignNext: true,
      wcss: 0,
      silhouette: 0,
    });
  };

  useEffect(() => {
    initModels();
  }, [basePoints, setupA, setupB]);

  // Loop de ejecución sincrónica
  useEffect(() => {
    if (!isRunning) return;

    if (stateA.hasConverged && stateB.hasConverged) {
      setIsRunning(false);
      return;
    }

    const timer = setTimeout(() => {
      // Avanzar A si no ha convergido
      if (!stateA.hasConverged) {
        const nextA = stepKMeans(
          {
            points: stateA.points,
            centroids: stateA.centroids,
            step: stateA.isStepAssignNext ? 'assign' : 'update',
            iteration: stateA.iteration,
            isStepAssignNext: stateA.isStepAssignNext,
            wcss: stateA.wcss,
            silhouetteScore: stateA.silhouette,
            hasConverged: stateA.hasConverged,
            maxCentroidDelta: 1,
          },
          {
            k: setupA.k,
            initMethod: setupA.initMethod,
            distanceMetric: setupA.distanceMetric,
            maxIterations: 40,
            tolerance: 0.001,
          }
        );
        setStateA((prev) => ({
          ...prev,
          points: nextA.points,
          centroids: nextA.centroids,
          iteration: nextA.iteration,
          isStepAssignNext: nextA.isStepAssignNext,
          hasConverged: nextA.hasConverged,
          wcss: nextA.wcss,
          silhouette: nextA.silhouetteScore,
        }));
      }

      // Avanzar B si no ha convergido
      if (!stateB.hasConverged) {
        const nextB = stepKMeans(
          {
            points: stateB.points,
            centroids: stateB.centroids,
            step: stateB.isStepAssignNext ? 'assign' : 'update',
            iteration: stateB.iteration,
            isStepAssignNext: stateB.isStepAssignNext,
            wcss: stateB.wcss,
            silhouetteScore: stateB.silhouette,
            hasConverged: stateB.hasConverged,
            maxCentroidDelta: 1,
          },
          {
            k: setupB.k,
            initMethod: setupB.initMethod,
            distanceMetric: setupB.distanceMetric,
            maxIterations: 40,
            tolerance: 0.001,
          }
        );
        setStateB((prev) => ({
          ...prev,
          points: nextB.points,
          centroids: nextB.centroids,
          iteration: nextB.iteration,
          isStepAssignNext: nextB.isStepAssignNext,
          hasConverged: nextB.hasConverged,
          wcss: nextB.wcss,
          silhouette: nextB.silhouetteScore,
        }));
      }
    }, 200);

    return () => clearTimeout(timer);
  }, [isRunning, stateA, stateB, setupA, setupB]);

  // Presets rápidos de comparación didáctica
  const applyComparisonPreset = (preset: 'init' | 'metric' | 'k_diff') => {
    if (preset === 'init') {
      setSetupA({ k: 3, initMethod: 'kmeans_plus_plus', distanceMetric: 'euclidean' });
      setSetupB({ k: 3, initMethod: 'adversarial', distanceMetric: 'euclidean' });
    } else if (preset === 'metric') {
      setSetupA({ k: 3, initMethod: 'kmeans_plus_plus', distanceMetric: 'euclidean' });
      setSetupB({ k: 3, initMethod: 'kmeans_plus_plus', distanceMetric: 'manhattan' });
    } else if (preset === 'k_diff') {
      setSetupA({ k: 3, initMethod: 'kmeans_plus_plus', distanceMetric: 'euclidean' });
      setSetupB({ k: 5, initMethod: 'kmeans_plus_plus', distanceMetric: 'euclidean' });
    }
  };

  return (
    <div id="comparison-view-root" className="flex flex-col gap-6">
      {/* Barra de Presets Didácticos */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-slate-800 bg-slate-900/80 p-4">
        <div className="flex items-center gap-2 text-sm text-slate-300">
          <Scale className="h-5 w-5 text-indigo-400" />
          <span className="font-semibold text-white">Experimentos Guiados A/B:</span>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => applyComparisonPreset('init')}
            className="rounded-xl border border-slate-700 bg-slate-800 px-3 py-1.5 text-xs font-medium text-slate-200 hover:bg-slate-700 hover:text-white transition"
          >
            🔥 K-Means++ vs Inicialización Adversaria
          </button>
          <button
            onClick={() => applyComparisonPreset('metric')}
            className="rounded-xl border border-slate-700 bg-slate-800 px-3 py-1.5 text-xs font-medium text-slate-200 hover:bg-slate-700 hover:text-white transition"
          >
            📐 Distancia Euclidiana vs Manhattan
          </button>
          <button
            onClick={() => applyComparisonPreset('k_diff')}
            className="rounded-xl border border-slate-700 bg-slate-800 px-3 py-1.5 text-xs font-medium text-slate-200 hover:bg-slate-700 hover:text-white transition"
          >
            🔢 K = 3 vs K = 5
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsRunning(!isRunning)}
            className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold text-white transition shadow-md ${
              isRunning ? 'bg-amber-600 hover:bg-amber-500' : 'bg-indigo-600 hover:bg-indigo-500'
            }`}
          >
            <Play className="h-4 w-4" />
            <span>{isRunning ? 'Pausar Ambos' : 'Comparar en Vivo'}</span>
          </button>
          <button
            onClick={initModels}
            className="rounded-xl border border-slate-800 bg-slate-850 p-2 text-slate-400 hover:text-white transition"
            title="Reiniciar prueba"
          >
            <RotateCcw className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Rejilla Comparativa de Lienzos Lado a Lado */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Modelo A */}
        <div className="flex flex-col gap-3 rounded-3xl border border-indigo-900/50 bg-slate-900/90 p-5 shadow-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="flex h-6 w-6 items-center justify-center rounded-lg bg-indigo-600 text-xs font-bold text-white">
                A
              </span>
              <h3 className="font-bold text-sm text-white">Configuración A</h3>
            </div>
            {stateA.hasConverged && (
              <span className="flex items-center gap-1 text-xs text-emerald-400 font-medium">
                <CheckCircle2 className="h-3.5 w-3.5" /> Convergió ({stateA.iteration} iter)
              </span>
            )}
          </div>

          {/* Selectores Modelo A */}
          <div className="grid grid-cols-3 gap-2 bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80 text-xs">
            <div>
              <label className="text-[10px] text-slate-400 block mb-1">K (Clústeres):</label>
              <select
                value={setupA.k}
                onChange={(e) => setSetupA({ ...setupA, k: Number(e.target.value) })}
                className="w-full rounded-lg bg-slate-800 border border-slate-700 py-1 px-2 text-xs text-white"
              >
                {[2, 3, 4, 5, 6].map((k) => (
                  <option key={k} value={k}>
                    K = {k}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-[10px] text-slate-400 block mb-1">Inicialización:</label>
              <select
                value={setupA.initMethod}
                onChange={(e) =>
                  setSetupA({ ...setupA, initMethod: e.target.value as InitMethod })
                }
                className="w-full rounded-lg bg-slate-800 border border-slate-700 py-1 px-2 text-xs text-white"
              >
                <option value="kmeans_plus_plus">K-Means++</option>
                <option value="random">Aleatoria</option>
                <option value="adversarial">Adversaria</option>
              </select>
            </div>
            <div>
              <label className="text-[10px] text-slate-400 block mb-1">Métrica:</label>
              <select
                value={setupA.distanceMetric}
                onChange={(e) =>
                  setSetupA({ ...setupA, distanceMetric: e.target.value as DistanceMetric })
                }
                className="w-full rounded-lg bg-slate-800 border border-slate-700 py-1 px-2 text-xs text-white"
              >
                <option value="euclidean">Euclidiana (L2)</option>
                <option value="manhattan">Manhattan (L1)</option>
                <option value="chebyshev">Chebyshev (L∞)</option>
              </select>
            </div>
          </div>

          {/* Canvas A */}
          <KMeansCanvas
            points={stateA.points}
            centroids={stateA.centroids}
            metric={setupA.distanceMetric}
            heightClass="h-[340px]"
            showTrails={true}
            showVoronoi={true}
          />

          {/* Métricas A */}
          <div className="grid grid-cols-3 gap-2 bg-slate-950/80 p-3 rounded-xl border border-slate-800/80 text-xs">
            <div>
              <span className="text-[10px] text-slate-400 block">Inercia WCSS:</span>
              <strong className="text-amber-300 font-mono text-sm">{stateA.wcss.toFixed(2)}</strong>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block">Silueta:</span>
              <strong className="text-cyan-300 font-mono text-sm">
                {stateA.silhouette.toFixed(3)}
              </strong>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block">Iteraciones:</span>
              <strong className="text-white font-mono text-sm">{stateA.iteration}</strong>
            </div>
          </div>
        </div>

        {/* Modelo B */}
        <div className="flex flex-col gap-3 rounded-3xl border border-amber-900/40 bg-slate-900/90 p-5 shadow-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="flex h-6 w-6 items-center justify-center rounded-lg bg-amber-600 text-xs font-bold text-white">
                B
              </span>
              <h3 className="font-bold text-sm text-white">Configuración B</h3>
            </div>
            {stateB.hasConverged && (
              <span className="flex items-center gap-1 text-xs text-emerald-400 font-medium">
                <CheckCircle2 className="h-3.5 w-3.5" /> Convergió ({stateB.iteration} iter)
              </span>
            )}
          </div>

          {/* Selectores Modelo B */}
          <div className="grid grid-cols-3 gap-2 bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80 text-xs">
            <div>
              <label className="text-[10px] text-slate-400 block mb-1">K (Clústeres):</label>
              <select
                value={setupB.k}
                onChange={(e) => setSetupB({ ...setupB, k: Number(e.target.value) })}
                className="w-full rounded-lg bg-slate-800 border border-slate-700 py-1 px-2 text-xs text-white"
              >
                {[2, 3, 4, 5, 6].map((k) => (
                  <option key={k} value={k}>
                    K = {k}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-[10px] text-slate-400 block mb-1">Inicialización:</label>
              <select
                value={setupB.initMethod}
                onChange={(e) =>
                  setSetupB({ ...setupB, initMethod: e.target.value as InitMethod })
                }
                className="w-full rounded-lg bg-slate-800 border border-slate-700 py-1 px-2 text-xs text-white"
              >
                <option value="random">Aleatoria</option>
                <option value="kmeans_plus_plus">K-Means++</option>
                <option value="adversarial">Adversaria</option>
              </select>
            </div>
            <div>
              <label className="text-[10px] text-slate-400 block mb-1">Métrica:</label>
              <select
                value={setupB.distanceMetric}
                onChange={(e) =>
                  setSetupB({ ...setupB, distanceMetric: e.target.value as DistanceMetric })
                }
                className="w-full rounded-lg bg-slate-800 border border-slate-700 py-1 px-2 text-xs text-white"
              >
                <option value="euclidean">Euclidiana (L2)</option>
                <option value="manhattan">Manhattan (L1)</option>
                <option value="chebyshev">Chebyshev (L∞)</option>
              </select>
            </div>
          </div>

          {/* Canvas B */}
          <KMeansCanvas
            points={stateB.points}
            centroids={stateB.centroids}
            metric={setupB.distanceMetric}
            heightClass="h-[340px]"
            showTrails={true}
            showVoronoi={true}
          />

          {/* Métricas B */}
          <div className="grid grid-cols-3 gap-2 bg-slate-950/80 p-3 rounded-xl border border-slate-800/80 text-xs">
            <div>
              <span className="text-[10px] text-slate-400 block">Inercia WCSS:</span>
              <strong className="text-amber-300 font-mono text-sm">{stateB.wcss.toFixed(2)}</strong>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block">Silueta:</span>
              <strong className="text-cyan-300 font-mono text-sm">
                {stateB.silhouette.toFixed(3)}
              </strong>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block">Iteraciones:</span>
              <strong className="text-white font-mono text-sm">{stateB.iteration}</strong>
            </div>
          </div>
        </div>
      </div>

      {/* Veredicto de la Comparativa */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-4 text-xs text-slate-300 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-amber-400" />
          <span>
            {stateA.wcss < stateB.wcss && stateA.wcss > 0
              ? '✨ Configuración A logró menor inercia (mejor compacidad de clústeres).'
              : stateB.wcss < stateA.wcss && stateB.wcss > 0
              ? '✨ Configuración B logró menor inercia.'
              : 'Ejecuta la simulación para comparar cuál converge más rápido y con menor dispersión de error.'}
          </span>
        </div>
        <span className="text-slate-500 font-mono text-[11px]">
          Ambos corren sobre el idéntico conjunto de {basePoints.length} datos
        </span>
      </div>
    </div>
  );
};
