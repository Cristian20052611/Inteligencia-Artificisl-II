import React from 'react';
import {
  Play,
  Pause,
  SkipForward,
  RotateCcw,
  Sparkles,
  Gauge,
  Sliders,
  Eye,
  Info,
  Layers,
  CheckCircle2,
  TrendingDown,
  Activity,
} from 'lucide-react';
import { DistanceMetric, InitMethod, KMeansHyperparameters, KMeansState } from '../types';
import { CLUSTER_COLORS } from '../utils/kmeans';

interface ControlPanelProps {
  hyperparams: KMeansHyperparameters;
  onUpdateHyperparams: (newParams: Partial<KMeansHyperparameters>) => void;
  state: KMeansState;
  isRunning: boolean;
  onTogglePlay: () => void;
  onNextStep: () => void;
  onReset: () => void;
  onReinitCentroids: () => void;
  onOpenElbowModal: () => void;
  animationSpeed: number; // ms
  onChangeSpeed: (speed: number) => void;
  showVoronoi: boolean;
  onToggleVoronoi: () => void;
  showTrails: boolean;
  onToggleTrails: () => void;
  showConnectors: boolean;
  onToggleConnectors: () => void;
  sprayMode: boolean;
  onToggleSprayMode: () => void;
  onAddRandomPoints: (count: number) => void;
  onClearPoints: () => void;
}

export const ControlPanel: React.FC<ControlPanelProps> = ({
  hyperparams,
  onUpdateHyperparams,
  state,
  isRunning,
  onTogglePlay,
  onNextStep,
  onReset,
  onReinitCentroids,
  onOpenElbowModal,
  animationSpeed,
  onChangeSpeed,
  showVoronoi,
  onToggleVoronoi,
  showTrails,
  onToggleTrails,
  showConnectors,
  onToggleConnectors,
  sprayMode,
  onToggleSprayMode,
  onAddRandomPoints,
  onClearPoints,
}) => {
  return (
    <div id="kmeans-control-panel" className="flex flex-col gap-4">
      {/* 1. Barra de Ejecución y Pasos */}
      <div
        id="execution-bar"
        className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-slate-800 bg-slate-900/90 p-4 shadow-xl backdrop-blur-md"
      >
        <div className="flex items-center gap-2">
          {/* Play / Pausa */}
          <button
            id="btn-play-pause"
            onClick={onTogglePlay}
            disabled={state.hasConverged}
            className={`flex items-center gap-2 rounded-xl px-5 py-2.5 text-sm font-semibold transition-all shadow-md active:scale-95 ${
              state.hasConverged
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                : isRunning
                ? 'bg-amber-600 hover:bg-amber-500 text-white shadow-amber-950/40'
                : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-950/50 hover:shadow-indigo-600/25'
            }`}
          >
            {isRunning ? (
              <>
                <Pause className="h-4 w-4" /> Pausar
              </>
            ) : (
              <>
                <Play className="h-4 w-4 fill-current" /> Auto-Ejecutar
              </>
            )}
          </button>

          {/* Siguiente Paso */}
          <button
            id="btn-next-step"
            onClick={onNextStep}
            disabled={isRunning || state.hasConverged}
            className={`flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-800 px-4 py-2.5 text-sm font-medium text-slate-200 transition-all hover:bg-slate-750 hover:border-slate-600 active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed`}
            title="Avanzar exactamente medio ciclo (asignación o actualización de medias)"
          >
            <SkipForward className="h-4 w-4 text-indigo-400" />
            <span>
              Paso:{' '}
              <strong className="text-indigo-300">
                {state.isStepAssignNext ? '1. Asignar Puntos' : '2. Mover Centroides'}
              </strong>
            </span>
          </button>

          {/* Reiniciar */}
          <button
            id="btn-reset"
            onClick={onReset}
            className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-850 px-3.5 py-2.5 text-sm font-medium text-slate-300 transition hover:bg-slate-800 hover:text-white"
            title="Reiniciar algoritmo con los centroides actuales"
          >
            <RotateCcw className="h-4 w-4 text-slate-400" />
            <span>Reset</span>
          </button>

          {/* Re-inicializar */}
          <button
            id="btn-reinit-centroids"
            onClick={onReinitCentroids}
            className="flex items-center gap-1.5 rounded-xl border border-indigo-900/50 bg-indigo-950/40 px-3.5 py-2.5 text-sm font-medium text-indigo-300 transition hover:bg-indigo-900/50 hover:text-white"
            title="Generar nueva posición inicial para los centroides"
          >
            <Sparkles className="h-4 w-4 text-indigo-400" />
            <span>Nuevos Centroides</span>
          </button>
        </div>

        {/* Velocidad */}
        <div className="flex items-center gap-2">
          <Gauge className="h-4 w-4 text-slate-400" />
          <span className="text-xs text-slate-400 font-medium">Velocidad:</span>
          <div className="flex rounded-lg bg-slate-800 p-0.5 text-xs">
            {[
              { label: 'Lenta', speed: 800 },
              { label: 'Normal', speed: 380 },
              { label: 'Rápida', speed: 120 },
              { label: 'Turbo', speed: 30 },
            ].map((s) => (
              <button
                key={s.label}
                onClick={() => onChangeSpeed(s.speed)}
                className={`rounded-md px-2.5 py-1 font-medium transition ${
                  animationSpeed === s.speed
                    ? 'bg-indigo-600 text-white font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 2. Tarjeta de Estado & Métricas Clave */}
      <div
        id="metrics-card"
        className="grid grid-cols-2 sm:grid-cols-4 gap-3 rounded-2xl border border-slate-800/80 bg-slate-900/60 p-4"
      >
        {/* Iteración */}
        <div className="flex flex-col gap-1 rounded-xl bg-slate-950/60 p-3 border border-slate-800/40">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Iteración</span>
            <Activity className="h-3.5 w-3.5 text-indigo-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-white">{state.iteration}</span>
            <span className="text-xs text-slate-500">/ {hyperparams.maxIterations} max</span>
          </div>
          <div className="flex items-center gap-1.5 text-[11px]">
            {state.hasConverged ? (
              <span className="flex items-center gap-1 text-emerald-400 font-medium">
                <CheckCircle2 className="h-3 w-3" /> Convergió
              </span>
            ) : (
              <span className="text-slate-400">
                Fase: {state.isStepAssignNext ? 'Asignación' : 'Actualización'}
              </span>
            )}
          </div>
        </div>

        {/* Inercia / WCSS */}
        <div className="flex flex-col gap-1 rounded-xl bg-slate-950/60 p-3 border border-slate-800/40">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Inercia (WCSS)</span>
            <TrendingDown className="h-3.5 w-3.5 text-amber-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-amber-300">
              {state.wcss.toFixed(2)}
            </span>
          </div>
          <span className="text-[11px] text-slate-400 truncate">
            Suma errores al cuadrado (menor = mejor)
          </span>
        </div>

        {/* Coeficiente de Silueta */}
        <div className="flex flex-col gap-1 rounded-xl bg-slate-950/60 p-3 border border-slate-800/40">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Silueta (Calidad)</span>
            <span
              className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                state.silhouetteScore > 0.5
                  ? 'bg-emerald-950 text-emerald-300'
                  : state.silhouetteScore > 0.25
                  ? 'bg-blue-950 text-blue-300'
                  : 'bg-rose-950 text-rose-300'
              }`}
            >
              {state.silhouetteScore > 0.5 ? 'Excelente' : state.silhouetteScore > 0.25 ? 'Moderada' : 'Difusa'}
            </span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-cyan-300">
              {state.silhouetteScore.toFixed(3)}
            </span>
          </div>
          <span className="text-[11px] text-slate-400">
            Rango [-1 a +1], cohesión y separación
          </span>
        </div>

        {/* Desplazamiento máximo del centroide */}
        <div className="flex flex-col gap-1 rounded-xl bg-slate-950/60 p-3 border border-slate-800/40">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Desplazamiento Δ</span>
            <span className="text-[10px] text-slate-500 font-mono">ε={hyperparams.tolerance}</span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-slate-200">
              {state.maxCentroidDelta.toFixed(4)}
            </span>
          </div>
          <span className="text-[11px] text-slate-400">
            {state.maxCentroidDelta <= hyperparams.tolerance
              ? 'Δ ≤ ε (Parada alcanzada)'
              : 'En movimiento'}
          </span>
        </div>
      </div>

      {/* 3. Panel de Hiperparámetros */}
      <div
        id="hyperparameters-section"
        className="rounded-2xl border border-slate-800 bg-slate-900/80 p-4 flex flex-col gap-4 shadow-lg"
      >
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
          <div className="flex items-center gap-2">
            <Sliders className="h-4 w-4 text-indigo-400" />
            <h3 className="text-sm font-semibold text-white">Hiperparámetros del Algoritmo</h3>
          </div>
          <button
            id="btn-open-elbow"
            onClick={onOpenElbowModal}
            className="flex items-center gap-1.5 rounded-lg border border-indigo-500/40 bg-indigo-950/50 px-3 py-1 text-xs font-semibold text-indigo-300 transition hover:bg-indigo-900/60 hover:text-white"
          >
            <TrendingDown className="h-3.5 w-3.5 text-indigo-400" />
            <span>Método del Codo (K óptimo)</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {/* Hiperparámetro 1: K (Número de Clústeres) */}
          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-medium text-slate-300 flex items-center gap-1">
                <span>Número de Clústeres (K):</span>
                <strong className="text-indigo-400 font-mono text-sm">{hyperparams.k}</strong>
              </label>
              <span className="text-[10px] text-slate-500">1 a 9</span>
            </div>

            <div className="flex items-center gap-1.5 flex-wrap">
              {[2, 3, 4, 5, 6, 7, 8].map((num) => (
                <button
                  key={num}
                  onClick={() => onUpdateHyperparams({ k: num })}
                  className={`flex h-8 w-8 items-center justify-center rounded-lg font-mono text-xs font-bold transition ${
                    hyperparams.k === num
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 scale-105'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-750 hover:text-white'
                  }`}
                  style={{
                    borderBottom:
                      hyperparams.k === num
                        ? `3px solid ${CLUSTER_COLORS[(num - 1) % CLUSTER_COLORS.length]}`
                        : undefined,
                  }}
                >
                  {num}
                </button>
              ))}
            </div>

            <p className="text-[11px] text-slate-400 leading-relaxed">
              Define cuántos centroides se buscan. Si K es muy bajo se mezclan datos; si es muy alto
              se sobreajusta (overfitting).
            </p>
          </div>

          {/* Hiperparámetro 2: Método de Inicialización */}
          <div className="flex flex-col gap-2">
            <label className="text-xs font-medium text-slate-300 flex items-center justify-between">
              <span>Inicialización:</span>
              <span className="text-[10px] text-indigo-400 font-mono">
                {hyperparams.initMethod === 'kmeans_plus_plus'
                  ? 'Recomendado'
                  : hyperparams.initMethod === 'adversarial'
                  ? 'Trampa'
                  : ''}
              </span>
            </label>

            <select
              id="select-init-method"
              value={hyperparams.initMethod}
              onChange={(e) =>
                onUpdateHyperparams({ initMethod: e.target.value as InitMethod })
              }
              className="rounded-xl border border-slate-700 bg-slate-800 px-3 py-2 text-xs font-medium text-slate-200 outline-none transition focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
            >
              <option value="kmeans_plus_plus">K-Means++ (Probabilístico D² - Óptimo)</option>
              <option value="random">Aleatoria Uniforme (Espacio)</option>
              <option value="forgy">Forgy (Puntos al azar del Dataset)</option>
              <option value="manual">Manual (Tú marcas las posiciones)</option>
              <option value="adversarial">Adversaria (Esquina - Mínimo local)</option>
            </select>

            <p className="text-[11px] text-slate-400 leading-relaxed">
              {hyperparams.initMethod === 'kmeans_plus_plus'
                ? 'K-Means++ separa los centroides iniciales para evitar caer en óptimos locales pobres.'
                : hyperparams.initMethod === 'adversarial'
                ? 'Comprime centroides en una esquina para ver cómo el algoritmo estándar puede fracasar.'
                : hyperparams.initMethod === 'manual'
                ? 'Haz clic directamente sobre el lienzo para colocar tus propios centroides.'
                : 'Posiciona al azar en el espacio; puede requerir más iteraciones.'}
            </p>
          </div>

          {/* Hiperparámetro 3: Métrica de Distancia */}
          <div className="flex flex-col gap-2">
            <label className="text-xs font-medium text-slate-300">Métrica de Distancia:</label>

            <div className="grid grid-cols-3 gap-1 rounded-xl bg-slate-800 p-1">
              {[
                { id: 'euclidean', label: 'Euclidiana', desc: 'L2 (Línea recta)' },
                { id: 'manhattan', label: 'Manhattan', desc: 'L1 (Taxicab)' },
                { id: 'chebyshev', label: 'Chebyshev', desc: 'L∞ (Máximo)' },
              ].map((m) => (
                <button
                  key={m.id}
                  onClick={() => onUpdateHyperparams({ distanceMetric: m.id as DistanceMetric })}
                  className={`rounded-lg py-1.5 px-2 text-[11px] font-semibold transition ${
                    hyperparams.distanceMetric === m.id
                      ? 'bg-indigo-600 text-white shadow'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                  title={m.desc}
                >
                  {m.label}
                </button>
              ))}
            </div>

            <p className="text-[11px] text-slate-400 leading-relaxed">
              {hyperparams.distanceMetric === 'euclidean'
                ? 'Genera fronteras Voronoi redondeadas y esféricas (caso clásico).'
                : hyperparams.distanceMetric === 'manhattan'
                ? 'Distancia en cuadrícula ortogonal; genera fronteras romboidales en diamante.'
                : 'Distancia de tablero de ajedrez; genera fronteras poligonales cuadradas.'}
            </p>
          </div>
        </div>

        {/* 4. Ajustes Finos (Tolerancia, Max Iter) y Visualizadores */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-800/80 pt-3 text-xs">
          <div className="flex items-center gap-4 flex-wrap">
            {/* Toggles de Visualización */}
            <div className="flex items-center gap-1.5 text-slate-300">
              <Eye className="h-3.5 w-3.5 text-slate-400" />
              <span className="text-[11px] font-medium text-slate-400">Ver en Lienzo:</span>
            </div>

            <label className="flex items-center gap-1.5 cursor-pointer text-slate-300 hover:text-white">
              <input
                type="checkbox"
                checked={showVoronoi}
                onChange={onToggleVoronoi}
                className="rounded border-slate-700 bg-slate-800 text-indigo-600 focus:ring-0"
              />
              <span>Regiones Voronoi</span>
            </label>

            <label className="flex items-center gap-1.5 cursor-pointer text-slate-300 hover:text-white">
              <input
                type="checkbox"
                checked={showTrails}
                onChange={onToggleTrails}
                className="rounded border-slate-700 bg-slate-800 text-indigo-600 focus:ring-0"
              />
              <span>Trayectorias de Centroides</span>
            </label>

            <label className="flex items-center gap-1.5 cursor-pointer text-slate-300 hover:text-white">
              <input
                type="checkbox"
                checked={showConnectors}
                onChange={onToggleConnectors}
                className="rounded border-slate-700 bg-slate-800 text-indigo-600 focus:ring-0"
              />
              <span>Líneas Conectoras</span>
            </label>
          </div>

          {/* Herramientas de Edición de Puntos */}
          <div className="flex items-center gap-2">
            <button
              onClick={onToggleSprayMode}
              className={`rounded-lg px-2.5 py-1 text-xs font-medium transition border ${
                sprayMode
                  ? 'border-indigo-500 bg-indigo-600 text-white'
                  : 'border-slate-700 bg-slate-800 text-slate-300 hover:bg-slate-750'
              }`}
            >
              {sprayMode ? '🖌️ Pincel Spray Activo' : '🖌️ Modo Spray'}
            </button>

            <button
              onClick={() => onAddRandomPoints(35)}
              className="rounded-lg border border-slate-700 bg-slate-800 px-2.5 py-1 text-xs text-slate-300 hover:bg-slate-750 hover:text-white"
            >
              +35 Puntos
            </button>

            <button
              onClick={onClearPoints}
              className="rounded-lg border border-slate-700 bg-slate-800 px-2.5 py-1 text-xs text-rose-400 hover:bg-rose-950/40 hover:border-rose-800"
            >
              Limpiar Lienzo
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
