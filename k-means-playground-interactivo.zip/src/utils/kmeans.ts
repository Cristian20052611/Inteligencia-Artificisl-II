import {
  Centroid,
  DistanceMetric,
  ElbowDataPoint,
  InitMethod,
  KMeansHyperparameters,
  KMeansState,
  Point,
} from '../types';

export const CLUSTER_COLORS = [
  '#3b82f6', // Azul eléctrico
  '#f43f5e', // Rosa carmín
  '#10b981', // Esmeralda
  '#f59e0b', // Ámbar
  '#8b5cf6', // Violeta
  '#06b6d4', // Cian
  '#ec4899', // Fucsia
  '#84cc16', // Lima
  '#f97316', // Naranja brillante
  '#14b8a6', // Turquesa
];

/**
 * Distancia calculada según la métrica elegida
 */
export function calculateDistance(
  p1: { x: number; y: number },
  p2: { x: number; y: number },
  metric: DistanceMetric
): number {
  const dx = p1.x - p2.x;
  const dy = p1.y - p2.y;

  switch (metric) {
    case 'manhattan':
      return Math.abs(dx) + Math.abs(dy);
    case 'chebyshev':
      return Math.max(Math.abs(dx), Math.abs(dy));
    case 'euclidean':
    default:
      return Math.sqrt(dx * dx + dy * dy);
  }
}

/**
 * Inicialización de Centroides
 */
export function initializeCentroids(
  points: Point[],
  k: number,
  method: InitMethod,
  metric: DistanceMetric = 'euclidean',
  manualPositions: { x: number; y: number }[] = []
): Centroid[] {
  if (k <= 0) return [];
  const centroids: Centroid[] = [];

  if (method === 'manual' && manualPositions.length >= k) {
    for (let i = 0; i < k; i++) {
      centroids.push({
        id: i,
        x: manualPositions[i].x,
        y: manualPositions[i].y,
        color: CLUSTER_COLORS[i % CLUSTER_COLORS.length],
        assignedCount: 0,
        history: [{ x: manualPositions[i].x, y: manualPositions[i].y }],
      });
    }
    return centroids;
  }

  if (points.length === 0) {
    // Si no hay puntos, dispersar en un círculo centrado
    for (let i = 0; i < k; i++) {
      const angle = (i / k) * Math.PI * 2;
      const x = 0.5 + 0.3 * Math.cos(angle);
      const y = 0.5 + 0.3 * Math.sin(angle);
      centroids.push({
        id: i,
        x,
        y,
        color: CLUSTER_COLORS[i % CLUSTER_COLORS.length],
        assignedCount: 0,
        history: [{ x, y }],
      });
    }
    return centroids;
  }

  switch (method) {
    case 'kmeans_plus_plus': {
      // 1. Elegir el primer centroide al azar de entre los puntos existentes
      const firstIdx = Math.floor(Math.random() * points.length);
      const c1 = points[firstIdx];
      centroids.push({
        id: 0,
        x: c1.x,
        y: c1.y,
        color: CLUSTER_COLORS[0],
        assignedCount: 0,
        history: [{ x: c1.x, y: c1.y }],
      });

      // 2. Elegir k-1 centroides con probabilidad proporcional a D(x)^2
      for (let c = 1; c < k; c++) {
        const distancesSquared: number[] = [];
        let totalWeight = 0;

        for (const p of points) {
          let minD = Infinity;
          for (const centroid of centroids) {
            const d = calculateDistance(p, centroid, metric);
            if (d < minD) minD = d;
          }
          const w = minD * minD;
          distancesSquared.push(w);
          totalWeight += w;
        }

        // Selección por ruleta ponderada
        let threshold = Math.random() * totalWeight;
        let selectedIdx = 0;
        for (let i = 0; i < points.length; i++) {
          threshold -= distancesSquared[i];
          if (threshold <= 0) {
            selectedIdx = i;
            break;
          }
        }

        const chosenPoint = points[selectedIdx];
        centroids.push({
          id: c,
          x: chosenPoint.x,
          y: chosenPoint.y,
          color: CLUSTER_COLORS[c % CLUSTER_COLORS.length],
          assignedCount: 0,
          history: [{ x: chosenPoint.x, y: chosenPoint.y }],
        });
      }
      break;
    }

    case 'forgy': {
      // Tomar k puntos únicos del dataset aleatoriamente
      const shuffled = [...points].sort(() => 0.5 - Math.random());
      const selected = shuffled.slice(0, Math.min(k, shuffled.length));
      for (let i = 0; i < selected.length; i++) {
        centroids.push({
          id: i,
          x: selected[i].x,
          y: selected[i].y,
          color: CLUSTER_COLORS[i % CLUSTER_COLORS.length],
          assignedCount: 0,
          history: [{ x: selected[i].x, y: selected[i].y }],
        });
      }
      break;
    }

    case 'adversarial': {
      // Coloca todos los centroides comprimidos en una esquina (ej. (0.05, 0.05) con leve perturbación)
      // Demuestra cómo el azar puede atrapar a K-Means en óptimos locales pobres!
      for (let i = 0; i < k; i++) {
        const x = 0.08 + (i * 0.03);
        const y = 0.08 + ((i % 2) * 0.04);
        centroids.push({
          id: i,
          x,
          y,
          color: CLUSTER_COLORS[i % CLUSTER_COLORS.length],
          assignedCount: 0,
          history: [{ x, y }],
        });
      }
      break;
    }

    case 'random':
    default: {
      // Puntos aleatorios uniformes en el rango [0.1, 0.9]
      for (let i = 0; i < k; i++) {
        const x = 0.15 + Math.random() * 0.7;
        const y = 0.15 + Math.random() * 0.7;
        centroids.push({
          id: i,
          x,
          y,
          color: CLUSTER_COLORS[i % CLUSTER_COLORS.length],
          assignedCount: 0,
          history: [{ x, y }],
        });
      }
      break;
    }
  }

  return centroids;
}

/**
 * Paso 1: Asignar cada punto al centroide más cercano
 */
export function assignPointsToCentroids(
  points: Point[],
  centroids: Centroid[],
  metric: DistanceMetric
): { updatedPoints: Point[]; counts: number[] } {
  if (centroids.length === 0) return { updatedPoints: points, counts: [] };

  const counts = new Array(centroids.length).fill(0);
  const updatedPoints = points.map((p) => {
    let bestDist = Infinity;
    let bestCluster = 0;

    for (let i = 0; i < centroids.length; i++) {
      const d = calculateDistance(p, centroids[i], metric);
      if (d < bestDist) {
        bestDist = d;
        bestCluster = i;
      }
    }

    counts[bestCluster]++;
    return {
      ...p,
      cluster: bestCluster,
      distToCentroid: bestDist,
    };
  });

  return { updatedPoints, counts };
}

/**
 * Paso 2: Actualizar centroides a la media (o mediana) de sus puntos asignados
 */
export function updateCentroidsPosition(
  points: Point[],
  centroids: Centroid[],
  tolerance: number
): { updatedCentroids: Centroid[]; maxDelta: number; converged: boolean } {
  let maxDelta = 0;

  const updatedCentroids = centroids.map((centroid) => {
    const assignedPoints = points.filter((p) => p.cluster === centroid.id);

    if (assignedPoints.length === 0) {
      // Si un cluster quedó huérfano sin puntos, conservar posición actual
      return {
        ...centroid,
        assignedCount: 0,
        history: [...centroid.history],
      };
    }

    const sumX = assignedPoints.reduce((acc, p) => acc + p.x, 0);
    const sumY = assignedPoints.reduce((acc, p) => acc + p.y, 0);
    const newX = sumX / assignedPoints.length;
    const newY = sumY / assignedPoints.length;

    const delta = Math.sqrt((newX - centroid.x) ** 2 + (newY - centroid.y) ** 2);
    if (delta > maxDelta) {
      maxDelta = delta;
    }

    return {
      ...centroid,
      x: newX,
      y: newY,
      assignedCount: assignedPoints.length,
      history: [...centroid.history, { x: newX, y: newY }],
    };
  });

  const converged = maxDelta <= tolerance;
  return { updatedCentroids, maxDelta, converged };
}

/**
 * Calcula WCSS (Inercia): suma de cuadrados de distancias entre cada punto y su centroide
 */
export function calculateWCSS(
  points: Point[],
  centroids: Centroid[],
  metric: DistanceMetric
): number {
  if (centroids.length === 0 || points.length === 0) return 0;
  let wcss = 0;

  for (const p of points) {
    if (p.cluster !== undefined && centroids[p.cluster]) {
      const c = centroids[p.cluster];
      const dist = calculateDistance(p, c, metric);
      wcss += dist * dist;
    }
  }

  return Number(wcss.toFixed(4));
}

/**
 * Calcula el coeficiente de silueta simplificado (muestra de hasta 300 puntos para fluidez de 60fps)
 */
export function calculateSilhouetteScore(
  points: Point[],
  centroids: Centroid[],
  metric: DistanceMetric
): number {
  if (centroids.length <= 1 || points.length === 0) return 0;

  // Tomar muestra si hay muchos puntos para mantener 60 FPS
  const sample = points.length > 250
    ? points.filter((_, idx) => idx % Math.ceil(points.length / 250) === 0)
    : points;

  let totalSilhouette = 0;
  let validCount = 0;

  for (const p of sample) {
    if (p.cluster === undefined) continue;

    // a(i): distancia media intra-cluster
    const sameClusterPoints = sample.filter((other) => other.cluster === p.cluster && other.id !== p.id);
    if (sameClusterPoints.length === 0) continue;

    const a_i =
      sameClusterPoints.reduce((acc, o) => acc + calculateDistance(p, o, metric), 0) /
      sameClusterPoints.length;

    // b(i): distancia media al cluster más cercano distinto
    let minOtherClusterAvg = Infinity;
    for (let c = 0; c < centroids.length; c++) {
      if (c === p.cluster) continue;
      const otherPoints = sample.filter((o) => o.cluster === c);
      if (otherPoints.length === 0) continue;

      const avgDist =
        otherPoints.reduce((acc, o) => acc + calculateDistance(p, o, metric), 0) /
        otherPoints.length;
      if (avgDist < minOtherClusterAvg) {
        minOtherClusterAvg = avgDist;
      }
    }

    if (minOtherClusterAvg === Infinity) continue;

    const s_i = (minOtherClusterAvg - a_i) / Math.max(a_i, minOtherClusterAvg);
    totalSilhouette += s_i;
    validCount++;
  }

  return validCount > 0 ? Number((totalSilhouette / validCount).toFixed(3)) : 0;
}

/**
 * Ejecuta un paso individual (alternando asignación y actualización)
 */
export function stepKMeans(
  state: KMeansState,
  params: KMeansHyperparameters
): KMeansState {
  if (state.hasConverged || state.step === 'max_iter') {
    return state;
  }

  if (state.isStepAssignNext) {
    // Paso de Asignación
    const { updatedPoints, counts } = assignPointsToCentroids(
      state.points,
      state.centroids,
      params.distanceMetric
    );

    const updatedCentroids = state.centroids.map((c, i) => ({
      ...c,
      assignedCount: counts[i] || 0,
    }));

    const wcss = calculateWCSS(updatedPoints, updatedCentroids, params.distanceMetric);
    const silhouette = calculateSilhouetteScore(updatedPoints, updatedCentroids, params.distanceMetric);

    return {
      ...state,
      points: updatedPoints,
      centroids: updatedCentroids,
      step: 'assign',
      isStepAssignNext: false,
      wcss,
      silhouetteScore: silhouette,
    };
  } else {
    // Paso de Actualización
    const { updatedCentroids, maxDelta, converged } = updateCentroidsPosition(
      state.points,
      state.centroids,
      params.tolerance
    );

    const nextIter = state.iteration + 1;
    const isMaxReached = nextIter >= params.maxIterations;

    const wcss = calculateWCSS(state.points, updatedCentroids, params.distanceMetric);
    const silhouette = calculateSilhouetteScore(state.points, updatedCentroids, params.distanceMetric);

    return {
      ...state,
      centroids: updatedCentroids,
      iteration: nextIter,
      maxCentroidDelta: maxDelta,
      hasConverged: converged,
      step: converged ? 'converged' : isMaxReached ? 'max_iter' : 'update',
      isStepAssignNext: !converged && !isMaxReached,
      wcss,
      silhouetteScore: silhouette,
    };
  }
}

/**
 * Ejecuta K-Means de inicio a fin hasta convergencia
 */
export function runKMeansToConvergence(
  initialPoints: Point[],
  params: KMeansHyperparameters,
  manualPositions: { x: number; y: number }[] = []
): KMeansState {
  const centroids = initializeCentroids(
    initialPoints,
    params.k,
    params.initMethod,
    params.distanceMetric,
    manualPositions
  );

  let state: KMeansState = {
    points: initialPoints.map((p) => ({ ...p, cluster: undefined })),
    centroids,
    step: 'init',
    iteration: 0,
    isStepAssignNext: true,
    wcss: 0,
    silhouetteScore: 0,
    hasConverged: false,
    maxCentroidDelta: 1,
  };

  while (!state.hasConverged && state.iteration < params.maxIterations) {
    state = stepKMeans(state, params);
  }

  return state;
}

/**
 * Evalúa la curva del método del codo (Elbow Curve) variando K de 1 a maxK
 */
export function computeElbowCurve(
  points: Point[],
  maxK: number = 8,
  metric: DistanceMetric = 'euclidean'
): ElbowDataPoint[] {
  const results: ElbowDataPoint[] = [];

  for (let k = 1; k <= maxK; k++) {
    const finalState = runKMeansToConvergence(points, {
      k,
      initMethod: 'kmeans_plus_plus',
      distanceMetric: metric,
      maxIterations: 30,
      tolerance: 0.001,
    });

    results.push({
      k,
      wcss: finalState.wcss,
      silhouette: finalState.silhouetteScore,
    });
  }

  return results;
}

/* =========================================================================
 * Generadores de Conjuntos de Datos Lúdicos e Interactivos
 * ========================================================================= */

function randomGaussian(mean: number, stdDev: number): number {
  let u1 = 0;
  let u2 = 0;
  while (u1 === 0) u1 = Math.random();
  while (u2 === 0) u2 = Math.random();
  const z0 = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
  return mean + z0 * stdDev;
}

function clamp(val: number, min = 0.04, max = 0.96): number {
  return Math.max(min, Math.min(max, val));
}

let pointCounter = 1;
export function createPoint(x: number, y: number, cluster?: number): Point {
  return {
    id: `pt-${pointCounter++}`,
    x: clamp(x),
    y: clamp(y),
    cluster,
  };
}

export const DATASET_PRESETS = [
  {
    id: 'three_blobs',
    name: '3 Clústeres Claros',
    description: 'Tres grupos esféricos bien separados. Ideal para comprender el caso clásico de K=3.',
    recommendedK: 3,
    iconName: 'Shapes',
    generate: (): Point[] => {
      const pts: Point[] = [];
      const centers = [
        { x: 0.25, y: 0.35, count: 65, spread: 0.06 },
        { x: 0.75, y: 0.3, count: 70, spread: 0.065 },
        { x: 0.5, y: 0.78, count: 75, spread: 0.07 },
      ];
      centers.forEach((c) => {
        for (let i = 0; i < c.count; i++) {
          pts.push(
            createPoint(
              randomGaussian(c.x, c.spread),
              randomGaussian(c.y, c.spread)
            )
          );
        }
      });
      return pts;
    },
  },
  {
    id: 'four_unbalanced',
    name: '4 Clústeres Desbalanceados',
    description: 'Grupos con distinto número de puntos y densidad. Desafía el balance de K-Means.',
    recommendedK: 4,
    iconName: 'Layers',
    generate: (): Point[] => {
      const pts: Point[] = [];
      const clusters = [
        { x: 0.22, y: 0.25, count: 120, spread: 0.05 }, // denso
        { x: 0.8, y: 0.25, count: 40, spread: 0.08 },  // disperso
        { x: 0.3, y: 0.75, count: 50, spread: 0.06 },
        { x: 0.75, y: 0.75, count: 80, spread: 0.07 },
      ];
      clusters.forEach((c) => {
        for (let i = 0; i < c.count; i++) {
          pts.push(
            createPoint(
              randomGaussian(c.x, c.spread),
              randomGaussian(c.y, c.spread)
            )
          );
        }
      });
      return pts;
    },
  },
  {
    id: 'concentric_rings',
    name: 'Anillos Concéntricos (Trampa)',
    description: '¡La trampa clásica! K-Means asume clústeres esféricos/convexos y divide los círculos en porciones.',
    recommendedK: 2,
    iconName: 'Target',
    generate: (): Point[] => {
      const pts: Point[] = [];
      const center = { x: 0.5, y: 0.5 };

      // Núcleo interno denso
      for (let i = 0; i < 70; i++) {
        const r = Math.random() * 0.12;
        const theta = Math.random() * Math.PI * 2;
        pts.push(createPoint(center.x + r * Math.cos(theta), center.y + r * Math.sin(theta)));
      }

      // Anillo exterior
      for (let i = 0; i < 150; i++) {
        const r = 0.28 + (Math.random() - 0.5) * 0.06;
        const theta = Math.random() * Math.PI * 2;
        pts.push(createPoint(center.x + r * Math.cos(theta), center.y + r * Math.sin(theta)));
      }

      return pts;
    },
  },
  {
    id: 'two_moons',
    name: 'Dos Medias Lunas',
    description: 'Estructuras curvilíneas entrelazadas. Muestra por qué métodos como Spectral Clustering o DBSCAN son necesarios.',
    recommendedK: 2,
    iconName: 'Moon',
    generate: (): Point[] => {
      const pts: Point[] = [];
      const n = 90;

      // Luna 1 (superior)
      for (let i = 0; i < n; i++) {
        const angle = (i / n) * Math.PI;
        const x = 0.4 + 0.25 * Math.cos(angle) + (Math.random() - 0.5) * 0.04;
        const y = 0.42 - 0.2 * Math.sin(angle) + (Math.random() - 0.5) * 0.04;
        pts.push(createPoint(x, y));
      }

      // Luna 2 (inferior desplazada)
      for (let i = 0; i < n; i++) {
        const angle = (i / n) * Math.PI;
        const x = 0.6 - 0.25 * Math.cos(angle) + (Math.random() - 0.5) * 0.04;
        const y = 0.58 + 0.2 * Math.sin(angle) + (Math.random() - 0.5) * 0.04;
        pts.push(createPoint(x, y));
      }

      return pts;
    },
  },
  {
    id: 'smiley_face',
    name: 'Carita Feliz (Lúdico)',
    description: 'Conjunto lúdico con ojos densos, contorno de cara y sonrisa en arco.',
    recommendedK: 4,
    iconName: 'Smile',
    generate: (): Point[] => {
      const pts: Point[] = [];

      // Ojo Izquierdo
      for (let i = 0; i < 25; i++) {
        pts.push(createPoint(randomGaussian(0.35, 0.03), randomGaussian(0.35, 0.03)));
      }

      // Ojo Derecho
      for (let i = 0; i < 25; i++) {
        pts.push(createPoint(randomGaussian(0.65, 0.03), randomGaussian(0.35, 0.03)));
      }

      // Sonrisa (arco)
      for (let i = 0; i < 60; i++) {
        const theta = Math.PI * 0.15 + (i / 60) * Math.PI * 0.7;
        const x = 0.5 + 0.22 * Math.cos(theta);
        const y = 0.55 + 0.18 * Math.sin(theta);
        pts.push(createPoint(x + (Math.random() - 0.5) * 0.02, y + (Math.random() - 0.5) * 0.02));
      }

      // Contorno circular
      for (let i = 0; i < 90; i++) {
        const theta = (i / 90) * Math.PI * 2;
        const x = 0.5 + 0.38 * Math.cos(theta);
        const y = 0.5 + 0.38 * Math.sin(theta);
        pts.push(createPoint(x + (Math.random() - 0.5) * 0.02, y + (Math.random() - 0.5) * 0.02));
      }

      return pts;
    },
  },
  {
    id: 'anisotropic',
    name: 'Clústeres Elongados (Anisotrópicos)',
    description: 'Nubes de puntos alargadas en diagonal. K-Means tiende a cortar las formas alargadas.',
    recommendedK: 3,
    iconName: 'GitCommit',
    generate: (): Point[] => {
      const pts: Point[] = [];
      const n = 65;

      // Línea 1
      for (let i = 0; i < n; i++) {
        const t = (i / n) * 0.35;
        pts.push(createPoint(0.15 + t + (Math.random() - 0.5) * 0.04, 0.2 + t * 0.7 + (Math.random() - 0.5) * 0.04));
      }
      // Línea 2
      for (let i = 0; i < n; i++) {
        const t = (i / n) * 0.35;
        pts.push(createPoint(0.45 + t + (Math.random() - 0.5) * 0.04, 0.5 + t * 0.7 + (Math.random() - 0.5) * 0.04));
      }
      // Línea 3
      for (let i = 0; i < n; i++) {
        const t = (i / n) * 0.3;
        pts.push(createPoint(0.2 + t * 0.7 + (Math.random() - 0.5) * 0.04, 0.75 - t + (Math.random() - 0.5) * 0.04));
      }

      return pts;
    },
  },
  {
    id: 'uniform_random',
    name: 'Ruido Uniforme Sin Clústeres',
    description: 'Datos 100% aleatorios. Demuestra cómo K-Means inventa agrupaciones incluso donde no existen.',
    recommendedK: 3,
    iconName: 'Shuffle',
    generate: (): Point[] => {
      const pts: Point[] = [];
      for (let i = 0; i < 180; i++) {
        pts.push(createPoint(0.08 + Math.random() * 0.84, 0.08 + Math.random() * 0.84));
      }
      return pts;
    },
  },
];
